This application tests the new buzzer. 
It tests all the primitive API for audio record and playback.
It doesn't test the high level UI API. 
The supported file formats include .wav, .qcp, .amr and .mp3.

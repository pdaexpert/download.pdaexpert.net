/* pilrc generated file.  Do not edit!*/
#define MainClearTextButton 1008
#define MainDescriptionField 1007
#define MainForm 1006
#define RomIncompatibleAlert 1005
#define EditOnlyMenuBar 1003
#define MainMenuBar 1001

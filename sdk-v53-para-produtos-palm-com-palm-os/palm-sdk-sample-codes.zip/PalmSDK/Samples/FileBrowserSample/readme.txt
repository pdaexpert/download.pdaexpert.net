File Browser Sample Code

This sample code shows how to use File Browser library and APIs.
You should run this sample code on Life Drive and Tungsten T5 devices.

Please refer to the Palm Developer Guide for more inforation about the File Browser library
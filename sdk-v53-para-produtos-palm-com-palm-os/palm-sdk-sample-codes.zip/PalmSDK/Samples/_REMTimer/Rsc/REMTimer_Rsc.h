/* pilrc generated file.  Do not edit!*/
#define SleepForm 1008
#define MainOffButton 1007
#define MainRemSleepButton 1006
#define MainSleepButton 1005
#define MainDescriptionField 1004
#define MainForm 1003
#define TimerAlert 1002
#define RomIncompatibleAlert 1001

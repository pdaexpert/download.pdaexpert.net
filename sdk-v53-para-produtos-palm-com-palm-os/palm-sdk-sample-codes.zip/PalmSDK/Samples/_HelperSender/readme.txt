The HelperSender application is a sample application that shows how to use the palmOne's
Helper API.  The applications shows how to broadcast helper notifications for SMS, Email, 
and WEB to "receiving" applications.  The application that is selected by the user in the 
Default App Preference Panel will receive the service class request send by this HelperSender
application.

       


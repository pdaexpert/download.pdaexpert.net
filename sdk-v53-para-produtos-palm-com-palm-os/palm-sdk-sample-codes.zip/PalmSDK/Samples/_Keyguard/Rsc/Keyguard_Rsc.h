/* pilrc generated file.  Do not edit!*/
#define MainUnlockButton 1005
#define MainLockButton 1004
#define MainDescriptionField 1003
#define MainForm 1002
#define RomIncompatibleAlert 1001

Camera Version 2 sample
=======================

This sample shows to use the Camera in Zire72 and Ace device using the new Camera Manager library.
For Zire71 and Treo 600, please check the CameraV3 folder in the Samples folder of SDK.

Note: There is a known issue when calling kCamLibCtrlStreamStart in CamLibControl on 700p family. 
Please check this functionality on Treo 650 and 680
. Tungsten T5 Switch Audio Sample Code

This sample code shows how to switch audio from Speaker to Multi-conenctor and from Multi-conenctor
to Speaker on Tungsten T5.
This project was built using CodeWarrior 9.

WARNING: This sample code uses an ARMlet to Switch Audio.
This is not officially supported by palmOne. Please use this at your own risk.

Features:

- Switch Audio from Speaker to Multi-connector (On Tungsten T5).
- Switch Audio from Multi-connector to Speaker (On Tungsten T5).

Files:

- TungstenT5SwitchAudio: Shows how to switch audio from Speaker to Multi-connector on Tungsten T5.
                         Shows how to switch audio from Multi-connector to Speaker on Tungsten T5.
			


//	Resource: tFRM 1000
#define MainForm                                  1000
#define MainFormScrollBar                         1001
#define MainFormScrollBarB												1002
//	Resource: Talt 1001
#define RomIncompatibleAlert                      1001
#define RomIncompatibleOK                         0

//	Resource: Talt 1000

#define CantLoadSTEAlert                          1000
#define CantLoadSTEOK                             0


//	Resource: MBAR 1000
#define MainFormMenuBar                           1000

#define MainEditCopy                              1000
#define MainEditSelect510                         1001
#define MainEditSelect10100                       1002
#define MainEditSelect50100                       1003
#define MainEditSelectAll                         1004
#define MainEditToggleFont			  1005

#define MainOptionsAboutSTETest                   1006



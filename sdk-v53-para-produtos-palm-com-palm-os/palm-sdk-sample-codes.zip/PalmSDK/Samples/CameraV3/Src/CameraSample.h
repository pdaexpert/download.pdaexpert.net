
//	Resource: tFRM 1000
#define MainForm                                  1000	
#define MainPreviewButton                         1003	


//	Resource: Talt 1001
#define RomIncompatibleAlert                      1001
#define RomIncompatibleOK                         0

//	Resource: Talt 1100
#define LibraryLoadErrorAlert                     1100
#define LibraryLoadErrorOK                        0

//	Resource: MBAR 1000
#define MainMenuBar								1000


//	Resource: MENU 1000
#define OptionsMenu                               1000
#define OptionsAbout							  1004


. Five Way Sample Code

This sample code shows how to detect key presses, holds, and releases on a Five-way enabled device.
This project was built using CodeWarrior 8.

Files:

- Common : Useful functions for PalmOS.
- TestFiveWay : Main application.
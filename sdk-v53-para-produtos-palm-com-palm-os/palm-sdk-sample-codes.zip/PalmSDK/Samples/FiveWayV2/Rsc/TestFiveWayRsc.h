/* pilrc generated file.  Do not edit!*/
#define NotAvailableAlert 1016
#define RomIncompatibleAlert 1015
#define MainSelectField 1014
#define MainRightField 1013
#define MainLeftField 1012
#define MainDownField 1011
#define MainChrField 1010
#define MainUnnamed1008Label 1009
#define MainUnnamed1007Label 1008
#define MainRightCheckbox 1007
#define MainLeftCheckbox 1006
#define MainDownCheckbox 1005
#define MainSelectCheckbox 1004
#define MainUpField 1003
#define MainUpCheckbox 1002
#define MainForm 1001

Name

_PhoneInfo

-----------------------------------------------------------------------------------------------------------------------
Description

This sample application shows how to use the palmOne Telephony Library to display useful information.


-----------------------------------------------------------------------------------------------------------------------
Builds with

This project was built using Palm OS Developer Suite version 1.2.0.23.

------------------------------------------------------------------------------------------------------------------------
Devices

Should run on all Palm OS devices
Should not crash on other devices

------------------------------------------------------------------------------------------------------------------------

Requirements

No specific requirements

-----------------------------------------------------------------------------------------------------------------------
Libraries Used

Telephony library

------------------------------------------------------------------------------------------------------------------------
How to Run

1. Launch the "PhoneInfo"
application
- Check Results

2. Tap on 'vibrate'
   - Check Results


Expected Results:

1. The application should show
information about the phone whenever
available

2. The device should vibrate



-----------------------------------------------------------------------------------------------------------------------

Note

----------------------------------------------------------------------------------------------------------------------


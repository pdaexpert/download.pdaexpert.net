. GoLCd Sample Code

This sample code shows how to use the GoLCD API.
This project was built using CodeWarrior 8.

Features:

- Enable/Disable GoLCD.
- Set the Ink Color.
- Set the GSI Color.
- Set the GoLCd boundary.
- Set the Tap and Hold Timeout.

Files:

- ColorButtonGadget : The little color buttons.
- Common : Usefeul functions for PalmOS.
- GoLCDTest : Main application.
- GoLcdUtils : Utility functions for GoLCD
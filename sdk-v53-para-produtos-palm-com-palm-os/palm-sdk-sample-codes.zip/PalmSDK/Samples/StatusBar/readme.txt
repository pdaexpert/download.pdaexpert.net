. Status Bar Sample Code

This sample code shows how to detect the Slider status on Tungsten T3.
This sample code also shows how to detect the screen rotation on Tungsten T3 and Tungsten T5.
This project was built using CodeWarrior 9.

WARNING: This sample code uses an ARMlet to determine the Slider Position.
This is not officially supported by palmOne. Please use this at your own risk.

Features:

- Detect the Slider position (Tungsten T3 Only).
- Detect the Screen Rotation (Tungsten T3 and Tungsten T5).

Files:

- StatusBar	: Shows how to detect the Slider position on Tungsten T3.
              Shows how to detect the screen rotation on Tungsten T3 and Tungsten T5.
			

The RingTone application is a sample application showing the use of palmOne's
Tones shared library.  The applications shows how to get the list of tones from
the system database, play the tone, and stop the tone play.
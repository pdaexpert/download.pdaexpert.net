/* pilrc generated file.  Do not edit!*/
#define MainClearTextButton 1009
#define MainDescriptionField 1008
#define MainForm 1007
#define CustomAlert 1006
#define RomIncompatibleAlert 1005
#define EditOnlyMenuBar 1003
#define MainMenuBar 1001

This sample code shows how to use the Favorites DB library to create custom favorites in Phone app view (blue grid).
Please note that the functionality of this library is very limited due to the fact that it was designed to be used
by the Phone application only. There is currently no programmatic way to tell if a position in the grid has been occupied
or not, so the newly-created entry will always replace the existing one.

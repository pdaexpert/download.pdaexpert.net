#pragma once

class MLConduitXml
{
public:
	MLConduitXml(void);
	~MLConduitXml(void);
};

This sample code shows how to detect if the radio is off or on,
how to turn on the radio, how to turn off the radio, how to query the sim card for
the phone number of the device, how to check if the device has service available
using the signal level.

This project was built using CodeWarrior 9.

Features:

- How to detect if the radio is off or on.
- How to turn the radio on.
- How to turn the radio off.
- How to query the SIM card for the phone number.
- How to check if the device has service available using the signal level.
/*********************************************************************
 * GSMStatus.c
 *
 * main file for GSMStatus
 *
 * Brief: 
 *	This sample code shows how to retriece radio connection status, operator name, and voicemail number on
 *	GSM phones.
 *
 * Copyright (c) 2000-2006 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *********************************************************************/
 
#include <PalmOS.h>
#include <PalmOSGlue.h>
#include <HsNav.h>      // Include for HsExt.h
#include <HsExt.h>      // Include for HsGetPhoneLibrary()
#include <HsPhone.h>    // Include for Phone library API
#include <HsNavCommon.h>

#include "Common.h"
#include "GSMStatus.h"
#include "GSMStatus_Rsc.h"

/*********************************************************************
 * Entry Points
 *********************************************************************/

/*********************************************************************
 * Global variables
 *********************************************************************/

UInt16 gLibRef = 0;

/*********************************************************************
 * Internal Constants
 *********************************************************************/

/* Define the minimum OS version we support */
#define ourMinVersion    sysMakeROMVersion(3,0,0,sysROMStageDevelopment,0)
#define kPalmOS20Version sysMakeROMVersion(2,0,0,sysROMStageDevelopment,0)

/*********************************************************************
 * Internal Functions
 *********************************************************************/
 
 extern void MainFormInit(FormType *frmP, Boolean redraw);

/*********************************************************************
 * FUNCTION: MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:
 *
 * command
 *     menu item id
 *********************************************************************/

static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;

	UInt16  cardNo;
	LocalID dbID;
	DmSearchStateType searchState;

	DmGetNextDatabaseByTypeCreator(true, &searchState, sysFileTApplication,
									 appFileCreator, true, &cardNo, &dbID);

	switch (command)
	{
		case OptionsAbout:
			MenuEraseStatus(0);
			HsAboutHandspringApp(cardNo, dbID, "2006", "Palm DTS Team");
			handled = true;
		break;
	}

	return handled;
}

/*********************************************************************
 * FUNCTION: MainFormHandleEvent
 *
 * DESCRIPTION:
 *
 * This routine is the event handler for the "MainForm" of this 
 * application.
 *
 * PARAMETERS:
 *
 * eventP
 *     a pointer to an EventType structure
 *
 * RETURNED:
 *     true if the event was handled and should not be passed to
 *     FrmHandleEvent
 *********************************************************************/

static Boolean MainFormHandleEvent(EventType * eventP)
{
	Boolean handled = false;
	FormType * frmP = FrmGetActiveForm();;

	switch (eventP->eType) 
	{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);

		case frmOpenEvent:
			DbgMessage ("frmOpenEvent \n");
			
			// Set focus on Refresh button
			FrmSetFocus(frmP, noFocus);
		  	FrmSetFocus(frmP, FrmGetObjectIndex(frmP, MainRefreshButton));
			
			FrmDrawForm(frmP);
			
			MainFormInit(frmP, true);
			handled = true;
			break;
            
        case frmUpdateEvent:
			/* 
			 * To do any custom drawing here, first call
			 * FrmDrawForm(), then do your drawing, and
			 * then set handled to true. 
			 */
			break;

		case nilEvent:
			
			DbgMessage ("nilEvent \n");
			MainFormInit(frmP, true);
		    handled = true;
		    
		    break;
		     
		case keyDownEvent:	 
		case ctlSelectEvent:
		{
			if ((eventP->data.ctlSelect.controlID == MainRefreshButton)||
				(eventP->data.keyDown.keyCode == vchrRockerCenter))
			{
			    PhnPowerType power = phnPowerOff;
			     
			    power = PhnLibModulePowered(gLibRef);
			    
			    if (power == phnPowerOff)   
			        PhnLibSetModulePower(gLibRef, true);
			        
			    DbgMessage ("Refresh \n");
				MainFormInit(frmP, true);
			}

			break;
		}
		
		default:
		    break;
	}
    
	return handled;
}

/*********************************************************************
 * FUNCTION: AppHandleEvent
 *
 * DESCRIPTION: 
 *
 * This routine loads form resources and set the event handler for
 * the form loaded.
 *
 * PARAMETERS:
 *
 * event
 *     a pointer to an EventType structure
 *
 * RETURNED:
 *     true if the event was handled and should not be passed
 *     to a higher level handler.
 *********************************************************************/

static Boolean AppHandleEvent(EventType * eventP)
{
	UInt16 formId;
	FormType * frmP;

	if (eventP->eType == frmLoadEvent)
	{
		/* Load the form resource. */
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		/* 
		 * Set the event handler for the form.  The handler of the
		 * currently active form is called by FrmHandleEvent each
		 * time is receives an event. 
		 */
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

		}
		return true;
	}

	return false;
}

/*********************************************************************
 * FUNCTION: AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.
 *********************************************************************/

static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;

	do 
	{
		/* change timeout if you need periodic nilEvents */
		EvtGetEvent(&event, SysTicksPerSecond() / 2);

		if (! SysHandleEvent(&event))
		{
			if (! MenuHandleEvent(0, &event, &error))
			{
				if (! AppHandleEvent(&event))
				{
					FrmDispatchEvent(&event);
				}
			}
		}
	} while (event.eType != appStopEvent);
}

/*********************************************************************
 * FUNCTION: AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * RETURNED:
 *     errNone - if nothing went wrong
 *********************************************************************/

static Err AppStart(void)
{
	HsGetPhoneLibrary(&gLibRef);
	PhnLibOpen(gLibRef);

    // Register for phone event:
    // We're mainly interested in phnEvtRegistration indication
	PhnLibRegister(gLibRef, appFileCreator, phnServiceAll);

	return errNone;
}

/*********************************************************************
 * FUNCTION: AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *********************************************************************/

static void AppStop(void)
{
    /* Unregister for phone event: */
    PhnLibRegister(gLibRef, appFileCreator, 0);

	PhnLibClose(gLibRef);
	
	/* Close all the open forms. */
	FrmCloseAllForms();
}

/*********************************************************************
 * FUNCTION: RomVersionCompatible
 *
 * DESCRIPTION: 
 *
 * This routine checks that a ROM version is meet your minimum 
 * requirement.
 *
 * PARAMETERS:
 *
 * requiredVersion
 *     minimum rom version required
 *     (see sysFtrNumROMVersion in SystemMgr.h for format)
 *
 * launchFlags
 *     flags that indicate if the application UI is initialized
 *     These flags are one of the parameters to your app's PilotMain
 *
 * RETURNED:
 *     error code or zero if ROM version is compatible
 *********************************************************************/

static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;

	/* See if we're on in minimum required version of the ROM or later. */
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
	{
		if ((launchFlags & 
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
		{
			FrmAlert (RomIncompatibleAlert);

			/* Palm OS versions before 2.0 will continuously relaunch this
			 * app unless we switch to another safe one. */
			if (romVersion < kPalmOS20Version)
			{
				AppLaunchWithCommand(
					sysFileCDefaultApp, 
					sysAppLaunchCmdNormalLaunch, NULL);
			}
		}

		return sysErrRomIncompatible;
	}

	return errNone;
}

/*********************************************************************
 * FUNCTION: PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 * 
 * PARAMETERS:
 *
 * cmd
 *     word value specifying the launch code. 
 *
 * cmdPB
 *     pointer to a structure that is associated with the launch code
 *
 * launchFlags
 *     word value providing extra information about the launch.
 *
 * RETURNED:
 *     Result of launch, errNone if all went OK
 *********************************************************************/

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	Err error;

	error = RomVersionCompatible (ourMinVersion, launchFlags);
	if (error) return (error);

	switch (cmd)
	{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;

			/* 
			 * start application by opening the main form
			 * and then entering the main event loop 
			 */
			FrmGotoForm(MainForm);
			AppEventLoop();

			AppStop();
			break;
			
		case phnLibLaunchCmdEvent:
		{
		    PhnEventPtr pEvent = (PhnEventPtr)cmdPBP;
		    
		    if (pEvent->eventType == phnEvtRegistration)
		    {
		        if (pEvent->data.registration.status != registrationNone)
		        {
		            /* Use this for demo only:
		             Do not block while the phone is being activated */
		            
		            // FrmAlert(RegistrationAlert);
		        }
		    }
		}
	}

	return errNone;
}

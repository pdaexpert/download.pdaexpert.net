/*********************************************************************
 * MainInit.c
 *
 * Initialization for GSMStatus
 *
 * Copyright (c) 2000-2006 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *********************************************************************/
 
#include <PalmOS.h>
#include <PalmOSGlue.h>
#include <HsNav.h>      // Include for HsExt.h
#include <HsExt.h>      // Include for HsGetPhoneLibrary()
#include <HsPhone.h>    // Include for Phone library API
#include <HsNavCommon.h>

#include "Common.h"
#include "GSMStatus.h"
#include "GSMStatus_Rsc.h"

/*********************************************************************
 * Global variables
 *********************************************************************/

extern UInt16 gLibRef;

/*********************************************************************
 * Internal Functions
 *********************************************************************/
static void * GetObjectPtr(UInt16 objectID);
void MainFormInit(FormType *frmP, Boolean redraw);

/*********************************************************************
 * FUNCTION: GetObjectPtr
 *
 * DESCRIPTION:
 *
 * This routine returns a pointer to an object in the current form.
 *
 * PARAMETERS:
 *
 * formId
 *     id of the form to display
 *
 * RETURNED:
 *     address of object as a void pointer
 *********************************************************************/

static void * GetObjectPtr(UInt16 objectID)
{
	FormType * frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}

/*********************************************************************
 * FUNCTION: MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:
 *
 * frm
 *     pointer to the MainForm form.
 *********************************************************************/

void MainFormInit(FormType *frmP, Boolean redraw)
{
	Err err = errNone;
	CharPtr operatorName = NULL;
	CharPtr voicemailNum = NULL;
    PhnPowerType power = phnPowerOff;
    PhnRadioStateType radioState;
  
	FieldType *ConnectionField;
	FieldType *OperatorField;
	FieldType *VoicemailField;
	FieldType *RadioField;
			
	ConnectionField = (FieldType *) GetObjectPtr(MainConnectionField);
	OperatorField = (FieldType *) GetObjectPtr(MainOperatorField);
	VoicemailField = (FieldType *) GetObjectPtr(MainVoicemailField);
	RadioField = (FieldType *) GetObjectPtr(MainRadioField);

    power = PhnLibModulePowered(gLibRef);
    PhnLibGetRadioState(gLibRef, &radioState);
    
    if (power == phnPowerOff)
    {
        DbgMessage ("Radio Off \n");
        SetFieldTextFromStr(RadioField, "OFF", redraw);
        
    }
    else
    {
        DbgMessage ("Radio On \n");
        SetFieldTextFromStr(RadioField, "ON", redraw);
        
    }
    
    /* Checks if the phone found any network cellular service. */
	if (PhnLibRegistered(gLibRef))
	{
		DbgMessage ("connectionfiled OK \n");
		SetFieldTextFromStr(ConnectionField, "OK", redraw);
		
				
		err = PhnLibCurrentOperator(gLibRef, NULL, &operatorName, NULL);
		if (!err)
		{
			DbgMessage ("operatorName OK \n");
			SetFieldTextFromStr(OperatorField, operatorName, redraw);
			
		}
		else
		{
			DbgMessage ("operatorName Notavailable \n");
			SetFieldTextFromStr(OperatorField, "Retrieving...", redraw);
			
		}
		
			
		DbgMessage ("Get Voicemail Number OK \n");
		err = PhnLibGetBoxNumber(gLibRef, kBoxVoice, radioState.activeLineNumber, &voicemailNum);
		
		/* If the radio is ready and the voicemail # is available */
		/* There is a known bug in Treo 680 of the PhnLibGetBoxNumber API. You need to check */
		/* both the return value and the voicemail number to make sure you actually retrieve the voicemail#*/
		if ((!err)&&(voicemailNum != NULL))
		{
			DbgMessage ("voiceNum OK \n");
			SetFieldTextFromStr(VoicemailField, voicemailNum, redraw);
			
		}
		else
		{	
			DbgMessage ("voiceNum Notavailable \n");
			SetFieldTextFromStr(VoicemailField, "Retrieving...", redraw);
			
		}	
		

	}
	else
	{
		DbgMessage ("Service not found \n");
		SetFieldTextFromStr(ConnectionField, "Service not found", redraw);
		DbgMessage ("operator - \n");
		SetFieldTextFromStr(OperatorField, "-", redraw);
		SetFieldTextFromStr(VoicemailField, "-", redraw);
		
	}
	
	if (operatorName) MemPtrFree(operatorName);
	if (voicemailNum) MemPtrFree(voicemailNum);
}
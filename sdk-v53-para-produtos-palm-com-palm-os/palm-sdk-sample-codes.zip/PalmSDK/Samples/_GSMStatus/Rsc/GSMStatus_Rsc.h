/* pilrc generated file.  Do not edit!*/
#define OptionsAbout 1013
#define MainRefreshButton 1012
#define MainRadioField 1011
#define MainRadioLabel 1010
#define MainVoicemailField 1009
#define MainVoicemailLabel 1008
#define MainOperatorField 1007
#define MainOperatorLabel 1006
#define MainConnectionField 1005
#define MainConnectionLabel 1004
#define OptionsMenu 1003
#define MainForm 1002
#define RomIncompatibleAlert 1001

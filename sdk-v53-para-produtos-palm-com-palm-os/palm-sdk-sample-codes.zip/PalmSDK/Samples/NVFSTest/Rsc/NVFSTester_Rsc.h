/* pilrc generated file.  Do not edit!*/
#define MainClearSyncButton 1005
#define MainClearTextButton 1004
#define MainDescriptionField 1003
#define MainForm 1002
#define RomIncompatibleAlert 1001

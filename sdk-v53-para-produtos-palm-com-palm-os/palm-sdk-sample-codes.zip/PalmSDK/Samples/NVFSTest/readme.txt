This sample file shows how to commit database changes permanently to NAND (Flash) drive.

'Write to DBCache' button writes the field changes to the app database, and 'sync to flash' button commits the changes to NAND (Flash) drive without closing the database.

Changes that are already committed to the NAND (Flash) drive should be seen even if the device loses power or resets when the application is running.
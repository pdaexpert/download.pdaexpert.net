The MMSReceiver application is a sample application that shows how to use the palmOne's
Helper API.  This application shows how to register, enumerate, validate, and execute
the system's helper notifications for MMS.

To use the palmOne's Helper architecture, an application will register with the system for
the service class(es) that the application wish to accept and respond to.  A Helper "sending" 
application can send the service request directly to this Helper receiver or send indirectly 
to the system which will be forwarded to the application selected in the Default App Preference
Panel.
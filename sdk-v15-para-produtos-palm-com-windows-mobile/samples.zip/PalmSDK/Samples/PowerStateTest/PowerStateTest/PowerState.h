/*! \file PowerState.h:  revision 1.0
\brief This provides routines for applications to have the device enter
  unattended mode when necessary and prevent it from suspending as long
  as the app needs to.  This also provides a dialog box handler for the main window.
 
	 Copyright 2005 Palm Inc., All Rights Reserved.
*/

#include "PowerStateTest.h"

#ifndef __POWERSTATE_H__
#define __POWERSTATE_H__

/**
 * No error
 */
#define	POWERSTATE_ERROR_OK					0x00000000L	
/**
 * Error with creating or deleting thread
 */
#define POWERSTATE_ERROR_THREAD				0x00000001L		
/**
 * Power Manager returned an error
 */
#define	POWERSTATE_ERROR_PM					0x00000002L		
/**
 * General error
 */
#define	POWERSTATE_ERROR_GENERAL			0x00000003L		
/**
 * Unattended mode already started
 */
#define	POWERSTATE_ERROR_ALREADY_STARTED	0x00000004L		
/**
 * Request to end unattended mode when it wasn't started
 */
#define	POWERSTATE_ERROR_NOT_STARTED		0x00000005L		

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/*! \fn DWORD PowerStateStartUnattendedMode ()
    \brief Start the Unattend Mode for an application.

     Start the Unattend Mode for an application. This will call the 
	 power manager to request the unattended mode and start a thread
	 that will reset the system idle timer every 30 seconds.
	 If the function encounters an error, it will clean up after itself.
	 There is no need to call PowerStateEndUnattendedMode.
*/
DWORD PowerStateStartUnattendedMode ();

/*! \fn DWORD PowerStateEndUnattendedMode ()
    \brief Shutdown the thread and undo the work from PowerStateStartUnattendedMode.

	Shutdown the thread and undo the work from PowerStateStartUnattendedMode.
*/
DWORD PowerStateEndUnattendedMode ();

/*! \fn INT_PTR CALLBACK PowerManagementDialog(HWND, UINT, WPARAM, LPARAM)
    \brief Message handler for main window.

	Handles the main window of the app.  When the user presses the "Start Unattended" button
	it puts the device into this mode and restarts the counter.  When the user presses the "Stop
	Unattended" button it takes the device out of unattended mode and restarts the counter.
*/
INT_PTR CALLBACK PowerManagementDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

#ifdef __cplusplus
}
#endif // __cplusplus



#endif __POWERSTATE_H__
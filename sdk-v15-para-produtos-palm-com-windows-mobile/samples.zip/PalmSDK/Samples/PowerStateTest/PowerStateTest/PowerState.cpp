#include <windows.h>
#include <pm.h>
#include <pmpolicy.h>

#include "powerstate.h"

/*************************************************************************
 * Globals
 ************************************************************************/
HANDLE g_hThread = NULL;
HANDLE g_hTerminateEvent = NULL;
BOOL   b_UnattendedMode = FALSE;

/*************************************************************************
 * Defines
 ************************************************************************/
#define	POWERSTATE_TIMER_RESET_INTERVAL		30	// Time  in seconds
#define MAX_POWER_STATE_NAME				64
/*************************************************************************
 * Private routines
 ************************************************************************/

/**
 * IdleResetThread
 *
 * Thread to call SystemIdleTimerReset at a set interval
 *
 * @param lpParameter
 *
 * @returns	0 if no error.
 */
DWORD 
IdleResetThread (LPVOID lpParameter)
{
	DWORD dwError = 0;
	BOOL bDone = FALSE;
	DWORD dwIdleResetInterval = (DWORD)lpParameter;	// Time is passed in as seconds
	HANDLE hUserActivityTimer = NULL;

	// Bump up the priority to ensure that we can reset the idle timer above other threads
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);

	hUserActivityTimer = CreateEvent (NULL, FALSE, FALSE, L"PowerManager/ActivityTimer/UserActivity");

	while (!bDone)
	{
		dwError = WaitForSingleObject (g_hTerminateEvent, dwIdleResetInterval * 1000 /* time in ms */);
		if (dwError == WAIT_OBJECT_0)
		{
			// Terminate event was signaled so we should exit
			bDone = TRUE;
		}
		else if (dwError == WAIT_TIMEOUT)
		{
			// timout expired so reset the idle timer
			SystemIdleTimerReset ();
		}
		else if (dwError == WAIT_FAILED)
		{
			//DEBUGMSG(TEXT("IdleResetThread: WaitForSingleObject returned error: 0x%Lx"), GetLastError ());
			bDone = TRUE;
		}
	}

	if (hUserActivityTimer)
		CloseHandle (hUserActivityTimer);

	return 0;
}

/**
 * CleanUpThread
 *
 * Cleanup the thread created by the start routine
 *
 * @returns	0 if no error.
 */
DWORD
CleanUpThread ()
{
	DWORD dwErrorCode = POWERSTATE_ERROR_OK;

	// Clean up after the thread

	// First we set the event that will cause the thread to exit
	dwErrorCode = SetEvent (g_hTerminateEvent);
	if (!dwErrorCode)
	{
		// This isn't a good situation as it appears we can't set an event
		// We need to exit because the WaitForSingleObject will never return
		// as the thread will never exit.
		return dwErrorCode;
	}
	// Wait for the thread to really finish
	dwErrorCode = WaitForSingleObject (g_hThread, INFINITE);
	if (dwErrorCode != WAIT_OBJECT_0)
	{
		dwErrorCode = POWERSTATE_ERROR_THREAD;
	}
	else
	{
		dwErrorCode = POWERSTATE_ERROR_OK;
	}

	// Close out the handles we created. We really don't care about the return codes
	(void)CloseHandle (g_hTerminateEvent);
	(void)CloseHandle (g_hThread);

	g_hThread = NULL;
	g_hTerminateEvent = NULL;

	return dwErrorCode;
}


/*************************************************************************
 * Public interface
 ************************************************************************/

/**
 * PowerStateStartUnattendedMode
 *
 * Start the Unattend Mode for an application. This will call the 
 * power manager to request the unattended mode and start a thread
 * that will reset the system idle timer every 30 seconds.
 * If the function encounters an error, it will clean up after itself.
 * There is no need to call PowerStateEndUnattendedMode.
 *
 * @returns	POWERSTATE_ERROR_OK if no error.
 */
DWORD
PowerStateStartUnattendedMode ()
{
	DWORD dwError = POWERSTATE_ERROR_OK;
	BOOL bResult;

	if (b_UnattendedMode)
		return POWERSTATE_ERROR_ALREADY_STARTED;

	// Create the SystemIdleTimerReset thread
	// We create an event that is passed into this thread. This event will be used
	// to terminate the thread.
	g_hTerminateEvent = CreateEvent (NULL, FALSE, FALSE, NULL);
	if (g_hTerminateEvent == NULL)
	{
		DWORD errorCode = GetLastError ();
		dwError = POWERSTATE_ERROR_THREAD;
		return dwError;
	}
	g_hThread = CreateThread (NULL, 0, IdleResetThread, (LPVOID)POWERSTATE_TIMER_RESET_INTERVAL, 0, NULL);
	if (g_hThread == NULL)
	{
		DWORD errorCode = GetLastError ();
		dwError = POWERSTATE_ERROR_THREAD;
		(void)CloseHandle (g_hTerminateEvent);
		g_hTerminateEvent = NULL;
		return dwError;
	}

	// Reset the timer for the first time
	SystemIdleTimerReset ();

	// Enter unattended mode. If the system is on, this will simply increment a
	// reference count in the power manager. The power manager looks at this count
	// if the user presses the power button to turn off the device.
	
	// Basically this function will either prevent the device from turning off or
	// allow the system to run with the screen off if the user presses the power button.

	bResult = PowerPolicyNotify (PPN_UNATTENDEDMODE, TRUE);
	if (bResult == FALSE)
	{
		dwError = POWERSTATE_ERROR_PM;
		// Clean up after the thread
		(void)CleanUpThread ();
	}

	if (dwError == POWERSTATE_ERROR_OK)
		b_UnattendedMode = TRUE;

	return dwError;
}

/**
 * PowerStateEndUnattendedMode
 *
 * Shutdown the thread and undo the work from PowerStateStartUnattendedMode
 *
 * @returns	POWERSTATE_ERROR_OK if no error.
 */
DWORD
PowerStateEndUnattendedMode ()
{
	DWORD dwError = POWERSTATE_ERROR_OK;
	BOOL bResult;

	// Make sure we called the StartUnattended mode
	if (b_UnattendedMode == FALSE)
		return POWERSTATE_ERROR_NOT_STARTED;

	// Shutdown the thread. This means the calls to SystemIdleTimerReset will stop
	// and the idle timer can countdown normally. At the worst case, the system will
	// auto-sleep 30 seconds later than scheduled.
	dwError = CleanUpThread ();
	if (dwError)
	{
		dwError = POWERSTATE_ERROR_THREAD;
		// Don't return immedately. We want to try to leave unattended mode so
		// we will have some chance of the device going to sleep.
	}

	// Leave unattended mode. If the device is on, this will simply decrement the Power
	// Manager reference count. If the system is already in Unattended mode, leaving this
	// state will cause the device to go to the Suspend state provided that no one else has
	// requested unattended mode.
	bResult = PowerPolicyNotify (PPN_UNATTENDEDMODE, FALSE);
	if (bResult == FALSE)
	{
		dwError = POWERSTATE_ERROR_PM;
	}

	if (dwError == POWERSTATE_ERROR_OK)
		b_UnattendedMode = FALSE;

	return dwError;
}


INT_PTR CALLBACK PowerManagementDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static int UnattendedTime = 0;
	static bool InUnattendedMode = false;

	switch (message)
	{
	case WM_INITDIALOG:
		{
			//set the timer so that we can check the keyguard state
			SetTimer(hDlg, 1, 1000, NULL); 
		}
		return (INT_PTR)TRUE;

	case WM_COMMAND:

		if (LOWORD(wParam) == IDC_START_UNATTENDED)
		{
            //if not in unattended mode then start it and set the timer to 0
			if (!InUnattendedMode)
			{
				SetDlgItemText(hDlg,IDC_UNATTENDED_TIME,L"0");
				UnattendedTime = 0;
				PowerStateStartUnattendedMode();
				InUnattendedMode = true;
				SetDlgItemText(hDlg,IDC_START_UNATTENDED,L"Stop unattended mode");
			}
			//otherwise get out of unattended mode and set the timer to 0
			else
			{

				SetDlgItemText(hDlg,IDC_UNATTENDED_TIME,L"0");
				UnattendedTime = 0;
				PowerStateEndUnattendedMode();
				InUnattendedMode = false;
				SetDlgItemText(hDlg,IDC_START_UNATTENDED,L"Start unattended mode");
			}
		}

    //increment the counter and display it
	case WM_TIMER:
		{	
			UnattendedTime++;
			wchar_t UnattedTimeString[10];
			_itow(UnattendedTime,UnattedTimeString,10);
			SetDlgItemText(hDlg,IDC_UNATTENDED_TIME,UnattedTimeString);
		}
		break;

		if (LOWORD(wParam) == IDOK)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;

	case WM_CLOSE:
		EndDialog(hDlg, message);
		return TRUE;
	}
	return (INT_PTR)FALSE;
}
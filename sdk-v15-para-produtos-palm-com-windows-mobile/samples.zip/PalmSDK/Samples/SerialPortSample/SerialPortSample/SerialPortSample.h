#pragma once
#include "resourceppc.h"
#include "SerialPort.h"

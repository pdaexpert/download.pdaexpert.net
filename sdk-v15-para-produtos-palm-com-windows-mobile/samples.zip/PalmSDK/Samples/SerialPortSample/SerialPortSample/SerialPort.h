/*! \file SerialPort.h:  revision 1.0
	\brief Serial Port sample demonstrating setting up the Treo700w, Treo700wx and Treo750v's serial port and sending a character.
	This sample allows configuration of the serial port and the ability to send a character of data over the port.  On the Treo750v there is an IOCTL which must be called to configure the port.  Something to note on the use of this IOCTL is that when the handle to the serial port is closed, the serial port will be un-configured even if this IOCTL had been used and to reconfigure the port the IOCTL will need to be used again the next time the serial port is opened.  SerialPortSample.cpp is where all SerialPort.h function calls are made and
	SerialPortSample.cpp is standard Windows code.

	Copyright 2006 Palm Inc., All Rights Reserved.
*/

#pragma once

#include "stdafx.h"
#include <windows.h>
#include <commctrl.h>
#include <WINIOCTL.H>

extern "C" __declspec(dllimport)


/**
 * soft' reset' IOCTL (used on the Treo 700w and 700wx configuration) - same as pressing the pin under the battery cover
 */
#define     IOCTL_HAL_REBOOT       CTL_CODE(FILE_DEVICE_HAL, 15, METHOD_BUFFERED, FILE_ANY_ACCESS)

/**
 * IOCTL to shut down access to the Treo750's serial port
 */
#define IOCTL_SERIAL_CONFIGURE_OFF CTL_CODE(FILE_DEVICE_SERIAL_PORT,101,METHOD_BUFFERED,FILE_ANY_ACCESS)

/**
 * IOCTL to allow the Treo750's serial port to be used
 */
#define IOCTL_SERIAL_CONFIGURE_ON CTL_CODE(FILE_DEVICE_SERIAL_PORT,102,METHOD_BUFFERED,FILE_ANY_ACCESS)


/*! \fn BOOL KernelIoControl( DWORD dwIoControlCode, LPVOID lpInBuf, DWORD nInBufSize,
					 LPVOID lpOutBuf, DWORD nOutBufSize, LPDWORD lpBytesReturned )
    \brief Prototype for Microsoft's KernelIOControl function.

	This function provides the kernel with a generic I/O control for carrying out I/O operations.
*/
BOOL KernelIoControl( DWORD dwIoControlCode, LPVOID lpInBuf, DWORD nInBufSize,
					 LPVOID lpOutBuf, DWORD nOutBufSize, LPDWORD lpBytesReturned );


/*! \fn bool IsSerialPortConfigured()
    \brief Check if the serial port is configured.

	This function will check if the serial port is configured.  On the Treo750v it will just
	return true since configuration doesn't happen until the COM port is opened for use.
*/
bool IsSerialPortConfigured();


/*! \fn bool ConfigureSerialPort()
    \brief Configures the serial port for use.

	This function will configure the serial port for use.  On the Treo750v it will just
	return true since configuration doesn't happen until the COM port is opened for use.
*/
bool ConfigureSerialPort();


/*! \fn bool ConfigureIRPort()
    \brief Configures the IR port.

	This function will configure the IR port for use.  On the Treo750v it will just
	return true since no configuration is necessary.
*/
bool ConfigureIRPort();


/*! \fn bool OpenCommPort()
    \brief Open the serial port.

	This function will open the serial port for serial use.  On the Treo700w and 700wx this is
	COM2 and on the Treo750v this is COM1.
*/
bool OpenCommPort();

/*! \fn bool CloseCommPort()
    \brief Close the port.

	This function will close the serial port for serial use.  On the Treo700w and 700wx this is
	COM2 and on the Treo750v this is COM1.
*/
bool CloseCommPort();


/*! \fn unsigned int SerialCommsSend(unsigned char * pData, unsigned int numberOfBytesToWrite)
    \brief Send the data through the port.

	This function will use WriteFile to write data to the serial port.
*/
unsigned int SerialCommsSend(unsigned char * pData, unsigned int numberOfBytesToWrite);

/*! \file SerialPort.cpp:  revision 1.0
	\brief Serial Port sample demonstrating setting up the Treo700w and Treo750 serial port
	and sending a character.  SerialPortSample.cpp is where all SerialPort.h function calls are 
	made and SerialPortSample.cpp is standard Windows code.

	Copyright 2006 Palm Inc., All Rights Reserved.
*/

#include "SerialPortSample.h"

HANDLE hCom = INVALID_HANDLE_VALUE;  //handle to area where serial port writes to

//call this to toggle the serial port on and off
BOOL TurnOnSerial(HANDLE m_hPort, int bOn)
{
	DWORD cbActual; 

	if(bOn == 1)
		return DeviceIoControl(m_hPort, IOCTL_SERIAL_CONFIGURE_ON, NULL, 0, NULL, 0, &cbActual, NULL);
	else
		return DeviceIoControl(m_hPort, IOCTL_SERIAL_CONFIGURE_OFF, NULL, 0, NULL, 0, &cbActual, NULL);
}



//pass in a device type to check if you're running on that type
bool CheckDeviceType (wchar_t *device_type)
{
	TCHAR OEMString[100];
	SystemParametersInfo(SPI_GETOEMINFO, 100, OEMString, 0 );

	if (wcscmp(OEMString,device_type)==0)
		return true;
	else
		return false;
}

//display a message box with the current error
void ShowLastError(wchar_t * string)
{
	DWORD error = ::GetLastError();

	wchar_t temp[100];
	_itow(error,temp,10);
	::MessageBox(NULL,temp,string,MB_OK);
}

//make a setting in the registry
BOOL SetRegistryDWORD(HKEY hive, TCHAR *szPath, TCHAR *szKey, DWORD dwValue)
{
	HKEY hk;
	LONG res= RegOpenKeyEx(hive, szPath, 0, 0, &hk);
	if (res!=ERROR_SUCCESS) {
		wchar_t temp[2000];
		swprintf( temp, L"%s", L"ERROR opening regpath %08lx %ls\n", hive, szPath );
		ShowLastError(temp);
		return false;
	}
	res= RegSetValueEx(hk, szKey, 0, REG_DWORD, (BYTE*)&dwValue, sizeof(DWORD));
	if (res!=ERROR_SUCCESS) {
		wchar_t temp[2000];
		swprintf( temp, L"ERROR setting regvalue %08lx %ls : %ls\n", hive, szPath, szKey);
		ShowLastError(temp);
		return false;
	}
	RegCloseKey(hk);

	return true;
}


	//check if the Serial Port is configured
	//  if not then return false, else return true
bool IsSerialPortConfigured()
{
	HKEY hKey;
	DWORD dwDisposition;

	//if this is a 750 then we don't configure the port until after we have a handle to it
	if (CheckDeviceType (L"Palm Treo 750"))
		return true;

	if (ERROR_SUCCESS == RegCreateKeyEx(HKEY_LOCAL_MACHINE, TEXT("Drivers\\BuiltIn\\SerialIR"), 0, TEXT(""), 0, KEY_WRITE, 0, &hKey, &dwDisposition))
	{
		DWORD regKeyReadBufferLength = sizeof(DWORD);
		DWORD regKeyReadBuffer = 0;
		if (ERROR_SUCCESS == RegQueryValueEx(hKey, TEXT("IRConnected"), 0, NULL, (BYTE*)(&regKeyReadBuffer), &regKeyReadBufferLength))
		{
			if (1 == regKeyReadBuffer) 
				return false;
			else
				return true;
		} 	
	} 

		::MessageBox(NULL,L"Could not create/open registry key.",L"Error",MB_OK);
		exit(0);
		return false;
}


bool ConfigureSerialPort()
{
	//if this is a 750 then we don't configure the port until after we have the handle to it
	if (CheckDeviceType (L"Palm Treo 750"))
	  return true;

	//************one time config for 700w & 700wx devices************************
	//
	//  - it will make set the correct settings in the registry
	//    and then reset the device.
	bool bSuccess = false;
	HKEY hKey;
	DWORD dwDisposition;	
	DWORD dwValue = 0;


	// The comport is shared between the ir and cradle.
	// set the reg value to use the cradle.
	if ( ! SetRegistryDWORD(HKEY_LOCAL_MACHINE, _T("Software\\Microsoft\\Obex"), TEXT("IsEnabled"), 0) ) {
		return bSuccess;
	}

	if (ERROR_SUCCESS == RegCreateKeyEx(HKEY_LOCAL_MACHINE, TEXT("Drivers\\BuiltIn\\SerialIR"), 0, TEXT(""), 0, KEY_WRITE, 0, &hKey, &dwDisposition))
	{
				bSuccess = (ERROR_SUCCESS == RegSetValueEx(hKey, TEXT("IRConnected"), 0, REG_DWORD, (BYTE*)(&dwValue), sizeof(dwValue)));
				RegFlushKey(hKey);
				RegCloseKey(hKey);
				KernelIoControl(IOCTL_HAL_REBOOT, NULL, 0, NULL, 0, NULL);
	}

	//*************end of one time config***************************
	return false;
}



//open the serial port (com2)
bool OpenCommPort()
{
	DCB dcb;
	BOOL fSuccess;
	wchar_t *pcCommPort = L"COM2:";

	//if the device is a 750 then use COM1
	if (CheckDeviceType (L"Palm Treo 750"))
		pcCommPort = L"COM1:";

	hCom = CreateFile(pcCommPort,
		GENERIC_READ | GENERIC_WRITE,
		0,    // must be opened with exclusive-access
		NULL, // no security attributes
		OPEN_EXISTING, // must use OPEN_EXISTING
		0,    // not overlapped I/O
		NULL  // hTemplate must be NULL for comm devices
		);

	DWORD error = ::GetLastError();
	if (hCom == INVALID_HANDLE_VALUE)
	{
		ShowLastError(L"Could not create the file");
		return false;
	}

	//if the device is a 750 then this is the critical call
	if (CheckDeviceType (L"Palm Treo 750"))
		TurnOnSerial(hCom, 1);

	// Build on the current configuration, and skip setting the size
	// of the input and output buffers with SetupComm.
	fSuccess = GetCommState(hCom, &dcb);

	if (!fSuccess)
	{
		ShowLastError(L"Could not get the control settings");
		return false;
	}

	// These are the connection settings
	dcb.BaudRate = CBR_57600 ;     // set the baud rate
	dcb.fParity = FALSE;
	dcb.fNull = FALSE;
	dcb.ByteSize = 8;             // data size, xmit, and rcv
	dcb.Parity = NOPARITY;        // no parity bit
	dcb.StopBits = ONESTOPBIT;    // one stop bit

	fSuccess = SetCommState(hCom, &dcb);


	COMMTIMEOUTS cto;
	cto.ReadIntervalTimeout = 1000;
	cto.ReadTotalTimeoutMultiplier = 40;
	cto.ReadTotalTimeoutConstant = 50;
	cto.WriteTotalTimeoutMultiplier = 0;
	cto.WriteTotalTimeoutConstant = 0;

	SetCommTimeouts(hCom, &cto);

	if (!fSuccess)
	{
		ShowLastError(L"Could not set timeout parameters");
		return false;
	}

	return true;
}

//close the port
bool CloseCommPort()
{
	//if the device is a 750 then turn off serial
	if ((hCom != INVALID_HANDLE_VALUE) && CheckDeviceType (L"Palm Treo 750"))
		TurnOnSerial(hCom, 0);

	CloseHandle(hCom);
	hCom = INVALID_HANDLE_VALUE;
	return true;
}


//send the data passed in
unsigned int SerialCommsSend(unsigned char * pData, unsigned int numberOfBytesToWrite)
{
	unsigned long nNumBytesWritten;
	unsigned int rc;

	rc = WriteFile(hCom, pData, numberOfBytesToWrite, &nNumBytesWritten, NULL);
	if(!rc)
	{
		ShowLastError(L"write failed");
		return 0;
	}

	return nNumBytesWritten;
}



//configure the IR Port to be used
bool ConfigureIRPort()
{
	bool bSuccess = false;
	HKEY hKey;
	DWORD dwDisposition;	
	DWORD dwValue = 1;
					
		//if this is a 750 then we don't need to do the below settings
	if (CheckDeviceType (L"Palm Treo 750"))
		return true;

	//************one time config************************
	//
	//  - it will set the correct settings in the registry for the IR port to be configured
	//    and then reset the device.

	// The comport is shared between the ir and cradle.
	// set the reg value to use IR.
	if ( ! SetRegistryDWORD(HKEY_LOCAL_MACHINE, _T("Software\\Microsoft\\Obex"), TEXT("IsEnabled"), 1) ) {
		return bSuccess;
	}

	if (ERROR_SUCCESS == RegCreateKeyEx(HKEY_LOCAL_MACHINE, TEXT("Drivers\\BuiltIn\\SerialIR"), 0, TEXT(""), 0, KEY_WRITE, 0, &hKey, &dwDisposition))
	{
				bSuccess = (ERROR_SUCCESS == RegSetValueEx(hKey, TEXT("IRConnected"), 0, REG_DWORD, (BYTE*)(&dwValue), sizeof(dwValue)));
				RegFlushKey(hKey);
				RegCloseKey(hKey);
				// FIXME: Need some kind of friendly screen to warn of reboot.
				KernelIoControl(IOCTL_HAL_REBOOT, NULL, 0, NULL, 0, NULL);
	}
	//*************end of one time config***************************

	return false;
}
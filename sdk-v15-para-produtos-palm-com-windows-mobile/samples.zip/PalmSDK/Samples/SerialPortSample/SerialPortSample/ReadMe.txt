The code in this sample application demonstrates the API for using the serial port on the Treo 700w, Treo 700wx and Treo 750v.

Version History:
1.0.1: Minor UI Changes
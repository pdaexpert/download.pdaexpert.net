#include "DeviceDiffRegCheck.h"

// Palm device version string
TCHAR tszSWVersionString[1024];

void CheckSoftwareVersion()
{
	//grab the value of the version string registry entry
	HRESULT hr = RegistryGetString(PALM_SWVERSIONSTRING_ROOT, PALM_SWVERSIONSTRING_PATH,
		PALM_SWVERSIONSTRING_VALUE, tszSWVersionString,
		sizeof(tszSWVersionString));

	//if the registry entry doesn't exist then the ROM is
	//one of the first 2 released versions(Verizon) which didn't have it
	if (hr != S_OK)
	{
		TCHAR OEMString[100];
		SystemParametersInfo(SPI_GETOEMINFO, 100, OEMString, 0 );

		//make sure it's a Palm Treo 700w
		if (wcscmp(OEMString,L"Palm Treo 700w") == 0)
		{
			OSVERSIONINFO ovi;
			GetVersionEx(&ovi);

			//Now check whether it's the original 700w ROM or the update
			if (ovi.dwBuildNumber == PALM_MSFTBUILDNUM700W)
			{
				wcscpy(tszSWVersionString,L"Treo700W-1.02-VZN");
			}
			else if (ovi.dwBuildNumber == PALM_MSFTBUILDNUM700WMAINTENANCE)
			{
				wcscpy(tszSWVersionString,L"Treo700W-1.10-VZN");
			}
		}
		else
			wcscpy(tszSWVersionString,L"Unknown Version");

	}
}

void DisplaySoftwareVersion(HDC hdc)
{
  TCHAR tszHardware[1024];
  TCHAR tszCarrier[1024];
  TCHAR tszRelease[1024];
  RECT rect;

  CheckSoftwareVersion();

  if (wcscmp(tszSWVersionString, L"Unknown Version")==0)
  {
	  RECT rect;
	  ::SetRect(&rect,10,50,150,100);
	  DrawText(hdc,tszSWVersionString,-1,&rect,DT_LEFT);
	  return;
  }

  //seperate the version string
  wcscpy(tszHardware, wcstok(tszSWVersionString,L"-"));
  wcscpy(tszRelease, wcstok(NULL,L"-"));
  wcscpy(tszCarrier, wcstok(NULL,L"-"));


  //display the information
  TCHAR tszDisplayString[2*1024];

  ::SetRect(&rect,10,40,150,60);
  wcscpy(tszDisplayString,L"Hardware: ");
  wcscat(tszDisplayString,tszHardware);
  DrawText(hdc,tszDisplayString,-1,&rect,DT_LEFT);

  ::SetRect(&rect,10,60,150,80);
  wcscpy(tszDisplayString,L"Release: ");
  wcscat(tszDisplayString,tszRelease);
  DrawText(hdc,tszDisplayString,-1,&rect,DT_LEFT);

  ::SetRect(&rect,10,80,150,100);
  wcscpy(tszDisplayString,L"Carrier: ");
  wcscat(tszDisplayString,tszCarrier);
  DrawText(hdc,tszDisplayString,-1,&rect,DT_LEFT);

}
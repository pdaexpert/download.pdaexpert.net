/*! \file DeviceDiffRegCheck.h:  revision 1.0
	\brief Device differentiation sample demonstrating the use of our registry entry
	which allows the differentiation of our devices and system images.

	 Copyright 2006 Palm Inc., All Rights Reserved.
*/

#pragma once
#include "resourceppc.h"
#include "stdafx.h"
#include <windows.h>
#include <commctrl.h>
#include <regext.h>
#include <snapi.h>


#define PALM_SWVERSIONSTRING_ROOT HKEY_LOCAL_MACHINE

/**
 * Path to Palm device differentiation registry key
 */
#define PALM_SWVERSIONSTRING_PATH L"Software\\Palm\\Version"

/**
 * Palm device differentiation registry key
 */
#define PALM_SWVERSIONSTRING_VALUE L"SoftwareVersionString"


/**
 * Microsoft build number used on the original Verizon Treo 700w ROM
 */
#define PALM_MSFTBUILDNUM700W 1700

/**
 * Microsoft build number used on the first maintenance release for the Verizon Treo 700w ROM
 */
#define PALM_MSFTBUILDNUM700WMAINTENANCE 195


/*! \fn void CheckSoftwareVersion()
    \brief Checks the System Image version.

	Uses the above defined registry entry to retrieve the device's system image version.
*/
void CheckSoftwareVersion();


/*! \fn void DisplaySoftwareVersion(HDC hdc)
    \brief Populates speed dial database entries onto main window listbox.

	Writes the device's system image version to the device context passed in.
*/
void DisplaySoftwareVersion(HDC hdc);


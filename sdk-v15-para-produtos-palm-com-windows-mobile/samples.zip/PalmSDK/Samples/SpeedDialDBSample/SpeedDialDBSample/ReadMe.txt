The code in this sample application demonstrates the use WinMobile Treo Speed Dial API to access and use the Speed Dial functionality added by Palm on top of Windows Mobile on Palm Treos.

Version History:
1.0.1 - Fixing cosmetic UI issues.
1.0.2 - Fixing cosmetic UI issues.
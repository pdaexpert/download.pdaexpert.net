//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SpeedDialDBSampleppc.rc
//
#define IDS_APP_TITLE                   1
#define IDOK                            1
#define IDC_SPEEDDIALDBSAMPLE           2
#define IDCANCEL                        2
#define IDI_SPEEDDIALDBSAMPLE           101
#define IDR_MENU                        102
#define IDS_OK                          103
#define IDS_HELP                        104
#define IDD_ABOUTBOX                    105
#define IDD_SPEED_DIAL_DIALOG           129
#define IDD_PHONE_PROPERTIES            131
#define IDC_STATIC_1                    201
#define IDC_STATIC_2                    202
#define IDC_STATIC_3                    203
#define IDC_ADD                         1000
#define IDC_GET                         1001
#define IDC_REMOVE                      1002
#define IDC_EDIT                        1003
#define IDC_SWAP                        1004
#define IDC_RADIO_QUICK_KEY             1005
#define IDC_RADIO_PHONE_NUM             1006
#define IDC_QUICK_KEY                   1007
#define IDC_PHONE_NUM                   1008
#define IDC_CONTACT                     1009
#define IDC_PHONE_LIST                  1010
#define IDC_PROPERTY                    1010
#define IDC_LABEL                       1011
#define IDC_RADIO_VOICEMAIL             1012
#define IDC_STATIC4                     1013
#define IDC_PREVIOUS                    1014
#define IDC_SAVE                        1015
#define IDC_PLAY                        1016
#define IDC_DELETE                      1017
#define IDC_NEXT                        1018
#define IDC_REPLAY                      1019
#define IDC_STATIC5                     1020
#define IDC_STATIC6                     1021
#define IDC_STATIC8                     1022
#define IDC_STATIC9                     1023
#define IDC_STATIC10                    1024
#define IDC_RADIO_CONTACTLINK           1025
#define IDC_STATIC_CONTACT              1026
#define IDC_STATIC_PROPERTYID           1027
#define IDM_OK                          40000
#define IDM_HELP                        40001
#define IDM_HELP_ABOUT                  40002
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif

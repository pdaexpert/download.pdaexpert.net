/*! \file SpeedDialDBApiCalls.h:  revision 1.0
	\brief Speed Dial Database api sample demonstrating the use of the available functions in
	this api.  SpeedDialDBApiCalls.cpp is where all SpeedDialDB api calls are made and
	SpeedDialDBSample.cpp is standard Windows code.

	SpeedDialDB.h is needed to compile this project.


	 Copyright 2005 Palm Inc., All Rights Reserved.
*/

#pragma once
#include "resourceppc.h"
#include "stdafx.h"
#include <windows.h>
#include <commctrl.h>
#include "SpeedDialDB.h"




/*! \fn INT_PTR CALLBACK MainDialog(HWND, UINT, WPARAM, LPARAM)
    \brief Message handler for main window.

	Handles all button presses on main window and makes SpeedDialDB api calls.
	Delegates responsibility of filling in SpeedDialInfo structure to other
	dialog procedures.
*/
INT_PTR CALLBACK	MainDialog(HWND, UINT, WPARAM, LPARAM);


/*! \fn void PopulatePhoneListBox(HWND hDlg)
    \brief Populates speed dial database entries onto main window listbox.

	Uses relevant SpeedDialDB api calls to retrieve all speed dial database entries
	and populate them to the main window listbox.
*/
void PopulatePhoneListBox(HWND hDlg);



/*! \fn INT_PTR CALLBACK Add(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    \brief Message handler for dialog box which fills in a SpeedDialInfo structure to
	\be added to the speed dial database.

	If OK is pressed then a speed dial entry is created using the information that was
	entered on this dialog.
*/
INT_PTR CALLBACK Add(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);



/*! \fn INT_PTR CALLBACK Edit(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    \brief Message handler for dialog box which is used to alter a SpeedDialInfo structure
	\given to it.

	If OK is pressed then the speed dial entry which corresponds to the SpeedDialInfo
	structure passed into this dialog is edited with the new values.
*/
INT_PTR CALLBACK Edit(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);



/*! \fn INT_PTR CALLBACK Show(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
    \brief Message handler for dialog box which is used to show the values in
	\a SpeedDialInfo structure given to it.
*/
INT_PTR CALLBACK Show(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);


/*! \fn void HideVoiceMailButtons(HWND hDlg)
    \brief Hides the voice mail edit boxes.
*/
void HideVoiceMailButtons(HWND hDlg);


/*! \fn void HideContactIDButtons(HWND hDlg)
    \brief Hides the contact edit boxes.
*/
void HideContactIDButtons(HWND hDlg);
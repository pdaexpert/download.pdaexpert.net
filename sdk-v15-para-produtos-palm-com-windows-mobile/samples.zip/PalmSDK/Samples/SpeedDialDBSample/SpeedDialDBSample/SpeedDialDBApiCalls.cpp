#include "SpeedDialDBSample.h"

// Global Variables:
extern HINSTANCE			g_hInst;			// current instance

// Message handler for IDD_SPEED_DIAL_DIALOG box.
INT_PTR CALLBACK MainDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            {
				EnableWindow(GetDlgItem(hDlg,IDC_QUICK_KEY),true);
				EnableWindow(GetDlgItem(hDlg,IDC_PHONE_NUM),false);
				CheckDlgButton(hDlg,IDC_RADIO_QUICK_KEY,BST_CHECKED);

				//enter all the speed dials into the list box
				PopulatePhoneListBox(hDlg);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK)
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }		
			//only enable the checked item
			else if (LOWORD(wParam) == IDC_RADIO_QUICK_KEY)
			{
				EnableWindow(GetDlgItem(hDlg,IDC_PHONE_NUM),false);
				EnableWindow(GetDlgItem(hDlg,IDC_QUICK_KEY),true);
			}	

			else if (LOWORD(wParam) == IDC_RADIO_PHONE_NUM)
			{
				EnableWindow(GetDlgItem(hDlg,IDC_QUICK_KEY),false);
				EnableWindow(GetDlgItem(hDlg,IDC_PHONE_NUM),true);
			}

			//get the current phone entry settings
			else if (LOWORD(wParam) == IDC_GET)
			{
				SPEEDDIALINFO sdi;
				wchar_t PhoneID[MAX_NAMELEN];
				memset(PhoneID,0,10*sizeof(wchar_t));

				unsigned int QuickChecked = BST_INDETERMINATE;
			    QuickChecked = IsDlgButtonChecked(hDlg,IDC_RADIO_QUICK_KEY);

				//if it's a quick key search
				if (QuickChecked == BST_CHECKED)
				{
					GetDlgItemText(hDlg,IDC_QUICK_KEY,PhoneID,MAX_NAMELEN);
					//<palmapi>
					GetSpeedDialRecordByQuickKey(PhoneID[0], &sdi);
				}
				//if it's a phone number search
				else if (QuickChecked == BST_UNCHECKED)
				{
					GetDlgItemText(hDlg,IDC_PHONE_NUM,PhoneID,MAX_NAMELEN);
					//<palmapi>
					GetSpeedDialRecordByPhoneNumber(PhoneID, &sdi);
				}
				else
					return TRUE;

				//display the phone entries properties
				DialogBoxParam(g_hInst, (LPCTSTR)IDD_PHONE_PROPERTIES, hDlg, Show, (LPARAM)&sdi);
			}

			//add a new entry
			else if (LOWORD(wParam) == IDC_ADD)
			{
				SPEEDDIALINFO sdi;
				SpeedDialErrorCode error;

				if (DialogBoxParam(g_hInst, (LPCTSTR)IDD_PHONE_PROPERTIES, hDlg, Add, (LPARAM)&sdi))
				{
					sdi.nFlags = FLAGS_DELETEABLE;
					sdi.nType = TYPE_TEXT;
					
					//<palmapi>
					error = NewSpeedDialRecord (&sdi);
				}

				
				//enter/refresh all the speed dials into the list box
				PopulatePhoneListBox(hDlg);

				//refresh what's shown on the today screen
				//Posting this message will cause all today view pluggins to refresh - rather than just the speed dial pluggin
				PostMessage(FindWindow(TEXT("DesktopExplorerWindow"), NULL), WM_WININICHANGE, 0xF2, NULL);
                return TRUE;
			}

			//edit an existing entry
			else if (LOWORD(wParam) == IDC_EDIT)
			{	
				int index[2];
				HWND PhoneListBox = GetDlgItem(hDlg,IDC_PHONE_LIST);

				//they can only select 1 item
				if (SendMessage(PhoneListBox, LB_GETSELITEMS , 2,(LPARAM)index) != 1)
				{
					MessageBox(hDlg,TEXT("You must select 1 and only 1 speed dial entry first"),TEXT("Try again"),MB_OK);
					return TRUE;
				}

				HANDLE pDBHandle;
				//open the speed dial database
					//<palmapi>
				SpeedDialErrorCode error = OpenSpeedDialDB(sddbOpenAccessRead, &pDBHandle);
				SPEEDDIALINFO sdi;
				//get the entry they chose
					//<palmapi>
				error = GetSpeedDialRecordByIndex(pDBHandle, (UINT32) index[0], &sdi);

				//display it's properties
				if (DialogBoxParam(g_hInst, (LPCTSTR)IDD_PHONE_PROPERTIES, hDlg, Edit,(LPARAM)&sdi))
				{
					//<palmapi>
					ReplaceSpeedDialRecord(pDBHandle,index[0],&sdi);
				}

				//close the speed dial database
					//<palmapi>
				CloseSpeedDialDB(pDBHandle);

				//enter/refresh all the speed dials into the list box
				PopulatePhoneListBox(hDlg);		
				
				//refresh what's shown on the today screen
				//Posting this message will cause all today view pluggins to refresh - rather than just the speed dial pluggin
				PostMessage(FindWindow(TEXT("DesktopExplorerWindow"), NULL), WM_WININICHANGE, 0xF2, NULL);
     
				return TRUE;
			}

			//swap 2 entries
			else if (LOWORD(wParam) == IDC_SWAP)
			{
				int index[3];

				HWND PhoneListBox = GetDlgItem(hDlg,IDC_PHONE_LIST);

				//they must pick 2 entries
				if (SendMessage(PhoneListBox, LB_GETSELITEMS , 3,(LPARAM)index) != 2)
				{
					MessageBox(hDlg,TEXT("You must select 2 and only 2 speed dial entries"),TEXT("Try again"),MB_OK);
					return TRUE;
				}

				//swap the entries
					//<palmapi>
				SpeedDialErrorCode error = SwapSpeedDialRecordPositions(index[0],index[1]);

				//enter all the speed dials into the list box
				PopulatePhoneListBox(hDlg);

				//refresh what's shown on the today screen
				//Posting this message will cause all today view pluggins to refresh - rather than just the speed dial pluggin
				PostMessage(FindWindow(TEXT("DesktopExplorerWindow"), NULL), WM_WININICHANGE, 0xF2, NULL);

                return TRUE;
			}
			
			//remove an entry
			else if (LOWORD(wParam) == IDC_REMOVE)
			{
				int index[2];

				HWND PhoneListBox = GetDlgItem(hDlg,IDC_PHONE_LIST);

				//they must choose 1 entry only
				if (SendMessage(PhoneListBox, LB_GETSELITEMS , 2,(LPARAM)index) != 1)
				{
					MessageBox(hDlg,TEXT("You must select 1 and only 1 speed dial entry first"),TEXT("Try again"),MB_OK);
					return TRUE;
				}

				//remove it
					//<palmapi>
				SpeedDialErrorCode error = RemoveSpeedDialRecord(index[0]);

				//enter/refresh all the speed dials into the list box
				PopulatePhoneListBox(hDlg);

				//refresh what's shown on the today screen
				//Posting this message will cause all today view pluggins to refresh - rather than just the speed dial pluggin
				PostMessage(FindWindow(TEXT("DesktopExplorerWindow"), NULL), WM_WININICHANGE, 0xF2, NULL);

                return TRUE;
			}


			break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;


    }
    return (INT_PTR)FALSE;
}


//update the phone entry list box with the current speed dial database contents
void PopulatePhoneListBox(HWND hDlg)
{
   UINT32 numberOfRecords;
   HANDLE pDBHandle;
					//<palmapi>
   SpeedDialErrorCode error = OpenSpeedDialDB(sddbOpenAccessRead, &pDBHandle);
					//<palmapi>
   error = GetNumberOfSpeedDialRecords(pDBHandle, &numberOfRecords);

   HWND PhoneListBox = GetDlgItem(hDlg,IDC_PHONE_LIST);
   SendMessage(PhoneListBox, LB_RESETCONTENT, 0, 0);

   for (int index=0;index<(int)numberOfRecords;index++)
   {
	   SPEEDDIALINFO sdi;
					//<palmapi>
	   error = GetSpeedDialRecordByIndex(pDBHandle, (UINT32) index, &sdi);
	   SendMessage(PhoneListBox, LB_ADDSTRING, 0,(LPARAM)(LPCTSTR)sdi.szLabel); 
   }

					//<palmapi>
   CloseSpeedDialDB(pDBHandle);
}




INT_PTR CALLBACK Add(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static SPEEDDIALINFO * sdi = NULL;

    switch (message)
    {
        case WM_INITDIALOG:
            {
				SetWindowText(hDlg,L"Add a phone entry");	
				
				sdi = (SPEEDDIALINFO *)lParam;

            {
                // Change the Close Button to an OK Button and Maximize the dialog.
                SHINITDLGINFO shidi;
                shidi.dwMask = SHIDIM_FLAGS;
                shidi.dwFlags = SHIDIF_DONEBUTTON | SHIDIF_SIPDOWN | SHIDIF_SIZEDLGFULLSCREEN | SHIDIF_EMPTYMENU;
                shidi.hDlg = hDlg;
                SHInitDialog(&shidi);
            }

				//no adding a voicemail, so don't even show the boxes
				HideVoiceMailButtons(hDlg);
				HideContactIDButtons(hDlg);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK)
            {		    
				GetDlgItemText(hDlg,IDC_LABEL,sdi->szLabel,MAX_NAMELEN+1);
				GetDlgItemText(hDlg,IDC_PHONE_NUM,sdi->szNumber,MAX_NUMBERLEN+1);
				GetDlgItemText(hDlg,IDC_QUICK_KEY,sdi->szQuickKey,MAX_QUICKKEYLEN+1);

				//if they link to a contact
				if (BST_CHECKED ==IsDlgButtonChecked(hDlg,IDC_RADIO_CONTACTLINK))
				{
					GetDlgItemText(hDlg,IDC_CONTACT,(LPWSTR)sdi->oidContactID,MAX_NUMBERLEN+1);
					GetDlgItemText(hDlg,IDC_PROPERTY,(LPWSTR)sdi->propID,MAX_QUICKKEYLEN+1);
				}
						
                EndDialog(hDlg, true);
                return TRUE;
			}
			else if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, false);
				return TRUE;
			}


    }
    return (INT_PTR)FALSE;
}



INT_PTR CALLBACK Edit(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static SPEEDDIALINFO * sdi = NULL;

    switch (message)
    {
        case WM_INITDIALOG:
            {
				SetWindowText(hDlg,L"Edit a phone entry");

            {
                // Change the Close Button to an OK Button and Maximize the dialog.
                SHINITDLGINFO shidi;
                shidi.dwMask = SHIDIM_FLAGS;
                shidi.dwFlags = SHIDIF_DONEBUTTON | SHIDIF_SIPDOWN | SHIDIF_SIZEDLGFULLSCREEN | SHIDIF_EMPTYMENU;
                shidi.hDlg = hDlg;
                SHInitDialog(&shidi);
            }

				sdi = (SPEEDDIALINFO *)lParam;
				SetDlgItemText(hDlg,IDC_LABEL,sdi->szLabel);
				SetDlgItemText(hDlg,IDC_PHONE_NUM,sdi->szNumber);
				SetDlgItemText(hDlg,IDC_QUICK_KEY,sdi->szQuickKey);

				//no editing allowed on voicemail buttons
				EnableWindow(GetDlgItem(hDlg,IDC_PREVIOUS),false);
				EnableWindow(GetDlgItem(hDlg,IDC_SAVE),false);
				EnableWindow(GetDlgItem(hDlg,IDC_PLAY),false);
				EnableWindow(GetDlgItem(hDlg,IDC_DELETE),false);
				EnableWindow(GetDlgItem(hDlg,IDC_NEXT),false);
				EnableWindow(GetDlgItem(hDlg,IDC_REPLAY),false);
				EnableWindow(GetDlgItem(hDlg,IDC_RADIO_VOICEMAIL),false);

				if (sdi->nFlags & FLAGS_VOICEMAIL)
				{
					CheckDlgButton(hDlg,IDC_RADIO_VOICEMAIL,BST_CHECKED);
				}
				
				HideContactIDButtons(hDlg);

            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK)
            {		    
				wcscpy(sdi->szLabel,L"");
				wcscpy(sdi->szNumber,L"");
				wcscpy(sdi->szQuickKey,L"");
				GetDlgItemText(hDlg,IDC_LABEL,sdi->szLabel,MAX_NAMELEN+1);
				GetDlgItemText(hDlg,IDC_PHONE_NUM,sdi->szNumber,MAX_NUMBERLEN+1);
				GetDlgItemText(hDlg,IDC_QUICK_KEY,sdi->szQuickKey,MAX_QUICKKEYLEN+1);

                EndDialog(hDlg, true);
                return TRUE;
			}
			else if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, false);
				return TRUE;
			}


    }
    return (INT_PTR)FALSE;
}



INT_PTR CALLBACK Show(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static SPEEDDIALINFO * sdi;

    switch (message)
    {
        case WM_INITDIALOG:
            {
				SetWindowText(hDlg,L"Showing a phone entry");

            {
                // Change the Close Button to an OK Button and Maximize the dialog.
                SHINITDLGINFO shidi;
                shidi.dwMask = SHIDIM_FLAGS;
                shidi.dwFlags = SHIDIF_DONEBUTTON | SHIDIF_SIPDOWN | SHIDIF_SIZEDLGFULLSCREEN | SHIDIF_EMPTYMENU;
                shidi.hDlg = hDlg;
                SHInitDialog(&shidi);
            }

				//no editing allowed here
				EnableWindow(GetDlgItem(hDlg,IDC_LABEL),false);
				EnableWindow(GetDlgItem(hDlg,IDC_PHONE_NUM),false);
				EnableWindow(GetDlgItem(hDlg,IDC_QUICK_KEY),false);
				EnableWindow(GetDlgItem(hDlg,IDC_PREVIOUS),false);
				EnableWindow(GetDlgItem(hDlg,IDC_SAVE),false);
				EnableWindow(GetDlgItem(hDlg,IDC_PLAY),false);
				EnableWindow(GetDlgItem(hDlg,IDC_DELETE),false);
				EnableWindow(GetDlgItem(hDlg,IDC_NEXT),false);
				EnableWindow(GetDlgItem(hDlg,IDC_REPLAY),false);
				EnableWindow(GetDlgItem(hDlg,IDC_RADIO_VOICEMAIL),false);

				//set the information
				sdi = (SPEEDDIALINFO *)lParam;
				SetDlgItemText(hDlg,IDC_LABEL,sdi->szLabel);
				SetDlgItemText(hDlg,IDC_PHONE_NUM,sdi->szNumber);
				SetDlgItemText(hDlg,IDC_QUICK_KEY,sdi->szQuickKey);

				if (sdi->nFlags & FLAGS_VOICEMAIL)
				{
					CheckDlgButton(hDlg,IDC_RADIO_VOICEMAIL,BST_CHECKED);

					SetDlgItemText(hDlg,IDC_PREVIOUS,sdi->szBtnPrev);
					SetDlgItemText(hDlg,IDC_SAVE,sdi->szBtnSave);
					SetDlgItemText(hDlg,IDC_PLAY,sdi->szBtnPlay);
					SetDlgItemText(hDlg,IDC_DELETE,sdi->szBtnDelete);
					SetDlgItemText(hDlg,IDC_NEXT,sdi->szBtnNext);
					SetDlgItemText(hDlg,IDC_REPLAY,sdi->szBtnReplay);
				}
				else
					CheckDlgButton(hDlg,IDC_RADIO_VOICEMAIL,BST_UNCHECKED);
	
				HideContactIDButtons(hDlg);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK)
            {
                EndDialog(hDlg, true);
                return TRUE;
            }	
			else if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, false);
				return TRUE;
			}


    }
    return (INT_PTR)FALSE;
}




void HideVoiceMailButtons(HWND hDlg)
{
	HWND SubDlg = GetDlgItem(hDlg,IDC_PREVIOUS);
	ShowWindow(SubDlg,false);
	SubDlg = GetDlgItem(hDlg,IDC_STATIC4);
	ShowWindow(SubDlg,false);

	SubDlg = GetDlgItem(hDlg,IDC_SAVE);
	ShowWindow(SubDlg,false);
	SubDlg = GetDlgItem(hDlg,IDC_STATIC5);
	ShowWindow(SubDlg,false);

	SubDlg = GetDlgItem(hDlg,IDC_PLAY);
	ShowWindow(SubDlg,false);
	SubDlg = GetDlgItem(hDlg,IDC_STATIC6);
	ShowWindow(SubDlg,false);

	SubDlg = GetDlgItem(hDlg,IDC_DELETE);
	ShowWindow(SubDlg,false);
	SubDlg = GetDlgItem(hDlg,IDC_STATIC8);
	ShowWindow(SubDlg,false);

	SubDlg = GetDlgItem(hDlg,IDC_NEXT);
	ShowWindow(SubDlg,false);
	SubDlg = GetDlgItem(hDlg,IDC_STATIC9);
	ShowWindow(SubDlg,false);

	SubDlg = GetDlgItem(hDlg,IDC_REPLAY);
	ShowWindow(SubDlg,false);
	SubDlg = GetDlgItem(hDlg,IDC_STATIC10);
	ShowWindow(SubDlg,false);

	SubDlg = GetDlgItem(hDlg,IDC_RADIO_VOICEMAIL);
	ShowWindow(SubDlg,false);
}


void HideContactIDButtons(HWND hDlg)
{
	HWND SubDlg = GetDlgItem(hDlg,IDC_RADIO_CONTACTLINK);
	ShowWindow(SubDlg,false);				
	SubDlg = GetDlgItem(hDlg,IDC_STATIC_CONTACT);
	ShowWindow(SubDlg,false);					
	SubDlg = GetDlgItem(hDlg,IDC_CONTACT);
	ShowWindow(SubDlg,false);	
	SubDlg = GetDlgItem(hDlg,IDC_STATIC_PROPERTYID);
	ShowWindow(SubDlg,false);
	SubDlg = GetDlgItem(hDlg,IDC_PROPERTY);
	ShowWindow(SubDlg,false);
}

/*! \file ClassDetectionHelper.h:  revision 1.0
	\brief Class detection sample demonstrating peripheral class detection.
	This sample will display the status of any peripherals connected to the Multiconnector port on a Treo 750v.  ClassDetectionHelper.cpp is where all the necessary definitions and helper functions are
	and	ClassDetection.cpp is standard Windows code.

	 Copyright 2005 Palm Inc., All Rights Reserved.
*/

#pragma once
#include "stdafx.h"
#include "ClassDetection.h"
#include <windows.h>
#include <commctrl.h>
#include <regext.h>


enum NotifType
{
      DeviceDetected = 0,
      PeripheralID
};


/**
 * Detach code
 */
#define	MULTICONN_DETACH				0x0000

/**
 * Attach code
 */
#define MULTICONN_ATTACH				0x0001


/**
 * Treo Wired Car Kit
 */
#define	MULTICONN_CLASSID_CARKIT			0x0001
/**
 * Serial Peripheral
 */
#define MULTICONN_CLASSID_SERIAL			0x0003
/**
 * Smart serial
 */
#define	MULTICONN_CLASSID_SMART_SERIAL		0x0007

/**
 * 2 types of registry notifications
 */
#define MAX_NOTIF 2


/**
 * Path to registry entry for peripheral detection status
 */
#define PALM_SWPERIPHDETECTSTRING_PATH L"\\System\\State\\Athena"
/**
 * Peripheral Type value
 */
#define PALM_SWPERIPHTYPESTRING_VALUE L"DeviceClass"
/**
 * Peripheral ID value
 */
#define PALM_SWPERIPHIDSTRING_VALUE L"PeripheralID"





/**
 * Top window handle
 */
extern HWND MainWindow;
/**
 * Handle to the registry notifiers
 */
extern HREGNOTIFY g_hRegNotify[ MAX_NOTIF ];
/**
 * Peripheral Class string
 */
extern wchar_t wcDeviceClass[100];
/**
 * Peripheral ID string
 */
extern wchar_t wcPeripheralID[100];



/*! \fn void RegisterForClassDetectionNotifications();
    \brief Sets up the notification callbacks for when a peripheral is detected

	First it checks if a peripheral is inserted and writes it out if it is.  It also checks if there is a
	peripheral ID available (only smart serial devices give this) and writes it out if it is.  Finally, it also
	registers the callback function so we'll be notified in the event the above changes.
*/
void RegisterForClassDetectionNotifications();



/*! \fn void GetDevice(DWORD dwDeviceClass)
    \brief Writes out the type of peripheral

	Looks through a list of the supported devices and writes out which it is.
*/
void GetDevice(DWORD dwDeviceClass);



/*! \fn void GetPeripheralID(DWORD dwPeripheralID)
    \brief Writes out the peripheral ID (only for smart serial)

	This is only called when a smart serial device is connected and has sent a 4-byte peripheral ID.
	The value will be set to 0 when the device is removed
*/
void GetPeripheralID(DWORD dwPeripheralID);



/*! \fn void ClassDetectionCallback(HREGNOTIFY hNotify, DWORD dwUserData, const PBYTE pData, const UINT cbData)
    \brief The call-back function for Registry Notifications.

	This function is called when a peripheral is inserted, removed, or when a smart serial
	device has sent a 4-byte peripheral ID
*/
void ClassDetectionCallback(HREGNOTIFY hNotify, DWORD dwUserData, const PBYTE pData, const UINT cbData);


/*! \fn void  CloseAllNotifications ()
    \brief Closes the registry callback notifications

	This function is called when the application shuts down and it will close the handles to the
	notification requests
*/
void  CloseAllNotifications ();
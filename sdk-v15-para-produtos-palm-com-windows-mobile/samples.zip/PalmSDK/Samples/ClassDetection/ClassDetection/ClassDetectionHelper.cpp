#include "ClassDetectionHelper.h"

// Global Variables:
 HWND MainWindow = NULL;  //top windows handle
 HREGNOTIFY g_hRegNotify[ MAX_NOTIF ]; //handle to the registry notifiers
 wchar_t wcDeviceClass[100]; //Peripheral Class string
 wchar_t wcPeripheralID[100]; //Peripheral ID string


 void RegisterForClassDetectionNotifications()
 {
	 HKEY hKey;
	 DWORD type,size,dwDeviceClass, dwPeripheralID;

	 //check if something is already detected
	 if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, PALM_SWPERIPHDETECTSTRING_PATH, 0, 0, &hKey))
	 {
		 //this is the peripheral type
		 if (ERROR_SUCCESS == RegQueryValueEx(hKey,PALM_SWPERIPHTYPESTRING_VALUE,NULL,&type,(BYTE*)(&dwDeviceClass),&size))
		 {
			 //check if there is a device plugged in
			 GetDevice(dwDeviceClass);
			 RegistryNotifyCallback(hKey,NULL,PALM_SWPERIPHTYPESTRING_VALUE,ClassDetectionCallback,DeviceDetected,NULL,&g_hRegNotify[ DeviceDetected ]);

		 }

		 //this is the peripheral ID which is sent from a smart serial peripheral
		 if (ERROR_SUCCESS == RegQueryValueEx(hKey,PALM_SWPERIPHIDSTRING_VALUE,NULL,&type,(BYTE*)(&dwPeripheralID),&size))
		 {
			 //check if their is a peripheral already plugged in
			 GetPeripheralID(dwPeripheralID);

			 //to receive regular updates on the device class use registry notify callbacks
			 RegistryNotifyCallback(hKey,NULL,PALM_SWPERIPHIDSTRING_VALUE,ClassDetectionCallback,PeripheralID,NULL,&g_hRegNotify[ PeripheralID ]);

		 }
		 else
			 wcscpy(wcPeripheralID,L"");


		 RegCloseKey(hKey);
	 }
 }



void GetDevice(DWORD dwDeviceClass)
{
	if (dwDeviceClass & MULTICONN_ATTACH)
	{
		if ((dwDeviceClass >> 16) == MULTICONN_CLASSID_CARKIT)
			wcscpy(wcDeviceClass,L"Car kit");
		else if ((dwDeviceClass >> 16) == MULTICONN_CLASSID_SERIAL)
			wcscpy(wcDeviceClass,L"Serial device");
		else if ((dwDeviceClass >> 16) == MULTICONN_CLASSID_SMART_SERIAL)
			wcscpy(wcDeviceClass,L"Smart Serial device");
		else
			wcscpy(wcDeviceClass,L"Unknown device");

	}
	else
		wcscpy(wcDeviceClass,L"No device attached");

	::InvalidateRect(MainWindow,0,true);
}



void GetPeripheralID(DWORD dwPeripheralID)
{
	_itow(dwPeripheralID ,wcPeripheralID,10);
	wcscpy(wcPeripheralID,L"Smart Serial device");

	::InvalidateRect(MainWindow,0,true);
}


void ClassDetectionCallback(HREGNOTIFY hNotify, DWORD dwUserData,
									  const PBYTE pData, const UINT cbData)
{
   // Identify the Notification received, based upon the User Data passed in, while registering for the notification.
    switch( dwUserData )
    {
        case DeviceDetected:
			{
				DWORD dwDeviceClass = (*(DWORD*) pData);
				GetDevice(dwDeviceClass);
			}
            break;

        case PeripheralID:
			{
				DWORD dwPeripheralID = (*(DWORD*) pData);
				GetPeripheralID(dwPeripheralID);
			}
            break;

        default :
            break;
    }
}

void  CloseAllNotifications ()
{
     for (int i = 0; i < MAX_NOTIF; i++)
    {
            RegistryCloseNotification(g_hRegNotify[i]);
    }

}
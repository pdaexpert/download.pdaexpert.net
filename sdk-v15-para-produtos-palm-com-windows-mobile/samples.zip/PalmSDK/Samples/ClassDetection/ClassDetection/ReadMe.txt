The code in this sample application demonstrates peripheral class detection (the status of any peripherals connected to the Multiconnector port on a Treo 750v). 


Revision History:
1.0.1 Minor UI fixes.
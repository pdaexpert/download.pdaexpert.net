The code in this sample application demonstrates several miscellaneous functions and API calls:
	- Using SystemParametersInfo() to check what device platform the application is running on
	- Using GetAsyncKeyState() to check if shift key, shift lock, option key, or option lock is in effect
	- Using RingerCallback to find out when the ringer switch on the Treo is switched on/off
	- Using GetDevicePower() to determine if the keyboard light is on or off

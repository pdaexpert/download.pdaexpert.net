// MiscellaneousFunctionality.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "MiscellaneousFunctionality.h"
#include <windows.h>
#include <commctrl.h>
#include "Pm.h"
#include <regext.h>
#include "snapi.h"
#include "KbdLayout.h"

HWND MainWindow = NULL;
HWND HRingerDialog = NULL;

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndMenuBar;		// menu bar handle

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


//sets up the registry notification calls for the ringer switch
HREGNOTIFY RegistryCallbackHandle = NULL;
void RingerCallback(HREGNOTIFY hNotify, DWORD dwUserData,
									const PBYTE pData, const UINT cbData);


//pass in a device type to check if you're running on that type
bool CheckDeviceType (wchar_t *device_type)
{
	TCHAR OEMString[100];
	SystemParametersInfo(SPI_GETOEMINFO, 100, OEMString, 0 );

	if (wcscmp(OEMString,device_type)==0)
		return true;
	else
		return false;
}

//this will check if a shift or option lock is in effect
INT_PTR CALLBACK LocksDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	wchar_t PressMessage[100]; //button pressed string

	switch (message)
	{
	case WM_INITDIALOG:
		{

		}
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		//check button was hit
		if (LOWORD(wParam) == IDC_CHECK)
		{
			wcscpy(PressMessage,L"");

			//find the radio button selected and then write if the corresponding 
			//lock is in effect or not
			if (IsDlgButtonChecked(hDlg,IDC_SHIFT_LOCK_ONETIME) == BST_CHECKED)
			{
				if (GetAsyncKeyState(VK_OEM_SHIFT_DOWN))
				{
					wcscpy(PressMessage,L"one time shift lock in effect");
				}
				else
				{
					wcscpy(PressMessage,L"one time shift lock is not in effect");
				}
			}
			else if (IsDlgButtonChecked(hDlg,IDC_SHIFT_LOCK) == BST_CHECKED)
			{
				if (GetAsyncKeyState(VK_OEM_SHIFT_LOCKED))
				{
					wcscpy(PressMessage,L"shift lock in effect");
				}
				else
				{
					wcscpy(PressMessage,L"shift lock is not in effect");
				}
			}
			else if (IsDlgButtonChecked(hDlg,IDC_OPTION_LOCK_ONETIME) == BST_CHECKED)
			{
				if (GetAsyncKeyState(VK_OEM_OPTION_DOWN))
				{
					wcscpy(PressMessage,L"one time option lock in effect");
				}
				else
				{
					wcscpy(PressMessage,L"one time option lock is not in effect");
				}
			}
			else if (IsDlgButtonChecked(hDlg,IDC_OPTION_LOCK) == BST_CHECKED)
			{
				if (GetAsyncKeyState(VK_OEM_OPTION_LOCKED))
				{
					wcscpy(PressMessage,L"option lock in effect");
				}
				else
				{
					wcscpy(PressMessage,L"option lock is not in effect");
				}
			}

			SetDlgItemText(hDlg,IDC_LOCK_STATE,PressMessage);			
		}

	case WM_CLOSE:
		EndDialog(hDlg, message);
		return TRUE;
	}
	return (INT_PTR)FALSE;
}


//this will display the state of the ringer switch
INT_PTR CALLBACK RingerDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

	switch (message)
	{
		//this manually checks the registry to see if the ringer switch is on or off
	case WM_INITDIALOG:
		{
			HKEY hKey;
			DWORD type,size,RingerState;		
			// check the ringer state
			if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("\\System\\State\\Hardware"), 0, 0, &hKey))
			{ 
				if (ERROR_SUCCESS == RegQueryValueEx(hKey,L"Ringer",NULL,&type,(BYTE*)(&RingerState),&size))
				{
					wchar_t Position[50];

					if (RingerState == 0)
						wcscpy(Position,L"Off");
					else
						wcscpy(Position,L"On");

					SetDlgItemText(hDlg,IDC_RINGER_MESSAGE,Position);

					//to receive regular updates on the switch position use registry notify callbacks
					RegistryNotifyCallback(hKey,NULL,L"Ringer",RingerCallback,(DWORD)MainWindow,NULL,&RegistryCallbackHandle);

					RegCloseKey(hKey);
				}
	}
		}
		return (INT_PTR)TRUE;

	case WM_CLOSE:
		EndDialog(hDlg, message);
		return TRUE;
	}
	return (INT_PTR)FALSE;
}



//this function gets called whenever the ringer switch is moved to a new position
void RingerCallback(HREGNOTIFY hNotify, DWORD dwUserData,
									  const PBYTE pData, const UINT cbData)
{
	HWND hWnd = (HWND)dwUserData;
	DWORD RingerState = (DWORD)*pData;				
	wchar_t Position[50];

	//set the ringer dialog text
	if (RingerState == 0)
		wcscpy(Position,L"Off");
	else
		wcscpy(Position,L"On");

	SetDlgItemText(HRingerDialog,IDC_RINGER_MESSAGE,Position);
}


//this handles the keyboard light dialog and checks the state of the light
//when the keylight dialog button is pressed
INT_PTR CALLBACK KeyboardLightDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	wchar_t KeyLightState[50];
	CEDEVICE_POWER_STATE DeviceState;

	switch (message)
	{
	case WM_INITDIALOG:
		{
			//Controlling the keyboardlight on the Treo750v is not supported
			if (CheckDeviceType (L"Palm Treo 750"))
			{
				//update the button text
				SetDlgItemText(hDlg,IDC_KEYBOARD_LIGHT,L"Not Supported");	
				return (INT_PTR)TRUE;
			}

			//check the state of the light
			GetDevicePower(L"kyl0:",POWER_NAME,&DeviceState);

			//is the light on or off
			if (DeviceState == D0)
				wcscpy(KeyLightState,L"Off");
			else
				wcscpy(KeyLightState,L"On");	

			//update the button text
			SetDlgItemText(hDlg,IDC_KEYBOARD_LIGHT,KeyLightState);	
		}
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_KEYBOARD_LIGHT)
		{			
			//Controlling the keyboardlight on the Treo750v is not supported
			if (CheckDeviceType (L"Palm Treo 750"))
			{
				::MessageBox(hDlg,L"Controlling the keyboardlight on the Treo750v is not supported",
					              L"Not supported", MB_OK);
				return TRUE;
			}

			DWORD ret;
			//check the state of the light
			GetDevicePower(L"kyl0:",POWER_NAME,&DeviceState);

			//turn the light on or off
			if (DeviceState == D0)
			{
				ret = SetDevicePower(L"kyl0:",POWER_NAME,D4);
				wcscpy(KeyLightState,L"On");
			}
			else
			{
				ret = SetDevicePower(L"kyl0:",POWER_NAME,D0);
				wcscpy(KeyLightState,L"Off");
			}

			//update the button text
			SetDlgItemText(hDlg,IDC_KEYBOARD_LIGHT,KeyLightState);

			//if something went wrong - set back the default device power
			if (ret != ERROR_SUCCESS)
				SetDevicePower(L"kyl0:",POWER_NAME,PwrDeviceUnspecified);	

			return TRUE;
		}

	case WM_CLOSE:
		EndDialog(hDlg, message);
		return TRUE;

	}
	return (INT_PTR)FALSE;
}

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MISCELLANEOUSFUNCTIONALITY));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MISCELLANEOUSFUNCTIONALITY));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable

    // SHInitExtraControls should be called once during your application's initialization to initialize any
    // of the Pocket PC special controls such as CAPEDIT and SIPPREF.
    SHInitExtraControls();

    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_MISCELLANEOUSFUNCTIONALITY, szWindowClass, MAX_LOADSTRING);

    //If it is already running, then focus on the window, and exit
    hWnd = FindWindow(szWindowClass, szTitle);	
    if (hWnd) 
    {
        // set focus to foremost child window
        // The "| 0x00000001" is used to bring any owned windows to the foreground and
        // activate them.
        SetForegroundWindow((HWND)((ULONG) hWnd | 0x00000001));
        return 0;
    } 

    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }

    MainWindow = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

    if (!MainWindow)
    {
        return FALSE;
    }

    // When the main window is created using CW_USEDEFAULT the height of the menubar (if one
    // is created is not taken into account). So we resize the window after creating it
    // if a menubar is present
    if (g_hWndMenuBar)
    {
        RECT rc;
        RECT rcMenuBar;

        GetWindowRect(MainWindow, &rc);
        GetWindowRect(g_hWndMenuBar, &rcMenuBar);
        rc.bottom -= (rcMenuBar.bottom - rcMenuBar.top);
		
        MoveWindow(MainWindow, rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top, FALSE);
    }

    ShowWindow(MainWindow, nCmdShow);
    UpdateWindow(MainWindow);

	
	//show the keyboard toggle button
	ShowWindow(CreateDialog(g_hInst, (LPCTSTR)IDD_KEYBOARDLIGHT_DIALOG, MainWindow, KeyboardLightDialog),true);
	//show the ringer dialog
	ShowWindow(HRingerDialog = CreateDialog(g_hInst, (LPCTSTR)IDD_RINGER_DIALOG, MainWindow, RingerDialog),true);
	//add the dialog window for locks
	ShowWindow(CreateDialog(g_hInst, (LPCTSTR)IDD_LOCKS_DIALOG, MainWindow, LocksDialog),true);

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

    static SHACTIVATEINFO s_sai;
	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_OK:
                    SendMessage (hWnd, WM_CLOSE, 0, 0);				
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            SHMENUBARINFO mbi;

            memset(&mbi, 0, sizeof(SHMENUBARINFO));
            mbi.cbSize     = sizeof(SHMENUBARINFO);
            mbi.hwndParent = hWnd;
            mbi.nToolBarId = IDR_MENU;
            mbi.hInstRes   = g_hInst;

            if (!SHCreateMenuBar(&mbi)) 
            {
                g_hWndMenuBar = NULL;
            }
            else
            {
                g_hWndMenuBar = mbi.hwndMB;
            }

            // Initialize the shell activate info structure
            memset(&s_sai, 0, sizeof (s_sai));
            s_sai.cbSize = sizeof (s_sai);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
			//set back default keyboard power management
			SetDevicePower(L"kyl0:",POWER_NAME,PwrDeviceUnspecified);

			RegistryCloseNotification(RegistryCallbackHandle);
            CommandBar_Destroy(g_hWndMenuBar);
            PostQuitMessage(0);
            break;

        case WM_ACTIVATE:
            // Notify shell of our activate message
            SHHandleWMActivate(hWnd, wParam, lParam, &s_sai, FALSE);
            break;
        case WM_SETTINGCHANGE:
            SHHandleWMSettingChange(hWnd, wParam, lParam, &s_sai);
            break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            {
                // Create a Done button and size it.  
                SHINITDLGINFO shidi;
                shidi.dwMask = SHIDIM_FLAGS;
                shidi.dwFlags = SHIDIF_DONEBUTTON | SHIDIF_SIPDOWN | SHIDIF_SIZEDLGFULLSCREEN | SHIDIF_EMPTYMENU;
                shidi.hDlg = hDlg;
                SHInitDialog(&shidi);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if (LOWORD(wParam) == IDOK)
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

#ifdef _DEVICE_RESOLUTION_AWARE
        case WM_SIZE:
            {
			const UINT dialogID = (DRA::GetDisplayMode() == DRA::Landscape ? IDD_ABOUTBOX_WIDE : IDD_ABOUTBOX);
			DRA::RelayoutDialog(g_hInst, hDlg, MAKEINTRESOURCE(dialogID));
            }
            break;
#endif
    }
    return (INT_PTR)FALSE;
}

/*! \file SerialPort.cpp:  revision 1.0
	\brief Serial Port sample demonstrating setting up the Treo700w serial port and sending a character.
	SerialPortSample.cpp is where all SerialPort.h function calls are made and
	SerialPortSample.cpp is standard Windows code.

	Copyright 2006 Palm Inc., All Rights Reserved.
*/

#include "5WayHandler.h"

#define IDC_BUTTON1  100
#define IDC_BUTTON2  101
#define IDC_BUTTON3  102

HWND Button1Wnd;
HWND Button2Wnd;
HWND Button3Wnd;


//Key handling switch
bool InterceptKeyPresses(MSG msg)
{
	switch (msg.message)
	{
	case WM_KEYDOWN:
		{

			//Find which window currently has focus
			HWND FocusWnd = ::GetFocus();
			//Get the parent window so that it can be invalidated if necessary
			HWND TopWnd = ::GetParent(FocusWnd);
			
			//Depending on the directional pad button pushed,
			//set the next button to be in focus or which button was pressed
			switch (msg.wParam)
			{
			case VK_UP:
				{
					if ((FocusWnd == Button1Wnd) || (FocusWnd == Button2Wnd))
						::SetFocus(Button3Wnd);
					else
						::SetFocus(Button1Wnd);
					::InvalidateRect(TopWnd,NULL,true);
				}
				break;
			case VK_DOWN:
				{
					if ((FocusWnd == Button1Wnd) || (FocusWnd == Button2Wnd))
						::SetFocus(Button3Wnd);
					else
						::SetFocus(Button1Wnd);
					::InvalidateRect(TopWnd,NULL,true);
				}
				break;
			case VK_LEFT:
				{
					if (FocusWnd == Button1Wnd) 
						::SetFocus(Button2Wnd);					
					else if (FocusWnd == Button2Wnd)
						::SetFocus(Button1Wnd);
					else
						::SetFocus(Button3Wnd);
					::InvalidateRect(TopWnd,NULL,true);
				}
				break;
			case VK_RIGHT:
				{
					if (FocusWnd == Button1Wnd) 
						::SetFocus(Button2Wnd);					
					else if (FocusWnd == Button2Wnd)
						::SetFocus(Button1Wnd);
					else
						::SetFocus(Button3Wnd);
					::InvalidateRect(TopWnd,NULL,true);
				}
				break;
			case VK_RETURN:
				{
					TCHAR Message[100];

					if (FocusWnd == Button1Wnd) 
					  wcscpy(Message,L"Button 1 has been pressed");			
					else if (FocusWnd == Button2Wnd)
					  wcscpy(Message,L"Button 2 has been pressed");	
					else
					  wcscpy(Message,L"Button 3 has been pressed");	

					::MessageBox(FocusWnd,Message,L"ButtonPress",MB_OK);
					return true;
				}
				break;
			}
			break;
		}
	}

	return false;
}


//Create 3 buttons
bool CreateButtons(HWND hWnd, HINSTANCE g_hInst)
{
	Button1Wnd = CreateWindow(L"BUTTON", L"Button 1",
		BS_PUSHBUTTON | BS_NOTIFY | WS_VISIBLE | WS_CHILD | BS_MULTILINE ,
		10, 30, 100, 50,
		hWnd, (HMENU) IDC_BUTTON1, g_hInst, NULL);

	Button2Wnd = CreateWindow(L"BUTTON", L"Button 2",
		BS_PUSHBUTTON | BS_NOTIFY | WS_VISIBLE | WS_CHILD,
		130, 30, 100, 50,
		hWnd, (HMENU) IDC_BUTTON2, g_hInst, NULL);


	Button3Wnd = CreateWindow(L"BUTTON", L"Button 3",
		BS_PUSHBUTTON | BS_NOTIFY | WS_VISIBLE | WS_CHILD | BS_MULTILINE ,
		70, 95, 100, 50,
		hWnd, (HMENU) IDC_BUTTON3, g_hInst, NULL);


	if (!Button1Wnd && !Button2Wnd && !Button3Wnd)
	{
		return false;
	}

	SetFocus(Button1Wnd);

	return true;
}
/*! \file 5WayHandler.h:  revision 1.0
	\brief 5-way sample demonstrating one method of allowing an application to use the directional
	pad to navigate between various windows in an application.  This is only used when dialog boxes are
	not used since the dialog manager will handle the directional pad presses for a dialog box.

	 Copyright 2006 Palm Inc., All Rights Reserved.
*/

#pragma once

#include "stdafx.h"
#include <windows.h>

/*! \fn bool InterceptKeyPresses(MSG msg)
    \brief This function handles directional pad presses.

	Handles all directional pad button presses.  If dialog boxes are being used then this is
	unnecessary since the dialog manager will handle this by default.
*/
bool InterceptKeyPresses(MSG msg);

/*! \fn bool CreateButtons(HWND hWnd, HINSTANCE g_hInst)
    \brief Creates the buttons to navigate.

	Creates three button windows which will be used to demonstrate window navigation using the
	directional pad.
*/
bool CreateButtons(HWND hWnd, HINSTANCE g_hInst);
The code in this sample application demonstrates one method of allowing an application to use the 5-way directional pad to navigate between various windows in an application. This is only necessary when dialog boxes are not used since the dialog manager will handle the directional pad presses for a dialog box.

Version History:
1.0.1 - Minor UI Changes
README

==================================================================
CONTENTS
==================================================================

1.  PACKAGE CONTENTS
2.  INSTALLING PRCs
3.  SAMPLE MIDLETS


==================================================================
1. PACKAGE CONTENTS
==================================================================
This package contains the following directories:


Palm OS Garnet JVM
	Documentation
	JSR172
	JSR75
	JVM
		ARM4T
	Samples
	

- Documentation - contains WEME 5.7 User Guide, Readme, and Release Notes
- JSR172 - Contains PRCs for JSR 172 Web Services 
- JSR75 - Contains PRCs for JSR 75 PIM integration
- JVM - Contains PRCs for JVM with MIDP and CLDC JSRs
- Samples - contains sample midlets


==================================================================
2. INSTALLING PRCs
==================================================================
No special installation procedures or wizards are required.

To run the MIDP2.0 JVM on a Palm OS device, HotSync all the ARM4T PRC files for your language.
Optional:  To add JSR 172 or JSR75 functionality to the JVM, HotSync the PRC files from the JSR172
	   and JSR75 directories (and appropriate files for your language).

See the WEME 5.7 User Guide in the /Documentation folder for more
detailed instructions.

==================================================================
3. SAMPLE MIDLETS
==================================================================
Java MIDlets are available on the Internet. The following sites are popular for downloading sample MIDlets.

http://developers.sun.com/techtopics/mobility/allsamples/
http://midlet.org
http://www.midlet-review.com/index?content=freegames/freegames




==============
Modified January 2005
Copyright 2004 PalmSource, Inc.
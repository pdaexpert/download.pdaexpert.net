PRC edit is a HEX editor and Ascii viewer in one. You can open a PRC with corresponding disassembled source file in the editor. 

Features:
- If you see an opcode in the source code and you want to edit it in the PRC file, all you have to do is press F10 to jump to the correct location.
- Jump to a link reference with F11 and jump right back with F12.
- Create XML files for PW-Patcher from within the editor.
- The PRC file can automaticly splitted with SplitPRC and disassebled with Pilotdis.
- The source file is splitted into the source part, the label cross reference part and the global cross reference part.
- Multiple undo when editing.
- Set unlimited bookmarks in the source file.
- Treeview with Form, alert and string resources.
- Syntax highlighting
- Etc.

Limitations:
- PRC edit is only compatible with pilotdis wich can be found at www.palmgear.com
- You cannot change the length of the PRC file in the editor. 
- The program isn't bastard proof. I'm sure that you can crash the program but I don't care.
- You cannot create illegal patches with PRC edit.

Tips:
- Use ctrl+shift+[0..9] to set a bookmark, use ctrl+[0..9] to jump to it. This works in source editor and in hex editor!
- Modified something in hexeditor and forgot from wich sourcetab you came? Press F9 to jump to it.
- Use the right click menu often. There are handy options like: search up/down for word on cursor and jump to subroutine under cursor.
- Look in the options screen. There are some nice options you can change to get most out of PRCedit.
- Look in all menus to see all the power of PRcedit.

Built in assembler:
There's a small assembler built in to insert custom opcodes in the binary file. It only supports some Data tranfers Instructions. You can use:
- MOVEQ, MOVE.B, MOVE.W and MOVE.L for instruction
- Dn, An, (An), (An)+ and -(An) for source and destination registers where n is a number from 0..7
- #n for source where n is a number (You can't use the syntax #10!$0A, use #10 or #$0A)

In hexeditor, choose the menu "Insert", "From assembler" to use this feature

(C)opyright 2000 by Dr Funk

History

0.1-0.5 First public releases
0.7-0.9 Added MDI childs to support multi code PRC files
1.0     Added a treeview with resources 
1.1 	Made it compatible with Pilotdis 1.16
1.11    Fixed a bug with paths with a space
1.20	Added 'saved changes log'
1.30    Added Auto delete tempfiles
        Added Copy XML to clipboard
	Added Extracting URL from PRC file
	Fixed Resizing treeview bug 
1.31    Fixed a bug in the 'Saved changes log'
        Added Ascii Load and Save option on right click popupmenu. Note that the original
        source file contains the Link list (LCR) and the Global variables list (GCR) and
        that PRC splits them on opening. If you save the Source file, you'll have to save
        the LCR and GCR too. Better is it to save the new file with a different name and 
        reload it manual if you open the file again.
        Added Use of tab key in Asciview
1.32	Fixed a bug with the delete tempfiles option
	Kept cursor position when reopening original file
	Creating linklist and creating XML is now more Windows friendly.
1.4	Added Jumpstack to store multiple jumps
1.41	Added PRECRC to create XML and speeded it up to lightning
1.50    Modified XML header to new standard
	Added Yes to all in disassemble question
1.60	Added references to DC.B lines
1.70 	Included SplitPRC in program. There's no more need for an external splitter.
1.80	Added right click menu with search for word under cursor
	Added option to use the same find options for all 'Find dialogs'
1.90	Added customizing of hex insert menu
	Fixed a small bug in internal splitPRC
	Fixed a small ignorance in copy-paste in notes window
1.91	Fixed a bug in the dc.b tree texts
	Speeded up the analysing
1.92	Fixed a bug in internal splitPRC that occurred in programs with strange code resourcenames
	Fixed a bug with spaces in filepaths
2.00    Fixed a bug when there was no systraps.txt
        Jump from tree now shows description selected
        Jump from hex editor back to last source screen by pressing F9
	Ability to change fontsize of Ascii forms
	Speeeeeed improvement!
        On first startup, the program opens options screen to set pilotdis
	Form and alert titles are included in the source as comment
	First try for subroutine name as comment
	Added extra XML header for PWCPP
	Changed the Bookmarks. Use C+Shift+[0..9] to set bookmark. 
        Use Ctrl+[0..9] to jump to the bookmark
        Syntax highlighting for 'Keywords' and 'special keywords'
        Save and load in Emulator command (ctrl-e)
        Added definitly green arrows for string references before sysTrapFrmHelp and sysTrapSysCopyStringResource
2.10    Added keywords in tree
        Added error handling for resource reading
        Added CRC calculating for selection in hexeditor
        Added Patch finder, it finds the location in the sourcefile from a position in the prc binary
        Insert from Assembler. You can type strings like: MOVE.? D?,D? and MOVEQ #???,D?
	Added option to always disassemble files
	Checking if saving works
	Opening prc read-only


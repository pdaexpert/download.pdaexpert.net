/* pilrc generated file.  Do not edit!*/
#define AboutUnnamed1606Button 1011
#define AboutUnnamed1605Label 1010
#define AboutUnnamed1603Label 1009
#define AboutUnnamed1602Label 1008
#define AboutForm 1007
#define MainClearSyncButton 1006
#define MainClearTextButton 1005
#define MainDescriptionField 1004
#define MainForm 1003
#define HelpAboutNVFSTester 1002
#define RomIncompatibleAlert 1001

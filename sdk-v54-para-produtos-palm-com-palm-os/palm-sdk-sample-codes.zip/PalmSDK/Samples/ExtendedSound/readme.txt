. Extended Sound Sample Code

This sample code shows how to use the extended sound manager API.
The application 'MyPlayer' is a recorder/player for WAVE files.
Currently only PCM and IMA_ADPCM 4-bit WAVE files are supported.
This application was built using CodeWarrior 9 but there should be
no issues switching to CodeWarrior 8.

Features:

- Recording.
- Playback.
- Write WAVE files to Memory or Card.
- Select recording options.
- Fully working application.
- Use different sample rate for playback (it's fun!).

Application Structure:

- The entry point of the program is MyPlayer.c.
- There are 2 forms: RecordForm and PlayForm.
- Each have there own event loops and menus.
- Each form has a mini state machine for play or record/pause/idle.

Files:

- Common : Common functions for PalmOS
- MyPlayer : Main application entry point
- PlayForm : Player form
- RecordForm : Record form
- Wave : Basic functionality to read/write WAVE headers to a file.

Note: 

When selecting the IMA_ADPCM codec, the recommended sample rate is
up to 22050 Hz. If set higher, the result may be poor audio quality
during playback.


/*
 * MiniADPCM.h
 *
 * This wizard-generated code is based on code adapted from the
 * stationery files distributed as part of the Palm OS SDK
 *
 * Copyright (c) 1999-2004 PalmOne, Inc. or its subsidiaries.
 * All rights reserved.
 */
 
#ifndef MINIADPCM_H_
#define MINIADPCM_H_

#define appFileCreator			'mADP'
#define appName					"MiniADPCM"
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

#endif /* MINIADPCM_H_ */

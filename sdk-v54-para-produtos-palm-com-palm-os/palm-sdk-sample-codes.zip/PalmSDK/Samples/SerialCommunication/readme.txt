---------------------------------------------------------------------------
Name

  SerialCommunication

---------------------------------------------------------------------------
Description

  This sample code shows how to use the Serial Manager to transmit and 
  receive Serial Data.

  Features:
  - Transmit data using the Serial Port.
  - Receive data from the Serial Port.
  - Detect Serial Peripheral (Uses Workaround for Tungsten T5).
  - Power On the POWER_OUT pin (Tungsten T5 Only).
  - Power Off the POWER_OUT pin (Tungsten T5 Only).
  - Workaround for the flow control problem on Tungsten T3.
  - Added support for the class notifications

  Files:
  - SerialTransRecv	: Shows how to transmit and receive data using the serial port.
                          Shows how to detect a serial peripheral on Tungsten T5.
		          Shows how to power on/off the POWER_OUT pin on Tungsten T5.
			  Shows how to workaround the flow control problem on Tungsten T3.
			  Shows how to detect class Notifications.

---------------------------------------------------------------------------
Builds With

  CodeWarrior 9
  Gcc

---------------------------------------------------------------------------
Devices

  All Palm devices

---------------------------------------------------------------------------
Requirements


---------------------------------------------------------------------------
Libraries Used

  Serial Manager

---------------------------------------------------------------------------
How to Run


---------------------------------------------------------------------------
Note

  WARNING: This sample code uses an ARMlet to workaround the flow control 
  problem on Tungsten T3. This is not officially supported by Palm. Please 
  use this at your own risk.

---------------------------------------------------------------------------






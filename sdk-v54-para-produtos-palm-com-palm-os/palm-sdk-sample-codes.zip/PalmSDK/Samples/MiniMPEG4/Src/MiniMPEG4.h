/*
 * MiniMPEG4.h
 *
 *
 * This wizard-generated code is based on code adapted from the
 * stationery files distributed as part of the Palm OS SDK 4.0.
 *
 * Copyright (c) 1999-2004 PalmOne, Inc. or its subsidiaries.
 * All rights reserved.
 */
 
#ifndef MINIMP3_H_
#define MINIMP3_H_

#define appFileCreator			'mMP4'
#define appName					"MiniMPEG4"
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

#endif /* MINIMP3_H_ */

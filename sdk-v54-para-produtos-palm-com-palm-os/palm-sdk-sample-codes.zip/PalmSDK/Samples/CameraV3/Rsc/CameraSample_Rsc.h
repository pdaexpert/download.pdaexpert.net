/* pilrc generated file.  Do not edit!*/
#define MainPreviewButton 1008
#define MainForm 1007
#define LibraryLoadErrorAlert 1006
#define RomIncompatibleAlert 1005
#define OptionsAbout 1004
#define OptionsMenu 1003
#define AppName 1002
#define VersionNumber 1001

---------------------------------------------------------------------------
Name

  CameraV3

---------------------------------------------------------------------------
Description

  CameraV3 is a sample application that shows how to add basic 
  camera/imaging functionality by using the Camera library. The sample 
  also uses the new Camera Manager library. 

---------------------------------------------------------------------------
Builds With

  CodeWarrior
  Gcc

---------------------------------------------------------------------------
Devices

  All Palm devices with camera support

---------------------------------------------------------------------------
Requirements


---------------------------------------------------------------------------
Libraries Used

  Camera Library
  New Camera Manager Library

---------------------------------------------------------------------------
How to Run

  1. Launch the application
  2. Tap on 'Capture' to take a picture

---------------------------------------------------------------------------
Note


---------------------------------------------------------------------------


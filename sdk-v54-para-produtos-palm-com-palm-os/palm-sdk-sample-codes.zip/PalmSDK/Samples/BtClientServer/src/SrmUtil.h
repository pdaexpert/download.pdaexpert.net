 /****************************************************************************
 *
 * Copyright (c) 2007 Palm, Inc. All rights reserved.
 *
 * File: SrmUtil.h
 *
 *****************************************************************************/

void SrmUtilSetupClient(void);
void SrmUtilClientSend(char *filePath);
void SrmUtilSetupServer( void );
void SrmUtilServerReceive(void);
Err SrmUtilUninit(void);




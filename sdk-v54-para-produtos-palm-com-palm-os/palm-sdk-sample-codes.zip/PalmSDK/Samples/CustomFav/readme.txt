---------------------------------------------------------------------------
Name

  CustomFav

---------------------------------------------------------------------------
Description

  This sample code shows how to use the Favorites DB library to create 
  custom favorites in the Phone app view (blue grid). Please note that the 
  functionality of this library is very limited due to the fact that it 
  was designed to be used by the Phone application only. There is currently 
  no programmatic way to tell if a position in the grid has been occupied
  or not, so the newly-created entry will always replace the existing one.

---------------------------------------------------------------------------
Builds With

  CodeWarrior
  Gcc

---------------------------------------------------------------------------
Devices

  All Treo smartphones

---------------------------------------------------------------------------
Requirements


---------------------------------------------------------------------------
Libraries Used


---------------------------------------------------------------------------
How to Run

  1. Launch application
  2. An alert will appear saying new favorites have been added to the 
     phone application favories view

---------------------------------------------------------------------------
Note


---------------------------------------------------------------------------

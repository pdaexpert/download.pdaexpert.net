#include ".\mlconduitxml.h"

MLConduitXml::MLConduitXml(void)
{
   
}

MLConduitXml::~MLConduitXml(void)
{
}


/***********************************************************************
 *
 * Copyright (c) 2003 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/
#include <PalmOS.h>
#include "PalmPhoto.h"

// Checks the version of API present and determine which version funtion to use
//static UInt32 		verPresent;
//UInt32 verPresent;
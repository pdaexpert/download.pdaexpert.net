/******************************************************************************
 * Copyright (c) 2006 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
/**
 * TickStock is a sample application that demonstrates:
 *
 * - mainly, how to detect and handle incoming call interruption
 * - how to detect if device is using EvDO connection
 * - downloading data while keeping UI responsive
 * - implementing [background] HTTP request as a state machine
 *
 * The application connects to Yahoo! Finance website and download
 * the HTTP content until it finds the latest price of the queried
 * stock.

 * The requested stocks are Palm, Yahoo!, Google, Microsoft, and Intel.

 * Once you tap on "Refresh" button, the application will open NetLib and establish socket
 * connections to retrieve stock data. It might take several seconds to see "Connecting" prompt
 * window after tapping on "Refresh". 

 * You can also choose "Auto-update every 15 minutes" to enable the application to set a 15 minutes
 * timer to go online and retrieve data.

 *
 */

README for 
PalmSource Java Technologies for Palm OS Garnet
using IBM WebSphere Everywhere Micro Edition, Relase 5.7

==================================================================
CONTENTS
==================================================================

1.  PACKAGE CONTENTS
2.  INSTALLING PRCs
3.  SAMPLE MIDLETS

==================================================================
1. PACKAGE CONTENTS
==================================================================
This package contains the following directories:

Documentation
JSR172
JSR75
JVM
	Simulator
Samples
Tools
	bin
	lib
		jclFoundation10

- Documentation - contains WEME 5.7 User Guide, Readme, and Release Notes
- JSR172 - Contains PRCs for JSR 172 Web Services 
- JSR75 - Contains PRCs for JSR 75 PIM integration
- JVM - Contains PRCs for JVM with MIDP and CLDC JSRs
- Samples - contains sample midlets
- Tools - JarToPRC tool converts JAR files to PRC files

==================================================================
2. INSTALLING PRCs
==================================================================
No special installation procedures or wizards are required.

To run the JVM on Palm OS Simulator, download the Palm OS Garnet Simulator
for Palm OS Garnet 5.4, put the J9JavaVMMidp20.dll file into the folder that
contains PalmSim.exe, and copy the PRC files into the AutoLoad folder.

This package does not include the device-version of the JVM.  Those are 
customized for specific devices and are available from PalmSource or from 
our licensees.  Please see the PalmSource developer site for more information.

See the WEME 5.7 User Guide in the /Documentation folder for more
detailed instructions.

==================================================================
3. SAMPLE MIDLETS
==================================================================
Java MIDlets are available on the Internet. The following sites are popular for downloading sample MIDlets.

http://developers.sun.com/techtopics/mobility/allsamples/
http://midlet.org
http://www.midlet-review.com/index?content=freegames/freegames


==============
Modified January 2005
Copyright (C) 2004-2005 PalmSource, Inc.  All rights reserved.
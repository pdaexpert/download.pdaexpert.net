#ifndef BORDEREDPANEL_H_
#define BORDEREDPANEL_H_

#include "java.awt.LayoutManager.h"
#include "java.awt.Insets.h"
#include "java.awt.Panel.h"
#include "japa.lang.GC.h"

class BorderedPanel: public java_awt_Panel {
    friend class MainFrame;
public: 
    BorderedPanel(int border, java_awt_LayoutManagerPtr mgr);

    BorderedPanel(int border);

    virtual java_awt_InsetsPtr getInsets();

private: 
    const int border;

};

typedef gc::ptr<BorderedPanel> BorderedPanelPtr;

#endif //BORDEREDPANEL_H_

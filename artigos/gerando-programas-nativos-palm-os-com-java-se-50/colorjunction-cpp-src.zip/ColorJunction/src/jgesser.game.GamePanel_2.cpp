#include "jgesser.game.GamePanel_2.h"

jgesser_game_GamePanel_2::jgesser_game_GamePanel_2(jgesser_game_GamePanelPtr this_0): this_0(this_0) {
}

void jgesser_game_GamePanel_2::mouseClicked(java_awt_event_MouseEventPtr e) {
    this_0->click(e->getX(), e->getY());
}

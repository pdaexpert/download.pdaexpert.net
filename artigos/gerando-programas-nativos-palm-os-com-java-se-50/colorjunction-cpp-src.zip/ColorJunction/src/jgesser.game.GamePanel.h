#ifndef JGESSER_GAME_GAMEPANEL_H_
#define JGESSER_GAME_GAMEPANEL_H_

#include "java.util.Random.h"
#include "java.lang.Array.h"
#include "java.awt.event.ComponentAdapter.h"
#include "java.awt.Color.h"
#include "java.awt.Graphics.h"
#include "java.awt.Font.h"
#include "java.awt.event.MouseAdapter.h"
#include "java.awt.Panel.h"
#include "japa.lang.GC.h"

class jgesser_game_GamePanel: public java_awt_Panel {
    friend class jgesser_game_GamePanel_1;
    friend class jgesser_game_GamePanel_2;
public: 
    jgesser_game_GamePanel();

    void setNumColors(int numColors);

    int getNumColors();

    void setNumBlocks(int numBlocks);

    int getNumBlocks();

    void newGame();

    void paint(java_awt_GraphicsPtr g);

    int getPiecesLeft();

protected: 
    void click(int x, int y);

private: 
    int numBlocks;

    java_lang_ArrayPtr< java_awt_ColorPtr > colors;

    int BLOCK_WIDTH;

    int TABLE_POS_X;

    int TABLE_POS_Y;

    int TABLE_BORDER;

    int numColors;

    int BLOCK_SPACING;

    java_lang_ArrayPtr< java_lang_ArrayPtr< int > > board;

    int BLOCK_ROUNDING;

    int TABLE_WIDTH;

    int piecesLeft;

    void mark(int color, int x, int y, java_lang_ArrayPtr< int > ret);

    void rearrange();

};

typedef gc::ptr<jgesser_game_GamePanel> jgesser_game_GamePanelPtr;

#endif //JGESSER_GAME_GAMEPANEL_H_

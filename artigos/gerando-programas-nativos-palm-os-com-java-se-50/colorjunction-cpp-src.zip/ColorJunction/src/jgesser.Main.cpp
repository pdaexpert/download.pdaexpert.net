#include "jgesser.Main.h"
//#include "MainFrame.h"

void jgesser_Main::main(java_lang_ArrayPtr< java_lang_StringPtr > args) {
    jgesser_ui_MainFramePtr(new jgesser_ui_MainFrame())->setVisible(true);
    //MainFramePtr(new MainFrame())->setVisible(true);
}

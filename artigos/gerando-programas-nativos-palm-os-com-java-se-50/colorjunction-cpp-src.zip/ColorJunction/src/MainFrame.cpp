#include "MainFrame.h"
#include "MainFrame_1.h"

const int MainFrame::BORDER = 8;

MainFrame::MainFrame() : java_awt_Frame() {
    this->choiceDia = NULL;
    this->listSaidaBairro = NULL;
    this->choiceLinha = NULL;
    this->listSaidaTerminal = NULL;
    
    initialize();
}

void MainFrame::main(java_lang_ArrayPtr< java_lang_StringPtr > args) {
    MainFramePtr(new MainFrame())->setVisible(true);
}

void MainFrame::initialize() {
    this->setSize(291, 395);
    this->setTitle(java_lang_StringPtr("BusTime"));
    addWindowListener(MainFrame_1Ptr(new MainFrame_1(MainFramePtr(this, true))));
    java_awt_BorderLayoutPtr borderLayout = java_awt_BorderLayoutPtr(new java_awt_BorderLayout());
    borderLayout->setVgap(BORDER / 2);
    java_awt_PanelPtr panelCenter = BorderedPanelPtr(new BorderedPanel(BORDER));
    panelCenter->setLayout(borderLayout);
    this->add(panelCenter);
    java_awt_PanelPtr paneTop = java_awt_PanelPtr(new java_awt_Panel());
    paneTop->setLayout(java_awt_BorderLayoutPtr(new java_awt_BorderLayout()));
    java_awt_GridLayoutPtr gridLayout = java_awt_GridLayoutPtr(new java_awt_GridLayout());
    gridLayout->setRows(2);
    gridLayout->setVgap(BORDER / 2);
    java_awt_LabelPtr labelLinha = java_awt_LabelPtr(new java_awt_Label());
    labelLinha->setText(java_lang_StringPtr("Linha:"));
    labelLinha->setFont(java_awt_FontPtr(new java_awt_Font(java_lang_StringPtr("Dialog"), java_awt_Font::BOLD, 12)));
    labelLinha->setAlignment(java_awt_Label::RIGHT);
    java_awt_LabelPtr labelDia = java_awt_LabelPtr(new java_awt_Label());
    labelDia->setText(java_lang_StringPtr("Dia:"));
    labelDia->setAlignment(java_awt_Label::RIGHT);
    labelDia->setFont(java_awt_FontPtr(new java_awt_Font(java_lang_StringPtr("Dialog"), java_awt_Font::BOLD, 12)));
    java_awt_PanelPtr panelTopLeft = java_awt_PanelPtr(new java_awt_Panel());
    panelTopLeft->setLayout(gridLayout);
    panelTopLeft->setName(java_lang_StringPtr("panel"));
    panelTopLeft->add(labelLinha, NULL);
    panelTopLeft->add(labelDia, NULL);
    paneTop->add(panelTopLeft, java_awt_BorderLayout::WEST);
    gridLayout = java_awt_GridLayoutPtr(new java_awt_GridLayout());
    gridLayout->setRows(2);
    gridLayout->setVgap(BORDER / 2);
    java_awt_PanelPtr panelTopRight = java_awt_PanelPtr(new java_awt_Panel());
    panelTopRight->setLayout(gridLayout);
    panelTopRight->setName(java_lang_StringPtr("panel1"));
    choiceLinha = java_awt_ChoicePtr(new java_awt_Choice());
    panelTopRight->add(choiceLinha, NULL);
    choiceDia = java_awt_ChoicePtr(new java_awt_Choice());
    panelTopRight->add(choiceDia, NULL);
    paneTop->add(panelTopRight, java_awt_BorderLayout::CENTER);
    panelCenter->add(paneTop, java_awt_BorderLayout::NORTH);
    gridLayout = java_awt_GridLayoutPtr(new java_awt_GridLayout());
    gridLayout->setRows(1);
    gridLayout->setHgap(BORDER);
    gridLayout->setColumns(2);
    java_awt_PanelPtr panelBottom = java_awt_PanelPtr(new java_awt_Panel());
    panelBottom->setLayout(gridLayout);
    java_awt_LabelPtr labelSaidaTerminal = java_awt_LabelPtr(new java_awt_Label());
    labelSaidaTerminal->setText(java_lang_StringPtr("Sa�da Terminal"));
    java_awt_PanelPtr panelBottomLeft = java_awt_PanelPtr(new java_awt_Panel());
    panelBottomLeft->setLayout(java_awt_BorderLayoutPtr(new java_awt_BorderLayout()));
    panelBottomLeft->add(labelSaidaTerminal, java_awt_BorderLayout::NORTH);
    listSaidaTerminal = java_awt_ListPtr(new java_awt_List());
    panelBottomLeft->add(listSaidaTerminal, java_awt_BorderLayout::CENTER);
    panelBottom->add(panelBottomLeft, NULL);
    java_awt_LabelPtr labelSaidaBairro = java_awt_LabelPtr(new java_awt_Label());
    labelSaidaBairro->setText(java_lang_StringPtr("Sa�da Bairro"));
    java_awt_PanelPtr panelBottomRight = java_awt_PanelPtr(new java_awt_Panel());
    panelBottomRight->setLayout(java_awt_BorderLayoutPtr(new java_awt_BorderLayout()));
    panelBottomRight->add(labelSaidaBairro, java_awt_BorderLayout::NORTH);
    listSaidaBairro = java_awt_ListPtr(new java_awt_List());
    panelBottomRight->add(listSaidaBairro, java_awt_BorderLayout::CENTER);
    panelBottom->add(panelBottomRight, NULL);
    panelCenter->add(panelBottom, java_awt_BorderLayout::CENTER);
}

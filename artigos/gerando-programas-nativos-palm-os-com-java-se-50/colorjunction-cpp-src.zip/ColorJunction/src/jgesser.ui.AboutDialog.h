#ifndef JGESSER_UI_ABOUTDIALOG_H_
#define JGESSER_UI_ABOUTDIALOG_H_

#include "java.awt.BorderLayout.h"
#include "java.awt.Button.h"
#include "java.awt.Label.h"
#include "java.awt.Frame.h"
#include "java.awt.event.ActionListener.h"
#include "java.awt.FlowLayout.h"
#include "java.awt.event.WindowAdapter.h"
#include "jgesser.ui.AboutDialog.h"
#include "java.awt.Dialog.h"
#include "java.awt.Panel.h"
#include "japa.lang.GC.h"

class jgesser_ui_AboutDialog: public java_awt_Dialog {
    friend class jgesser_ui_MainFrame;
    friend class jgesser_ui_OptionDialog;
    friend class jgesser_ui_AboutDialog_1;
    friend class jgesser_ui_AboutDialog_2;
public: 
    static void show(java_awt_FramePtr owner);

private: 
    jgesser_ui_AboutDialog(java_awt_FramePtr owner);

    void initialize();

};

typedef gc::ptr<jgesser_ui_AboutDialog> jgesser_ui_AboutDialogPtr;

#endif //JGESSER_UI_ABOUTDIALOG_H_

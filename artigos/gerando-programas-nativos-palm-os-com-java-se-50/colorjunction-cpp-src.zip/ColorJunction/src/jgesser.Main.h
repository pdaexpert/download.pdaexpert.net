#ifndef JGESSER_MAIN_H_
#define JGESSER_MAIN_H_

#include "java.lang.Array.h"
#include "java.lang.String.h"
#include "jgesser.ui.MainFrame.h"
#include "japa.lang.GC.h"

class jgesser_Main {
public: 
    static void main(java_lang_ArrayPtr< java_lang_StringPtr > args);

};

typedef gc::ptr<jgesser_Main> jgesser_MainPtr;

#endif //JGESSER_MAIN_H_

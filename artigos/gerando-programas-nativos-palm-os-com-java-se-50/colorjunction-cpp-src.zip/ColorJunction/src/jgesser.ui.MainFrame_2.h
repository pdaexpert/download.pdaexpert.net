#ifndef JGESSER_UI_MAINFRAME_2_H_
#define JGESSER_UI_MAINFRAME_2_H_

#include "java.awt.event.WindowEvent.h"
#include "java.awt.event.WindowAdapter.h"
#include "jgesser.ui.MainFrame.h"
#include "java.lang.System.h"
#include "japa.lang.GC.h"

class jgesser_ui_MainFrame_2: public java_awt_event_WindowAdapter {
    friend class jgesser_ui_AboutDialog;
    friend class jgesser_ui_MainFrame;
    friend class jgesser_ui_OptionDialog;
public: 
    jgesser_ui_MainFrame_2(jgesser_ui_MainFramePtr this_0);

    void windowClosing(java_awt_event_WindowEventPtr e);

private: 
    const jgesser_ui_MainFramePtr this_0;

};

typedef gc::ptr<jgesser_ui_MainFrame_2> jgesser_ui_MainFrame_2Ptr;

#endif //JGESSER_UI_MAINFRAME_2_H_

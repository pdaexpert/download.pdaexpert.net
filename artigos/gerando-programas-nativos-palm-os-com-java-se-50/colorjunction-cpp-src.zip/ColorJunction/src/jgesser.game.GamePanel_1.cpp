#include "jgesser.game.GamePanel_1.h"

jgesser_game_GamePanel_1::jgesser_game_GamePanel_1(jgesser_game_GamePanelPtr this_0): this_0(this_0) {
}

void jgesser_game_GamePanel_1::componentResized(java_awt_event_ComponentEventPtr e) {
    this_0->BLOCK_WIDTH = 0;
}

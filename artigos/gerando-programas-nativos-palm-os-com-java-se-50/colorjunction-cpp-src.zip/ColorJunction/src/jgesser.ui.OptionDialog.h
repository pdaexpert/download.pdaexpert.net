#ifndef JGESSER_UI_OPTIONDIALOG_H_
#define JGESSER_UI_OPTIONDIALOG_H_

#include "java.awt.Button.h"
#include "java.awt.Label.h"
#include "java.awt.Frame.h"
#include "java.awt.event.ActionListener.h"
#include "jgesser.ui.OptionDialog.h"
#include "java.awt.event.WindowAdapter.h"
#include "java.awt.FlowLayout.h"
#include "java.awt.GridLayout.h"
#include "java.awt.Panel.h"
#include "java.awt.BorderLayout.h"
#include "jgesser.game.GamePanel.h"
#include "java.awt.Choice.h"
#include "java.awt.Dialog.h"
#include "japa.lang.GC.h"

class jgesser_ui_OptionDialog: public java_awt_Dialog {
    friend class jgesser_ui_AboutDialog;
    friend class jgesser_ui_MainFrame;
    friend class jgesser_ui_OptionDialog_1;
    friend class jgesser_ui_OptionDialog_2;
    friend class jgesser_ui_OptionDialog_3;
public: 
    static bool show(java_awt_FramePtr owner, jgesser_game_GamePanelPtr game);

protected: 
    java_awt_ChoicePtr choice2;

    java_awt_ChoicePtr choice1;

    bool ok;

    const jgesser_game_GamePanelPtr game;

private: 
    jgesser_ui_OptionDialog(java_awt_FramePtr owner, jgesser_game_GamePanelPtr game);

    void initialize();

};

typedef gc::ptr<jgesser_ui_OptionDialog> jgesser_ui_OptionDialogPtr;

#endif //JGESSER_UI_OPTIONDIALOG_H_

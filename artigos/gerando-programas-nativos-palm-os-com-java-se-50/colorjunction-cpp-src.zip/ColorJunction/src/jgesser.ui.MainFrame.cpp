#include "jgesser.ui.MainFrame.h"
#include "jgesser.ui.MainFrame_6.h"
#include "jgesser.ui.MainFrame_5.h"
#include "jgesser.ui.MainFrame_4.h"
#include "jgesser.ui.MainFrame_3.h"
#include "jgesser.ui.MainFrame_2.h"
#include "jgesser.ui.MainFrame_1.h"

jgesser_ui_MainFrame::jgesser_ui_MainFrame() : java_awt_Frame(java_lang_StringPtr("ColorJunction")) {this->status = java_awt_LabelPtr();
    this->game = jgesser_game_GamePanelPtr();
    
    initialize();
    game->addMouseListener(jgesser_ui_MainFrame_1Ptr(new jgesser_ui_MainFrame_1(jgesser_ui_MainFramePtr(this, true))));
    addWindowListener(jgesser_ui_MainFrame_2Ptr(new jgesser_ui_MainFrame_2(jgesser_ui_MainFramePtr(this, true))));
}

void jgesser_ui_MainFrame::updateStatus() {
    status->setText(java_lang_StringPtr("Pieces left: ") + game->getPiecesLeft());
}

void jgesser_ui_MainFrame::initialize() {
    setSize(335, 405);
    java_awt_MenuBarPtr menuBar = java_awt_MenuBarPtr(new java_awt_MenuBar());
    setMenuBar(menuBar);
    java_awt_MenuPtr menuGame = java_awt_MenuPtr(new java_awt_Menu(java_lang_StringPtr("Game")));
    menuBar->add(menuGame);
    java_awt_MenuPtr menuHelp = java_awt_MenuPtr(new java_awt_Menu(java_lang_StringPtr("Help")));
    menuBar->add(menuHelp);
    java_awt_MenuItemPtr item = java_awt_MenuItemPtr(new java_awt_MenuItem(java_lang_StringPtr("New"), java_awt_MenuShortcutPtr(new java_awt_MenuShortcut(java_awt_event_KeyEvent::VK_N))));
    menuGame->add(item);
    java_awt_event_ActionListenerPtr newGameActionListener = jgesser_ui_MainFrame_3Ptr(new jgesser_ui_MainFrame_3(jgesser_ui_MainFramePtr(this, true)));
    item->addActionListener(newGameActionListener);
    item = java_awt_MenuItemPtr(new java_awt_MenuItem(java_lang_StringPtr("Configure..."), java_awt_MenuShortcutPtr(new java_awt_MenuShortcut(java_awt_event_KeyEvent::VK_C))));
    menuGame->add(item);
    java_awt_event_ActionListenerPtr confgActionListener = jgesser_ui_MainFrame_4Ptr(new jgesser_ui_MainFrame_4(jgesser_ui_MainFramePtr(this, true)));
    item->addActionListener(confgActionListener);
    menuGame->addSeparator();
    item = java_awt_MenuItemPtr(new java_awt_MenuItem(java_lang_StringPtr("Exit"), java_awt_MenuShortcutPtr(new java_awt_MenuShortcut(java_awt_event_KeyEvent::VK_X))));
    menuGame->add(item);
    item->addActionListener(jgesser_ui_MainFrame_5Ptr(new jgesser_ui_MainFrame_5(jgesser_ui_MainFramePtr(this, true))));
    item = java_awt_MenuItemPtr(new java_awt_MenuItem(java_lang_StringPtr("About..."), java_awt_MenuShortcutPtr(new java_awt_MenuShortcut(java_awt_event_KeyEvent::VK_A))));
    menuHelp->add(item);
    item->addActionListener(jgesser_ui_MainFrame_6Ptr(new jgesser_ui_MainFrame_6(jgesser_ui_MainFramePtr(this, true))));
    game = jgesser_game_GamePanelPtr(new jgesser_game_GamePanel());
    add(game, java_awt_BorderLayout::CENTER);
    java_awt_PanelPtr bottom = java_awt_PanelPtr(new java_awt_Panel(java_awt_BorderLayoutPtr(new java_awt_BorderLayout())));
    bottom->setBackground(java_awt_SystemColor::control);
    add(bottom, java_awt_BorderLayout::SOUTH);
    status = java_awt_LabelPtr(new java_awt_Label(java_lang_StringPtr("Pieces left: ") + game->getPiecesLeft(), java_awt_Label::RIGHT));
    bottom->add(status, java_awt_BorderLayout::EAST);
    java_awt_PanelPtr panel = java_awt_PanelPtr(new java_awt_Panel());
    java_awt_ButtonPtr newGameButton = java_awt_ButtonPtr(new java_awt_Button(java_lang_StringPtr("New")));
    panel->add(newGameButton);
    newGameButton->addActionListener(newGameActionListener);
    java_awt_ButtonPtr aboutButton = java_awt_ButtonPtr(new java_awt_Button(java_lang_StringPtr("Config...")));
    aboutButton->addActionListener(confgActionListener);
    panel->add(aboutButton);
    bottom->add(panel, java_awt_BorderLayout::WEST);
}

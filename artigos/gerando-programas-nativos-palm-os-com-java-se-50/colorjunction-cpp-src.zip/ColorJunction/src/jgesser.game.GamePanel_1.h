#ifndef JGESSER_GAME_GAMEPANEL_1_H_
#define JGESSER_GAME_GAMEPANEL_1_H_

#include "java.awt.event.ComponentEvent.h"
#include "java.awt.event.ComponentAdapter.h"
#include "jgesser.game.GamePanel.h"
#include "japa.lang.GC.h"

class jgesser_game_GamePanel_1: public java_awt_event_ComponentAdapter {
    friend class jgesser_game_GamePanel;
public: 
    jgesser_game_GamePanel_1(jgesser_game_GamePanelPtr this_0);

    void componentResized(java_awt_event_ComponentEventPtr e);

private: 
    const jgesser_game_GamePanelPtr this_0;

};

typedef gc::ptr<jgesser_game_GamePanel_1> jgesser_game_GamePanel_1Ptr;

#endif //JGESSER_GAME_GAMEPANEL_1_H_

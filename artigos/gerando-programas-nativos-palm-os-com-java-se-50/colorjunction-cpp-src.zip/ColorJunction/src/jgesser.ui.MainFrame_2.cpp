#include "jgesser.ui.MainFrame_2.h"

jgesser_ui_MainFrame_2::jgesser_ui_MainFrame_2(jgesser_ui_MainFramePtr this_0): this_0(this_0) {
}

void jgesser_ui_MainFrame_2::windowClosing(java_awt_event_WindowEventPtr e) {
    this_0->setVisible(false);
    this_0->dispose();
    java_lang_System::exit(0);
}

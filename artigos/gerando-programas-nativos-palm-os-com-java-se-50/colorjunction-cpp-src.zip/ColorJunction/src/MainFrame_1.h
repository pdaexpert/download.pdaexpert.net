#ifndef MAINFRAME_1_H_
#define MAINFRAME_1_H_

#include "java.awt.event.WindowEvent.h"
#include "java.awt.event.WindowAdapter.h"
#include "java.lang.System.h"
#include "MainFrame.h"
#include "japa.lang.GC.h"

class MainFrame_1: public java_awt_event_WindowAdapter {
    friend class BorderedPanel;
    friend class MainFrame;
public: 
    MainFrame_1(MainFramePtr this_0);

    void windowClosing(java_awt_event_WindowEventPtr e);

private: 
    const MainFramePtr this_0;

};

typedef gc::ptr<MainFrame_1> MainFrame_1Ptr;

#endif //MAINFRAME_1_H_

#include "jgesser.ui.OptionDialog_3.h"

jgesser_ui_OptionDialog_3::jgesser_ui_OptionDialog_3(jgesser_ui_OptionDialogPtr this_0): this_0(this_0) {
}

void jgesser_ui_OptionDialog_3::actionPerformed(java_awt_event_ActionEventPtr e) {
    this_0->ok = false;
    this_0->setVisible(false);
}

#include "jgesser.ui.OptionDialog_1.h"

jgesser_ui_OptionDialog_1::jgesser_ui_OptionDialog_1(jgesser_ui_OptionDialogPtr this_0): this_0(this_0) {
}

void jgesser_ui_OptionDialog_1::windowClosing(java_awt_event_WindowEventPtr e) {
    this_0->setVisible(false);
}

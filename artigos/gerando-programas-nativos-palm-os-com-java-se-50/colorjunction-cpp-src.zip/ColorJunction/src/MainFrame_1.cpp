#include "MainFrame_1.h"

MainFrame_1::MainFrame_1(MainFramePtr this_0): this_0(this_0) {

}

void MainFrame_1::windowClosing(java_awt_event_WindowEventPtr e) {
    this_0->setVisible(false);
    this_0->dispose();
    java_lang_System::exit(0);
}

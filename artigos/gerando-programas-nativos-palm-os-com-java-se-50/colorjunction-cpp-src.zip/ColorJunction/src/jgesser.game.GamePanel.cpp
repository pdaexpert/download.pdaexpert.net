#include "jgesser.game.GamePanel.h"
#include "jgesser.game.GamePanel_1.h"
#include "jgesser.game.GamePanel_2.h"

jgesser_game_GamePanel::jgesser_game_GamePanel() {
    this->numBlocks = 0;
    this->colors = java_lang_ArrayPtr< java_awt_ColorPtr >(6).set(0, java_awt_ColorPtr(new java_awt_Color(255, 255, 255))).set(1, java_awt_ColorPtr(new java_awt_Color(164, 31, 98))).set(2, java_awt_ColorPtr(new java_awt_Color(95, 159, 0))).set(3, java_awt_ColorPtr(new java_awt_Color(0, 31, 162))).set(4, java_awt_ColorPtr(new java_awt_Color(255, 163, 0))).set(5, java_awt_ColorPtr(new java_awt_Color(164, 100, 0)));
    this->BLOCK_WIDTH = 0;
    this->TABLE_POS_X = 0;
    this->TABLE_POS_Y = 0;
    this->TABLE_BORDER = 0;
    this->numColors = 0;
    this->BLOCK_SPACING = 0;
    this->board = java_lang_ArrayPtr< java_lang_ArrayPtr< int > >();
    this->BLOCK_ROUNDING = 0;
    this->TABLE_WIDTH = 0;
    this->piecesLeft = 0;
    setNumBlocks(15);
    setNumColors(4);
    addComponentListener(jgesser_game_GamePanel_1Ptr(new jgesser_game_GamePanel_1(jgesser_game_GamePanelPtr(this, true))));
    addMouseListener(jgesser_game_GamePanel_2Ptr(new jgesser_game_GamePanel_2(jgesser_game_GamePanelPtr(this, true))));
    newGame();
}

void jgesser_game_GamePanel::setNumColors(int numColors) {
    this->numColors = numColors;
}

int jgesser_game_GamePanel::getNumColors() {
    return numColors;
}

void jgesser_game_GamePanel::setNumBlocks(int numBlocks) {
    this->numBlocks = numBlocks;
}

int jgesser_game_GamePanel::getNumBlocks() {
    return numBlocks;
}

void jgesser_game_GamePanel::newGame() {
    board = java_lang_ArrayPtr< java_lang_ArrayPtr< int > >(numBlocks).sub(1,numBlocks);
    java_util_RandomPtr random = java_util_RandomPtr(new java_util_Random());
    for (int i = 0; i < numBlocks; i++) {
        for (int j = 0; j < numBlocks; j++) {
            board[i][j] = random->nextInt(numColors) + 1;
        }
    }
    piecesLeft = numBlocks * numBlocks;
    BLOCK_WIDTH = 0;
    repaint();
}

void jgesser_game_GamePanel::click(int x, int y) {
    if (x >= TABLE_POS_X + TABLE_BORDER && y >= TABLE_POS_Y + TABLE_BORDER) {
        x = (x - TABLE_BORDER - TABLE_POS_X + BLOCK_SPACING) / (BLOCK_WIDTH + BLOCK_SPACING);
        y = (y - TABLE_BORDER - TABLE_POS_Y + BLOCK_SPACING) / (BLOCK_WIDTH + BLOCK_SPACING);
        if (x < numBlocks && y < numBlocks) {
            if (board[x][y] != 0) {
                java_lang_ArrayPtr< int > ret = java_lang_ArrayPtr< int >(1).set(0, 0);
                int color = board[x][y];
                mark(color, x, y, ret);
                if (ret[0] == 1) {
                    board[x][y] = color;
                } else if (ret[0] > 1) {
                    piecesLeft -= ret[0];
                    rearrange();
                    repaint();
                }
            }
        }
    }
}

void jgesser_game_GamePanel::mark(int color, int x, int y, java_lang_ArrayPtr< int > ret) {
    if (board[x][y] == color) {
        ret[0]++;
        board[x][y] = 0;
        if (x > 0) {
            mark(color, x - 1, y, ret);
        }
        if (x < numBlocks - 1) {
            mark(color, x + 1, y, ret);
        }
        if (y > 0) {
            mark(color, x, y - 1, ret);
        }
        if (y < numBlocks - 1) {
            mark(color, x, y + 1, ret);
        }
    }
}

void jgesser_game_GamePanel::rearrange() {
    for (int x = 0; x < numBlocks; x++) {
        int hole = 0;
        for (int y = numBlocks - 1; y >= 0; y--) {
            if (board[x][y] != 0) {
                if (hole > 0) {
                    board[x][y + hole] = board[x][y];
                    board[x][y] = 0;
                }
            } else {
                hole++;
            }
        }
    }
    int hole = 0;
    for (int x = 0; x < numBlocks; x++) {
        if (board[x][numBlocks - 1] != 0) {
            if (hole > 0) {
                java_lang_ArrayPtr< int > temp = board[x - hole];
                board[x - hole] = board[x];
                board[x] = temp;
            }
        } else {
            hole++;
        }
    }
}

void jgesser_game_GamePanel::paint(java_awt_GraphicsPtr g) {
    if (BLOCK_WIDTH == 0) {
        int dim = getHeight();
        if (getWidth() < dim) {
            dim = getWidth();
        }
        BLOCK_SPACING = dim / numBlocks / 10;
        BLOCK_WIDTH = (dim - (numBlocks * BLOCK_SPACING)) / (numBlocks + 1);
        TABLE_BORDER = BLOCK_SPACING * 2;
        TABLE_WIDTH = ((BLOCK_WIDTH + BLOCK_SPACING) * numBlocks) - BLOCK_SPACING + (TABLE_BORDER * 2);
        BLOCK_ROUNDING = BLOCK_WIDTH / 2;
        TABLE_POS_X = (getWidth() - TABLE_WIDTH) / 2;
        TABLE_POS_Y = (getHeight() - TABLE_WIDTH) / 2;
    }
    g->setColor(java_awt_Color::BLACK);
    g->drawRect(TABLE_POS_X, TABLE_POS_Y, TABLE_WIDTH, TABLE_WIDTH);
    bool gameOver = true;
    for (int x = 0; x < numBlocks; x++) {
        for (int y = 0; y < numBlocks; y++) {
            if (board[x][y] == 0) {
                continue;
            }
            g->setColor(colors[board[x][y]]);
            int bx = x * (BLOCK_WIDTH + BLOCK_SPACING) + TABLE_BORDER + TABLE_POS_X;
            int by = y * (BLOCK_WIDTH + BLOCK_SPACING) + TABLE_BORDER + TABLE_POS_Y;
            g->fillRoundRect(bx, by, BLOCK_WIDTH, BLOCK_WIDTH, BLOCK_ROUNDING, BLOCK_ROUNDING);
            if (x + 1 < numBlocks && board[x][y] == board[x + 1][y]) {
                g->fillRect(bx + BLOCK_WIDTH / 2, by, BLOCK_WIDTH, BLOCK_WIDTH);
                gameOver = false;
            }
            if (y + 1 < numBlocks && board[x][y] == board[x][y + 1]) {
                g->fillRect(bx, by + BLOCK_WIDTH / 2, BLOCK_WIDTH, BLOCK_WIDTH);
                gameOver = false;
            }
        }
    }
    if (gameOver) {
        java_awt_FontPtr f = g->getFont()->deriveFont(java_awt_Font::BOLD, 40);
        g->setFont(f);
        int w = g->getFontMetrics(f)->stringWidth(java_lang_StringPtr("Game Over"));
        g->setColor(java_awt_Color::WHITE);
        g->drawString(java_lang_StringPtr("Game Over"), (getWidth() - w) / 2, getHeight() / 2);
        g->setColor(java_awt_Color::BLACK);
        g->drawString(java_lang_StringPtr("Game Over"), (getWidth() - w) / 2 + 1, getHeight() / 2 + 1);
    }
}

int jgesser_game_GamePanel::getPiecesLeft() {
    return piecesLeft;
}

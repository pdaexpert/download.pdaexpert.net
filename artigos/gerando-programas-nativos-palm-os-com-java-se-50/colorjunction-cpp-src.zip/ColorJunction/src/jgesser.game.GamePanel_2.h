#ifndef JGESSER_GAME_GAMEPANEL_2_H_
#define JGESSER_GAME_GAMEPANEL_2_H_

#include "java.awt.event.MouseEvent.h"
#include "jgesser.game.GamePanel.h"
#include "java.awt.event.MouseAdapter.h"
#include "japa.lang.GC.h"

class jgesser_game_GamePanel_2: public java_awt_event_MouseAdapter {
    friend class jgesser_game_GamePanel;
public: 
    jgesser_game_GamePanel_2(jgesser_game_GamePanelPtr this_0);

    void mouseClicked(java_awt_event_MouseEventPtr e);

private: 
    const jgesser_game_GamePanelPtr this_0;

};

typedef gc::ptr<jgesser_game_GamePanel_2> jgesser_game_GamePanel_2Ptr;

#endif //JGESSER_GAME_GAMEPANEL_2_H_

#include "jgesser.ui.MainFrame_6.h"

jgesser_ui_MainFrame_6::jgesser_ui_MainFrame_6(jgesser_ui_MainFramePtr this_0): this_0(this_0) {
}

void jgesser_ui_MainFrame_6::actionPerformed(java_awt_event_ActionEventPtr e) {
    jgesser_ui_AboutDialog::show(this_0);
}

#ifndef JGESSER_UI_ABOUTDIALOG_1_H_
#define JGESSER_UI_ABOUTDIALOG_1_H_

#include "java.awt.event.WindowEvent.h"
#include "java.awt.event.WindowAdapter.h"
#include "jgesser.ui.AboutDialog.h"
#include "japa.lang.GC.h"

class jgesser_ui_AboutDialog_1: public java_awt_event_WindowAdapter {
    friend class jgesser_ui_AboutDialog;
    friend class jgesser_ui_MainFrame;
    friend class jgesser_ui_OptionDialog;
public: 
    jgesser_ui_AboutDialog_1(jgesser_ui_AboutDialogPtr this_0);

    void windowClosing(java_awt_event_WindowEventPtr e);

private: 
    const jgesser_ui_AboutDialogPtr this_0;

};

typedef gc::ptr<jgesser_ui_AboutDialog_1> jgesser_ui_AboutDialog_1Ptr;

#endif //JGESSER_UI_ABOUTDIALOG_1_H_

#include "jgesser.ui.AboutDialog_2.h"

jgesser_ui_AboutDialog_2::jgesser_ui_AboutDialog_2(jgesser_ui_AboutDialogPtr this_0): this_0(this_0) {
}

void jgesser_ui_AboutDialog_2::actionPerformed(java_awt_event_ActionEventPtr e) {
    this_0->setVisible(false);
}

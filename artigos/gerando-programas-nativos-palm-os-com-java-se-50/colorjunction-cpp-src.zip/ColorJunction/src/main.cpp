#include "jgesser.Main.h"

UInt32 PilotMain (UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags) {
	switch (cmd) {
		case sysAppLaunchCmdNormalLaunch: {
			jgesser_Main::main(NULL);
			break;
		}
			
	}

	return errNone;
}

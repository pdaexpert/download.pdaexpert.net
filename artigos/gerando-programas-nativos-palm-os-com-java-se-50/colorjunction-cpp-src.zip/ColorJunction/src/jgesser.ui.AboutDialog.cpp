#include "jgesser.ui.AboutDialog.h"
#include "jgesser.ui.AboutDialog_2.h"
#include "jgesser.ui.AboutDialog_1.h"

jgesser_ui_AboutDialog::jgesser_ui_AboutDialog(java_awt_FramePtr owner) : java_awt_Dialog(owner, java_lang_StringPtr("About")) {    
    initialize();
    addWindowListener(jgesser_ui_AboutDialog_1Ptr(new jgesser_ui_AboutDialog_1(jgesser_ui_AboutDialogPtr(this, true))));
}

void jgesser_ui_AboutDialog::show(java_awt_FramePtr owner) {
    jgesser_ui_AboutDialogPtr ad = jgesser_ui_AboutDialogPtr(new jgesser_ui_AboutDialog(owner));
    ad->setLocation(owner->getX() + ((owner->getWidth() - ad->getWidth()) / 2), owner->getY() + ((owner->getHeight() - ad->getHeight()) / 2));
    ad->setVisible(true);
    ad->dispose();
}

void jgesser_ui_AboutDialog::initialize() {
    setSize(200, 200);
    setResizable(false);
    setModal(true);
    java_awt_PanelPtr panel1 = java_awt_PanelPtr(new java_awt_Panel(java_awt_FlowLayoutPtr(new java_awt_FlowLayout())));
    panel1->add(java_awt_LabelPtr(new java_awt_Label(java_lang_StringPtr("ColorJunction v1.0"))));
    panel1->add(java_awt_LabelPtr(new java_awt_Label(java_lang_StringPtr("Programmed by"))));
    panel1->add(java_awt_LabelPtr(new java_awt_Label(java_lang_StringPtr("Julio Vilmar Gesser"))));
    panel1->add(java_awt_LabelPtr(new java_awt_Label(java_lang_StringPtr("jgesser@gmail.com"))));
    this->add(panel1, java_awt_BorderLayout::CENTER);
    java_awt_PanelPtr panel2 = java_awt_PanelPtr(new java_awt_Panel());
    panel2->setLayout(java_awt_FlowLayoutPtr(new java_awt_FlowLayout()));
    java_awt_ButtonPtr buttonOk = java_awt_ButtonPtr(new java_awt_Button());
    buttonOk->setLabel(java_lang_StringPtr("OK"));
    buttonOk->addActionListener(jgesser_ui_AboutDialog_2Ptr(new jgesser_ui_AboutDialog_2(jgesser_ui_AboutDialogPtr(this, true))));
    panel2->add(buttonOk);
    this->add(panel2, java_awt_BorderLayout::SOUTH);
}

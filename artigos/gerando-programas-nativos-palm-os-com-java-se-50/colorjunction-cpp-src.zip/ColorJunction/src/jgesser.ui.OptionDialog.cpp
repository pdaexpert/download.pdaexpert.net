#include "jgesser.ui.OptionDialog.h"
#include "jgesser.ui.OptionDialog_3.h"
#include "jgesser.ui.OptionDialog_1.h"
#include "jgesser.ui.OptionDialog_2.h"

jgesser_ui_OptionDialog::jgesser_ui_OptionDialog(java_awt_FramePtr owner, jgesser_game_GamePanelPtr game) : java_awt_Dialog(owner, java_lang_StringPtr("Options")), game(game) {this->choice2 = java_awt_ChoicePtr();
    this->choice1 = java_awt_ChoicePtr();
    this->ok = false;
    
    initialize();
    addWindowListener(jgesser_ui_OptionDialog_1Ptr(new jgesser_ui_OptionDialog_1(jgesser_ui_OptionDialogPtr(this, true))));
}

bool jgesser_ui_OptionDialog::show(java_awt_FramePtr owner, jgesser_game_GamePanelPtr game) {
    jgesser_ui_OptionDialogPtr od = jgesser_ui_OptionDialogPtr(new jgesser_ui_OptionDialog(owner, game));
    od->setLocation(owner->getX() + ((owner->getWidth() - od->getWidth()) / 2), owner->getY() + ((owner->getHeight() - od->getHeight()) / 2));
    od->setVisible(true);
    od->dispose();
    return od->ok;
}

void jgesser_ui_OptionDialog::initialize() {
    setSize(250, 117);
    setResizable(false);
    setModal(true);
    java_awt_GridLayoutPtr gridLayout = java_awt_GridLayoutPtr(new java_awt_GridLayout());
    gridLayout->setHgap(2);
    gridLayout->setVgap(2);
    gridLayout->setRows(2);
    gridLayout->setColumns(2);
    java_awt_PanelPtr panel1 = java_awt_PanelPtr(new java_awt_Panel());
    panel1->setLayout(gridLayout);
    java_awt_LabelPtr label1 = java_awt_LabelPtr(new java_awt_Label());
    label1->setText(java_lang_StringPtr("Difficulty"));
    label1->setAlignment(java_awt_Label::RIGHT);
    java_awt_LabelPtr label2 = java_awt_LabelPtr(new java_awt_Label());
    label2->setText(java_lang_StringPtr("Board Size"));
    label2->setAlignment(java_awt_Label::RIGHT);
    choice1 = java_awt_ChoicePtr(new java_awt_Choice());
    choice1->addItem(java_lang_StringPtr("Easy"));
    choice1->addItem(java_lang_StringPtr("Medium"));
    choice1->addItem(java_lang_StringPtr("Hard"));
    switch(game->getNumColors()) {
        case 3:
            choice1->select(0);
            break;
        case 4:
            choice1->select(1);
            break;
        case 5:
            choice1->select(2);
            break;
    }
    choice2 = java_awt_ChoicePtr(new java_awt_Choice());
    choice2->addItem(java_lang_StringPtr("Small (10x10)"));
    choice2->addItem(java_lang_StringPtr("Medium (15x15)"));
    choice2->addItem(java_lang_StringPtr("Large (20x20)"));
    switch(game->getNumBlocks()) {
        case 10:
            choice2->select(0);
            break;
        case 15:
            choice2->select(1);
            break;
        case 20:
            choice2->select(2);
            break;
    }
    panel1->add(label1);
    panel1->add(choice1);
    panel1->add(label2);
    panel1->add(choice2);
    this->add(panel1, java_awt_BorderLayout::CENTER);
    java_awt_PanelPtr panel2 = java_awt_PanelPtr(new java_awt_Panel());
    panel2->setLayout(java_awt_FlowLayoutPtr(new java_awt_FlowLayout()));
    java_awt_ButtonPtr buttonOk = java_awt_ButtonPtr(new java_awt_Button());
    buttonOk->setLabel(java_lang_StringPtr("Ok"));
    buttonOk->addActionListener(jgesser_ui_OptionDialog_2Ptr(new jgesser_ui_OptionDialog_2(jgesser_ui_OptionDialogPtr(this, true))));
    java_awt_ButtonPtr buttonCancel = java_awt_ButtonPtr(new java_awt_Button());
    buttonCancel->setLabel(java_lang_StringPtr("Cancel"));
    buttonCancel->addActionListener(jgesser_ui_OptionDialog_3Ptr(new jgesser_ui_OptionDialog_3(jgesser_ui_OptionDialogPtr(this, true))));
    panel2->add(buttonOk);
    panel2->add(buttonCancel);
    this->add(panel2, java_awt_BorderLayout::SOUTH);
}

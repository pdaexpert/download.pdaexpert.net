#include "jgesser.ui.MainFrame_1.h"

jgesser_ui_MainFrame_1::jgesser_ui_MainFrame_1(jgesser_ui_MainFramePtr this_0): this_0(this_0) {
}

void jgesser_ui_MainFrame_1::mouseClicked(java_awt_event_MouseEventPtr e) {
    this_0->updateStatus();
}

#include "jgesser.ui.MainFrame_5.h"

jgesser_ui_MainFrame_5::jgesser_ui_MainFrame_5(jgesser_ui_MainFramePtr this_0): this_0(this_0) {
}

void jgesser_ui_MainFrame_5::actionPerformed(java_awt_event_ActionEventPtr e) {
    this_0->setVisible(false);
    this_0->dispose();
    java_lang_System::exit(0);
}

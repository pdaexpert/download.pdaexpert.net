#ifndef JGESSER_UI_MAINFRAME_1_H_
#define JGESSER_UI_MAINFRAME_1_H_

#include "java.awt.event.MouseEvent.h"
#include "jgesser.ui.MainFrame.h"
#include "java.awt.event.MouseAdapter.h"
#include "japa.lang.GC.h"

class jgesser_ui_MainFrame_1: public java_awt_event_MouseAdapter {
    friend class jgesser_ui_AboutDialog;
    friend class jgesser_ui_MainFrame;
    friend class jgesser_ui_OptionDialog;
public: 
    jgesser_ui_MainFrame_1(jgesser_ui_MainFramePtr this_0);

    void mouseClicked(java_awt_event_MouseEventPtr e);

private: 
    const jgesser_ui_MainFramePtr this_0;

};

typedef gc::ptr<jgesser_ui_MainFrame_1> jgesser_ui_MainFrame_1Ptr;

#endif //JGESSER_UI_MAINFRAME_1_H_

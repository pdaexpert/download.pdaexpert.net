#include "jgesser.ui.MainFrame_3.h"

jgesser_ui_MainFrame_3::jgesser_ui_MainFrame_3(jgesser_ui_MainFramePtr this_0): this_0(this_0) {
}

void jgesser_ui_MainFrame_3::actionPerformed(java_awt_event_ActionEventPtr e) {
    this_0->game->newGame();
    this_0->updateStatus();
}

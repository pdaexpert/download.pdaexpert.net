#ifndef MAINFRAME_H_
#define MAINFRAME_H_

#include "java.awt.Label.h"
#include "java.awt.Frame.h"
#include "java.lang.String.h"
#include "java.awt.event.WindowAdapter.h"
#include "java.awt.Font.h"
#include "java.awt.Panel.h"
#include "java.awt.GridLayout.h"
#include "java.awt.BorderLayout.h"
#include "java.lang.Array.h"
#include "BorderedPanel.h"
#include "java.awt.List.h"
#include "java.awt.Choice.h"
#include "MainFrame.h"
#include "japa.lang.GC.h"

class MainFrame: public java_awt_Frame {
    friend class BorderedPanel;
    friend class MainFrame_1;
public: 
    MainFrame();

    static void main(java_lang_ArrayPtr< java_lang_StringPtr > args);

private: 
    java_awt_ChoicePtr choiceDia;

    java_awt_ListPtr listSaidaBairro;

    java_awt_ChoicePtr choiceLinha;

    java_awt_ListPtr listSaidaTerminal;

    static const int BORDER;

    virtual void initialize();

};

typedef gc::ptr<MainFrame> MainFramePtr;

#endif //MAINFRAME_H_

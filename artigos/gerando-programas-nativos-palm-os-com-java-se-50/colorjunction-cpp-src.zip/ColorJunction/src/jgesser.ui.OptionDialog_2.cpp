#include "jgesser.ui.OptionDialog_2.h"

jgesser_ui_OptionDialog_2::jgesser_ui_OptionDialog_2(jgesser_ui_OptionDialogPtr this_0): this_0(this_0) {
}

void jgesser_ui_OptionDialog_2::actionPerformed(java_awt_event_ActionEventPtr e) {
    switch(this_0->choice1->getSelectedIndex()) {
        case 0:
            this_0->game->setNumColors(3);
            break;
        case 1:
            this_0->game->setNumColors(4);
            break;
        case 2:
            this_0->game->setNumColors(5);
            break;
    }
    switch(this_0->choice2->getSelectedIndex()) {
        case 0:
            this_0->game->setNumBlocks(10);
            break;
        case 1:
            this_0->game->setNumBlocks(15);
            break;
        case 2:
            this_0->game->setNumBlocks(20);
            break;
    }
    this_0->ok = true;
    this_0->setVisible(false);
}

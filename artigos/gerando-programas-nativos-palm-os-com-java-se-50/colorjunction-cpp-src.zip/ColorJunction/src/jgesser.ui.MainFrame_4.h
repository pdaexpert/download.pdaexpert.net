#ifndef JGESSER_UI_MAINFRAME_4_H_
#define JGESSER_UI_MAINFRAME_4_H_

#include "java.awt.event.ActionEvent.h"
#include "java.awt.event.ActionListener.h"
#include "jgesser.ui.OptionDialog.h"
#include "jgesser.ui.MainFrame.h"
#include "japa.lang.GC.h"

class jgesser_ui_MainFrame_4: public java_awt_event_ActionListener {
    friend class jgesser_ui_AboutDialog;
    friend class jgesser_ui_MainFrame;
    friend class jgesser_ui_OptionDialog;
public: 
    jgesser_ui_MainFrame_4(jgesser_ui_MainFramePtr this_0);

    void actionPerformed(java_awt_event_ActionEventPtr e);

private: 
    const jgesser_ui_MainFramePtr this_0;

};

typedef gc::ptr<jgesser_ui_MainFrame_4> jgesser_ui_MainFrame_4Ptr;

#endif //JGESSER_UI_MAINFRAME_4_H_

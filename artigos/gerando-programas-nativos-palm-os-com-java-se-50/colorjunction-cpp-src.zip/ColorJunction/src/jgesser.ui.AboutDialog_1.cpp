#include "jgesser.ui.AboutDialog_1.h"

jgesser_ui_AboutDialog_1::jgesser_ui_AboutDialog_1(jgesser_ui_AboutDialogPtr this_0): this_0(this_0) {
}

void jgesser_ui_AboutDialog_1::windowClosing(java_awt_event_WindowEventPtr e) {
    this_0->setVisible(false);
}

#include "BorderedPanel.h"

BorderedPanel::BorderedPanel(int border, java_awt_LayoutManagerPtr mgr) : java_awt_Panel(mgr), border(border) {
    
}
BorderedPanel::BorderedPanel(int border): border(border) {

}

java_awt_InsetsPtr BorderedPanel::getInsets() {
    return java_awt_InsetsPtr(new java_awt_Insets(border, border, border, border));
}

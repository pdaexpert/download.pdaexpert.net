#ifndef JGESSER_UI_MAINFRAME_H_
#define JGESSER_UI_MAINFRAME_H_

#include "java.awt.Menu.h"
#include "java.awt.Button.h"
#include "java.awt.Label.h"
#include "java.awt.MenuItem.h"
#include "java.awt.event.KeyEvent.h"
#include "java.awt.Frame.h"
#include "java.awt.event.ActionListener.h"
#include "java.awt.event.WindowAdapter.h"
#include "java.awt.Panel.h"
#include "java.awt.BorderLayout.h"
#include "java.awt.MenuBar.h"
#include "jgesser.game.GamePanel.h"
#include "java.awt.SystemColor.h"
#include "java.awt.event.MouseAdapter.h"
#include "java.awt.MenuShortcut.h"
#include "japa.lang.GC.h"

class jgesser_ui_MainFrame: public java_awt_Frame {
    friend class jgesser_ui_AboutDialog;
    friend class jgesser_ui_OptionDialog;
    friend class jgesser_ui_MainFrame_1;
    friend class jgesser_ui_MainFrame_2;
    friend class jgesser_ui_MainFrame_3;
    friend class jgesser_ui_MainFrame_4;
    friend class jgesser_ui_MainFrame_5;
    friend class jgesser_ui_MainFrame_6;
public: 
    jgesser_ui_MainFrame();

protected: 
    jgesser_game_GamePanelPtr game;

    virtual void updateStatus();

private: 
    java_awt_LabelPtr status;

    virtual void initialize();

};

typedef gc::ptr<jgesser_ui_MainFrame> jgesser_ui_MainFramePtr;

#endif //JGESSER_UI_MAINFRAME_H_

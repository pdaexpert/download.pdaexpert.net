/*
 * Created on 20/08/2006
 */
package jgesser.game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Panel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

/**
 * @author Julio Vilmar Gesser
 */
public final class GamePanel extends Panel {

    private int TABLE_BORDER;

    private int BLOCK_WIDTH;

    private int BLOCK_SPACING;

    private int BLOCK_ROUNDING;

    private int TABLE_POS_X;

    private int TABLE_POS_Y;

    private int TABLE_WIDTH;

    private int numBlocks;

    private int numColors;

    private int[][] board;

    private int piecesLeft;

    private final Color[] colors = new Color[] { //
    new Color(255, 255, 255), //bg color
            new Color(164, 31, 98), //
            new Color(95, 159, 0), //
            new Color(0, 31, 162), //
            new Color(255, 163, 0), //
            new Color(164, 100, 0) //
    };

    public GamePanel() {
        setNumBlocks(15);
        setNumColors(4);

        addComponentListener(new ComponentAdapter() {

            @Override
            public void componentResized(ComponentEvent e) {
                BLOCK_WIDTH = 0;
            }
        });

        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                click(e.getX(), e.getY());
            }
        });

        newGame();
    }

    public void setNumColors(int numColors) {
        this.numColors = numColors;
    }

    public int getNumColors() {
        return numColors;
    }

    public void setNumBlocks(int numBlocks) {
        this.numBlocks = numBlocks;
    }

    public int getNumBlocks() {
        return numBlocks;
    }

    public void newGame() {
        board = new int[numBlocks][numBlocks];

        Random random = new Random();

        for (int i = 0; i < numBlocks; i++) {
            for (int j = 0; j < numBlocks; j++) {
                board[i][j] = random.nextInt(numColors) + 1;
            }
        }

        piecesLeft = numBlocks * numBlocks;
        BLOCK_WIDTH = 0;
        repaint();
    }

    void click(int x, int y) {
        if (x >= TABLE_POS_X + TABLE_BORDER && y >= TABLE_POS_Y + TABLE_BORDER) {

            x = (x - TABLE_BORDER - TABLE_POS_X + BLOCK_SPACING) / (BLOCK_WIDTH + BLOCK_SPACING);
            y = (y - TABLE_BORDER - TABLE_POS_Y + BLOCK_SPACING) / (BLOCK_WIDTH + BLOCK_SPACING);

            if (x < numBlocks && y < numBlocks) {
                if (board[x][y] != 0) {
                    int[] ret = new int[] { 0 };
                    int color = board[x][y];
                    mark(color, x, y, ret);
                    if (ret[0] == 1) {
                        board[x][y] = color;
                    } else if (ret[0] > 1) {
                        piecesLeft -= ret[0];
                        rearrange();
                        repaint();
                    }
                }
            }
        }
    }

    private void mark(int color, int x, int y, int[] ret) {
        if (board[x][y] == color) {
            ret[0]++;
            board[x][y] = 0;
            if (x > 0) {
                mark(color, x - 1, y, ret);
            }
            if (x < numBlocks - 1) {
                mark(color, x + 1, y, ret);
            }
            if (y > 0) {
                mark(color, x, y - 1, ret);
            }
            if (y < numBlocks - 1) {
                mark(color, x, y + 1, ret);
            }
        }
    }

    private void rearrange() {
        for (int x = 0; x < numBlocks; x++) {
            int hole = 0;
            for (int y = numBlocks - 1; y >= 0; y--) {
                if (board[x][y] != 0) {
                    if (hole > 0) {
                        board[x][y + hole] = board[x][y];
                        board[x][y] = 0;
                    }
                } else {
                    hole++;
                }
            }
        }
        int hole = 0;
        for (int x = 0; x < numBlocks; x++) {
            if (board[x][numBlocks - 1] != 0) {
                if (hole > 0) {
                    int[] temp = board[x - hole];
                    board[x - hole] = board[x];
                    board[x] = temp;
                }
            } else {
                hole++;
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        if (BLOCK_WIDTH == 0) { // inicializa constantes
            int dim = getHeight();
            if (getWidth() < dim) {
                dim = getWidth();
            }

            BLOCK_SPACING = dim / numBlocks / 10;
            BLOCK_WIDTH = (dim - (numBlocks * BLOCK_SPACING)) / (numBlocks + 1);
            TABLE_BORDER = BLOCK_SPACING * 2;
            TABLE_WIDTH = ((BLOCK_WIDTH + BLOCK_SPACING) * numBlocks) - BLOCK_SPACING + (TABLE_BORDER * 2);

            BLOCK_ROUNDING = BLOCK_WIDTH / 2;
            TABLE_POS_X = (getWidth() - TABLE_WIDTH) / 2;
            TABLE_POS_Y = (getHeight() - TABLE_WIDTH) / 2;
        }

        // desenha borda
        g.setColor(Color.BLACK);
        g.drawRect(TABLE_POS_X, TABLE_POS_Y, TABLE_WIDTH, TABLE_WIDTH);

        //g.setColor(colors[0]);
        //g.fillRect(tablePos, tablePos, tableWidth, tableWidth);

        boolean gameOver = true;

        for (int x = 0; x < numBlocks; x++) {
            for (int y = 0; y < numBlocks; y++) {
                // desenha bloco
                if (board[x][y] == 0) {
                    continue;
                }
                g.setColor(colors[board[x][y]]);

                int bx = x * (BLOCK_WIDTH + BLOCK_SPACING) + TABLE_BORDER + TABLE_POS_X;
                int by = y * (BLOCK_WIDTH + BLOCK_SPACING) + TABLE_BORDER + TABLE_POS_Y;

                g.fillRoundRect( //
                        bx, //
                        by, //
                        BLOCK_WIDTH, //
                        BLOCK_WIDTH, //
                        BLOCK_ROUNDING, //
                        BLOCK_ROUNDING //
                        );

                // desenha jun��es horizontais
                if (x + 1 < numBlocks && board[x][y] == board[x + 1][y]) {
                    g.fillRect( //
                            bx + BLOCK_WIDTH / 2, //
                            by, //
                            BLOCK_WIDTH, //
                            BLOCK_WIDTH //
                            );
                    gameOver = false;
                }

                // desenha jun��es verticais
                if (y + 1 < numBlocks && board[x][y] == board[x][y + 1]) {
                    g.fillRect( //
                            bx, //
                            by + BLOCK_WIDTH / 2, //
                            BLOCK_WIDTH, //
                            BLOCK_WIDTH //
                            );
                    gameOver = false;
                }

            }
        }

        if (gameOver) {
            Font f = g.getFont().deriveFont(Font.BOLD, 40);
            g.setFont(f);
            int w = g.getFontMetrics(f).stringWidth("Game Over");

            g.setColor(Color.WHITE);
            g.drawString("Game Over", (getWidth() - w) / 2, getHeight() / 2);
            g.setColor(Color.BLACK);
            g.drawString("Game Over", (getWidth() - w) / 2 + 1, getHeight() / 2 + 1);
        }

    }

    public int getPiecesLeft() {
        return piecesLeft;
    }

}

/*
 * Created on 20/08/2006
 */
package jgesser;

import jgesser.ui.MainFrame;


/**
 * @author Julio Vilmar Gesser
 */
public class Main {

    public static void main(String[] args) {
        new MainFrame().setVisible(true);
    }

}

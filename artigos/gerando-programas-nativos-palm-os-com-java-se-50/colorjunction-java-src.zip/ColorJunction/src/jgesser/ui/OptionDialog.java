/*
 * Created on 20/08/2006
 */
package jgesser.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import jgesser.game.GamePanel;

/**
 * @author Julio Vilmar Gesser
 */
public final class OptionDialog extends Dialog {

    final GamePanel game;

    Choice choice1;

    Choice choice2;

    boolean ok;

    public static boolean show(Frame owner, GamePanel game) {
        OptionDialog od = new OptionDialog(owner, game);
        od.setLocation(owner.getX() + ((owner.getWidth() - od.getWidth()) / 2), owner.getY() + ((owner.getHeight() - od.getHeight()) / 2));
        od.setVisible(true);
        od.dispose();
        return od.ok;
    }

    private OptionDialog(Frame owner, GamePanel game) {
        super(owner, "Options");
        this.game = game;
        initialize();

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
    }

    /**
     * This method initializes this
     * 
     */
    private void initialize() {
        setSize(250, 117);
        setResizable(false);
        setModal(true);

        GridLayout gridLayout = new GridLayout();
        gridLayout.setHgap(2);
        gridLayout.setVgap(2);
        gridLayout.setRows(2);
        gridLayout.setColumns(2);

        Panel panel1 = new Panel();
        panel1.setLayout(gridLayout);

        Label label1 = new Label();
        label1.setText("Difficulty");
        label1.setAlignment(Label.RIGHT);

        Label label2 = new Label();
        label2.setText("Board Size");
        label2.setAlignment(Label.RIGHT);

        choice1 = new Choice();
        choice1.addItem("Easy");
        choice1.addItem("Medium");
        choice1.addItem("Hard");
        switch (game.getNumColors()) {
            case 3:
                choice1.select(0);
                break;
            case 4:
                choice1.select(1);
                break;
            case 5:
                choice1.select(2);
                break;
        }

        choice2 = new Choice();
        choice2.addItem("Small (10x10)");
        choice2.addItem("Medium (15x15)");
        choice2.addItem("Large (20x20)");
        switch (game.getNumBlocks()) {
            case 10:
                choice2.select(0);
                break;
            case 15:
                choice2.select(1);
                break;
            case 20:
                choice2.select(2);
                break;
        }

        panel1.add(label1);
        panel1.add(choice1);
        panel1.add(label2);
        panel1.add(choice2);
        this.add(panel1, BorderLayout.CENTER);

        // bottom
        Panel panel2 = new Panel();
        panel2.setLayout(new FlowLayout());

        Button buttonOk = new Button();
        buttonOk.setLabel("Ok");
        buttonOk.addActionListener(new ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent e) {
                switch (choice1.getSelectedIndex()) {
                    case 0:
                        game.setNumColors(3);
                        break;
                    case 1:
                        game.setNumColors(4);
                        break;
                    case 2:
                        game.setNumColors(5);
                        break;
                }
                switch (choice2.getSelectedIndex()) {
                    case 0:
                        game.setNumBlocks(10);
                        break;
                    case 1:
                        game.setNumBlocks(15);
                        break;
                    case 2:
                        game.setNumBlocks(20);
                        break;
                }
                ok = true;
                setVisible(false);
            }
        });

        Button buttonCancel = new Button();
        buttonCancel.setLabel("Cancel");
        buttonCancel.addActionListener(new ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent e) {
                ok = false;
                setVisible(false);
            }
        });

        panel2.add(buttonOk);
        panel2.add(buttonCancel);
        this.add(panel2, BorderLayout.SOUTH);

    }
} //  @jve:decl-index=0:visual-constraint="10,10"

/*
 * Created on 20/08/2006
 */
package jgesser.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * @author Julio Vilmar Gesser
 */
public final class AboutDialog extends Dialog {

    public static void show(Frame owner) {
        AboutDialog ad = new AboutDialog(owner);
        ad.setLocation(owner.getX() + ((owner.getWidth() - ad.getWidth()) / 2), owner.getY() + ((owner.getHeight() - ad.getHeight()) / 2));
        ad.setVisible(true);
        ad.dispose();
    }

    private AboutDialog(Frame owner) {
        super(owner, "About");
        initialize();

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                setVisible(false);
            }
        });
    }

    /**
     * This method initializes this
     * 
     */
    private void initialize() {
        setSize(200, 200);
        setResizable(false);
        setModal(true);

        // top
        Panel panel1 = new Panel(new FlowLayout());
        panel1.add(new Label("ColorJunction v1.0"));
        panel1.add(new Label("Programmed by"));
        panel1.add(new Label("Julio Vilmar Gesser"));
        panel1.add(new Label("jgesser@gmail.com"));
        this.add(panel1, BorderLayout.CENTER);

        // bottom
        Panel panel2 = new Panel();
        panel2.setLayout(new FlowLayout());

        Button buttonOk = new Button();
        buttonOk.setLabel("OK");
        buttonOk.addActionListener(new ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent e) {
                setVisible(false);
            }
        });

        panel2.add(buttonOk);
        this.add(panel2, BorderLayout.SOUTH);

    }
} //  @jve:decl-index=0:visual-constraint="10,10"

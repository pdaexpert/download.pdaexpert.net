/*
 * Created on 20/08/2006
 */
package jgesser.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import jgesser.game.GamePanel;

/**
 * @author Julio Vilmar Gesser
 */
public class MainFrame extends Frame {

    GamePanel game;

    private Label status;

    public MainFrame() {
        super("ColorJunction");
        initialize();

        game.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                updateStatus();
            }
        });

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                setVisible(false);
                dispose();
                System.exit(0);
            }
        });
    }

    void updateStatus() {
        status.setText("Pieces left: " + game.getPiecesLeft());
    }

    /**
     * This method initializes this
     * 
     */
    private void initialize() {
        setSize(335, 405);
        //setResizable(false);

        MenuBar menuBar = new MenuBar();
        setMenuBar(menuBar);

        Menu menuGame = new Menu("Game");
        menuBar.add(menuGame);
        Menu menuHelp = new Menu("Help");
        menuBar.add(menuHelp);

        MenuItem item = new MenuItem("New", new MenuShortcut(KeyEvent.VK_N));
        menuGame.add(item);
        ActionListener newGameActionListener = new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                game.newGame();
                updateStatus();
            }

        };
        item.addActionListener(newGameActionListener);

        item = new MenuItem("Configure...", new MenuShortcut(KeyEvent.VK_C));
        menuGame.add(item);
        ActionListener confgActionListener = new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (OptionDialog.show(MainFrame.this, game)) {
                    game.newGame();
                    updateStatus();
                }
            }

        };
        item.addActionListener(confgActionListener);

        menuGame.addSeparator();

        item = new MenuItem("Exit", new MenuShortcut(KeyEvent.VK_X));
        menuGame.add(item);
        item.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                dispose();
                System.exit(0);
            }

        });

        item = new MenuItem("About...", new MenuShortcut(KeyEvent.VK_A));
        menuHelp.add(item);
        item.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                AboutDialog.show(MainFrame.this);
            }

        });

        game = new GamePanel();
        add(game, BorderLayout.CENTER);

        Panel bottom = new Panel(new BorderLayout());
        bottom.setBackground(SystemColor.control);
        add(bottom, BorderLayout.SOUTH);

        status = new Label("Pieces left: " + game.getPiecesLeft(), Label.RIGHT);
        bottom.add(status, BorderLayout.EAST);

        Panel panel = new Panel();

        Button newGameButton = new Button("New");
        panel.add(newGameButton);
        newGameButton.addActionListener(newGameActionListener);

        Button aboutButton = new Button("Config...");
        aboutButton.addActionListener(confgActionListener);
        panel.add(aboutButton);

        bottom.add(panel, BorderLayout.WEST);
    }
}

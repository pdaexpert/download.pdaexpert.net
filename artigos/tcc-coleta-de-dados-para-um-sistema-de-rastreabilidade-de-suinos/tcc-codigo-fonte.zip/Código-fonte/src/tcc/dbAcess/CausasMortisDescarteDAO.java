/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * CausasMortisDescarteDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.CausasMortisDescarte;

/**
 * Extende a classe DAO <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class CausasMortisDescarteDAO
	extends DAO
{

	/**
	 * Objeto com as informa��es
	 */
	CausasMortisDescarte causa = null;
	
	/**
	 * Tabela que ser� acessada pela classe
	 */
	protected static final String TABELA = "mortisdescarte";	
	
	/**
	 * Campos que ser�o acessados pela classe
	 */
	protected static final String[] CAMPOS = {"codigocausa","descricao","mortedescarte"};
	
	
	public CausasMortisDescarteDAO(Conexao conexao, CausasMortisDescarte causa)
	{
		super(conexao,TABELA,CAMPOS);
		setCausa(causa);
	}
	
	/** setCausa 													<br>
	 * Valorar o atributo causa desta classe							<br>
	 * @param causa 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setCausa(CausasMortisDescarte causa)
	{
		this.causa = causa;
	}
	
	/** getCausa 													<br>
	 * Retorna causa												<br>
	 * @return causa												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public CausasMortisDescarte getCausa()
	{
		return this.causa;
	}
	
	protected void Integridade()
	{
		setWhere(" where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]);
	}

	protected void Selecao()
	{
		setWhere(" ");
	}

	protected String [] returnValores()
	{
		return new String[] {" " + getCausa().getCodigoCausa()   + " ",
								   "'" + getCausa().getDescricao()     + "'",
								   "'" + getCausa().getMorteDescarte() + "'"};
	}

}

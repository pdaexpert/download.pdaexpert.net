/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * LoteDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.Lote;

/**
 * Classe de acesso � dados de um Banco de Dados <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class LoteDAO
	extends DAO
{

	
	/**
	 * Cont�m as informa��es que ser�o inseridas ou consultadas do BD
	 */
	protected Lote lote = null;
	
	/**
	 * Tabela que ser� acessada pela classe
	 */
	private static final String 	TABELA = "lote";
	
	/**
	 * Campos que ser�o acessados pela classe
	 */
	private static final String[]	CAMPOS = {"cgccpf"		, 
														 "propriedade"	, 
														 "pocilga"		, 
														 "lote"			};
	
	
	
	public LoteDAO(Conexao conexao, Lote lote)
	{
		super(conexao,TABELA,CAMPOS);
		setLote(lote);
	}
	
	/** getLote 													<br>
	 * Retorna lote												<br>
	 * @return lote												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Lote getLote()
	{
		return this.lote;
	}

	/** setLote 													<br>
	  * Valorar o atributo lote desta classe							<br>
	  * @param lote 															<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  **/
	public void setLote(Lote lote) 
	{
	  this.lote = lote;
	}
	

	protected void Integridade()
	{
		setWhere(    " where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]
				     + "   and " + TABELA + "." + CAMPOS[1] + " = " + returnValores()[1]         
				     + "   and " + TABELA + "." + CAMPOS[2] + " = " + returnValores()[2]           							
				     + "   and " + TABELA + "." + CAMPOS[3] + " = " + returnValores()[3]);
		

	}

	protected void Selecao()
	{
		setWhere(    " where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]
			        + "   and " + TABELA + "." + CAMPOS[1] + " = " + returnValores()[1]       
			        + "   and " + TABELA + "." + CAMPOS[2] + " = " + returnValores()[2]);
	}

	protected String [] returnValores()
	{
		return new String[] {"'" + getLote().getPocilga().getPropriedade().getProdutor().getCgcCpf() + "'" ,
				               ""  + getLote().getPocilga().getPropriedade().getPropriedade()          + ""  ,
				               ""  + getLote().getPocilga().getPocilga()										   + ""  ,
				               ""  + getLote().getLote()										   					+ ""  };
	}

}

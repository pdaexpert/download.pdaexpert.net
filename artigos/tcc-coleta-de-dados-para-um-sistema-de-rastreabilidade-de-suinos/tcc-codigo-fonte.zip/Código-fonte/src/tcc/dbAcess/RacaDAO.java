/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * RacaDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.Raca;

/**
 * Extens�o da Classe DAO													<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class RacaDAO
	extends DAO
{

	/**
	 * Objeto que cont�m as informa��es
	 */
	protected Raca raca = null;
	
	/**
	 * Tabela que ser� acessada pela classe
	 */
	protected static final String		TABELA		= "raca";
	
	/**
	 * Campos que ser�o acessados pela classe
	 */
	protected static final String []	CAMPOS		=
																{ "raca", "descricao" };

	/**
	 *  Construtor da Classe RacaDAO.java <br>
	 * @param conexao
	 * @param raca <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public RacaDAO(Conexao conexao, Raca raca)
	{
		super(conexao,TABELA,CAMPOS);
		setRaca(raca);
	}
	
	/** setRaca 													<br>
    *  Valorar o atributo raca desta classe							<br>
    * @param raca 															<br>
    * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
    **/
	public void setRaca(Raca raca) 
	{
		this.raca = raca;
	}

	/** getRaca 													<br>
	 * Retorna raca												<br>
	 * @return raca												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Raca getRaca()
	{
		return this.raca;
	}
	
	protected void Integridade()
	{
		setWhere(" where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]);
	}
	
	protected void Selecao()
	{
		setWhere(" ");
	}

	protected String [] returnValores()
	{
		return new String[] { ""  + this.getRaca().getRaca()      + "" ,
				                "'" + this.getRaca().getDescricao() + "'" };
	}

}

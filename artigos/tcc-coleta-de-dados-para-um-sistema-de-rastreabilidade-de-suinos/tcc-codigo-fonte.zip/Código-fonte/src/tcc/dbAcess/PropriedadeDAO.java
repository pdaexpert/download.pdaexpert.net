/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 26/04/2006 <br>
 * TCC <br>
 * PropriedadeDAO.java <br>
 */
package tcc.dbAcess;

import tcc.rastreabilidade.Propriedade;

/**
 * <br>
 * Classe de acesso a dados da tabela PROPRIEDADE
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class PropriedadeDAO
	extends DAO
{
	/**
	 * Objeto que ter� os valores a serem inseridos no banco de dados
	 */
	protected Propriedade				propriedade	= null;
	
	/**
	 * Tabela que ser� acessada pela classe
	 */
	protected static final String		TABELA		= "PROPRIEDADE";
	
	/**
	 * Campos que ser�o acessados pela classe
	 */
	protected static final String []	CAMPOS		=
																{ "CGCCPF", "PROPRIEDADE" };

	/**
	 *  Construtor da Classe PropriedadeDAO.java <br>
	 * @param conexao
	 * @param propriedade <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public PropriedadeDAO(Conexao conexao, Propriedade propriedade)
	{
		super(conexao,TABELA,CAMPOS);
		setPropriedade(propriedade);
	}

	/** getPropriedade 													<br>
	 * Retorna propriedade												<br>
	 * @return propriedade												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Propriedade getPropriedade()
	{
		return this.propriedade;
	}

	/** setPropriedade 													<br>
	  * Valorar o atributo propriedade desta classe							<br>
	  * @param propriedade 															<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  **/
	public void setPropriedade(Propriedade propriedade) 
	{
		this.propriedade = propriedade;
	}

	protected void Integridade()
	{
		setWhere(    " where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]
				     + "   and " + TABELA + "." + CAMPOS[1] + " = " + returnValores()[1]);
	}

	protected void Selecao()
	{
		setWhere(" where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]);
	}

	protected String [] returnValores()
	{
		return new String[] {"'" + this.getPropriedade().getProdutor().getCgcCpf() + "'" ,
				               ""  + this.getPropriedade().getPropriedade()          + ""  };
	}

}

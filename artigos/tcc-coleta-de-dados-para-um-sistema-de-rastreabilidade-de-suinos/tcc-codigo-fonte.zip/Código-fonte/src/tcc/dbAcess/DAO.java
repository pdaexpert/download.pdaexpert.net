/**
 * Universidade Regional de Chapec� - Unochapec� 09/04/2006 TCC DAO.java
 */
package tcc.dbAcess;

import superwaba.ext.xplat.sql.PreparedStatement;
import superwaba.ext.xplat.sql.ResultSet;
import superwaba.ext.xplat.sql.SQLException;
import superwaba.ext.xplat.sql.db2e.Db2eStatement;
import tcc.superwaba.custom.ui.Mensagem;
import waba.sys.Vm;

/**
 * DAO<br>
 * Classe de acesso � dados de um Banco de Dados <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public abstract class DAO
{
	/**
	 * Conexao com o Banco de Dados
	 */
	protected Conexao					conexao;

	/**
	 * String que indica inclusao de dados no BD
	 */
	private static final String	INSERIR		= "inserir";
	/**
	 * String que indica remo��o de dados do BD
	 */
	private static final String	EXCLUIR		= "excluir";
	/**
	 * String que indica atualiza��o de dados do BD
	 */
	private static final String	ATUALIZAR	= "atualizar";
	/**
	 * String que indica Consulta no BD
	 */
	private static final String	CONSULTAR	= "consultar";

	/**
	 * Tabela que ser� acessada pela classe
	 */
	private String						Tabela		= "";

	/**
	 * Campos que ser�o acessados pela classe
	 */
	private String []					Campos		= null;

	/**
	 * Clausula Where, para sele��o de Dados
	 */
	private String						where			= " ";

	/* ========== METODOS CONSTRUTORES ========== */
	/**
	 * Construtor da Classe DAO
	 * 
	 * @param conexao conex�o com o Banco de Dados <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 */
	protected DAO(Conexao conexao, String Tabela, String[] Campos)
	{
		this.setConexao(conexao);
		this.setTabela(Tabela);
		this.setCampos(Campos);
	}

	/* ========== METODOS SETS ========== */
	/**
	 * setConexao <br>
	 * Atribuir valor ao Atributo Conexao desta Classe <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 * @param conexao
	 */
	protected void setConexao(Conexao conexao)
	{
		this.conexao = conexao;
	}

	/** setTabela 													<br>
	 * Valorar o atributo Tabela desta classe							<br>
	 * @param tabela 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	protected void setTabela(String tabela)
	{
		this.Tabela = tabela;
	}
	
	/** setCampos 													<br>
	 * Valorar o atributo Campos desta classe							<br>
	 * @param campos 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setCampos(String [] campos)
	{
		this.Campos = campos;
	}
	
	/**
	 * setWhere <br>
	 * Valorar o atributo where desta classe <br>
	 * 
	 * @param where <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void setWhere(String where)
	{
		this.where = where;
	}

	/* ========== METODOS GETS ========== */
	/**
	 * getConexao <br>
	 * Buscar o atributo Conexao desta classe <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 * @return Conexao
	 */
	protected Conexao getConexao()
	{
		return this.conexao;
	}

	/** getTabela 													<br>
	 * Retorna tabela												<br>
	 * @return tabela												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getTabela()
	{
		return this.Tabela;
	}
	
	/** getCampos 													<br>
	 * Retorna campos												<br>
	 * @return campos												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String [] getCampos()
	{
		return this.Campos;
	}
	
	/**
	 * getWhere <br>
	 * Retorna where <br>
	 * 
	 * @return where <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public String getWhere()
	{
		return this.where;
	}

	/* =========== DEMAIS METODOS ============ */
	/**
	 * <b>Inserir</b> - Inserir informa��es no banco de dados <br>
	 * <b>"INSERT INTO tabela (colunas) VALUES (valores)</b> <br>
	 * 
	 * @param strSQL Clausula SQL para inser��o de dados <br>
	 * @return n�mero de linhas inseridas <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected int Inserir(String strSQL)
	{
		int inseriu = 0;
		Db2eStatement stmtStatement = null;

		try
		{
			stmtStatement = (Db2eStatement) this.conexao.getConexao()
					.prepareStatement(strSQL);
			inseriu = stmtStatement.executeUpdate();
		}
		catch (SQLException sqlEx)
		{
			new Mensagem("tcc.dbAcess.Dao."
								+ INSERIR, "Erro: ".concat(sqlEx.getMessage()))
					.popupBlockingModal();
		}
		return inseriu;
	}

	/**
	 * <b>Consultar</b> - Sele��o de dados <br>
	 * <b>" SELECT *|colunas FROM tabela WHERE condicoes</b> <br>
	 * 
	 * @param strSQL Clausula de Sele��o de dados
	 * @return Dados que foram selecionados <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected ResultSet Consultar(String strSQL)
	{
		ResultSet resResultado = null;
		PreparedStatement stmtStatement = null;

		try
		{
			stmtStatement = this.conexao.getConexao().prepareStatement(strSQL);
			resResultado = stmtStatement.executeQuery();
			resResultado.beforeFirst();
		}
		catch (SQLException sqlE)
		{
			new Mensagem("tcc.dbAcess.DAO."
								+ CONSULTAR, "Erro: ".concat(sqlE.getMessage()))
					.popupBlockingModal();
		}
		return resResultado;
	}

	/**
	 * <b>Atualizar</b> - Atualizar valores no banco de dados <br>
	 * <b>"UPDATE tabela SET coluna = valores WHERE condicao"</b><br>
	 * 
	 * @param strSQL
	 * @return <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected int Atualizar(String strSQL)
	{
		int nrLinhasAlteradas = 0;
		Db2eStatement stmtStatement = null;	
		
		try
		{
			Vm.debug("antes stmt atualizar");
			Vm.debug(strSQL);
			stmtStatement = (Db2eStatement) this.conexao.getConexao()
					.prepareStatement(strSQL);
			Vm.debug("antes stmt executar update");
			nrLinhasAlteradas = stmtStatement.executeUpdate();
			Vm.debug("apos stmt executar update");
		}
		catch (SQLException sqlEx)
		{
			new Mensagem("tcc.dbAcess.Dao."
								+ ATUALIZAR, "Erro: ".concat(sqlEx.getMessage()))
					.popupBlockingModal();
		}

		return nrLinhasAlteradas;
	}

	/**
	 * <b>Excluir</b> - Excluir registros de um banco de dados <br>
	 * <b>"DELETE FROM tabela WHERE condi��o"</b> <br>
	 * 
	 * @param strSQL clausula SQL para dele��o <br>
	 * @return nr de linhas excluidas <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected int Excluir(String strSQL)
	{
		int nrLinhasAlteradas = 0;
		Db2eStatement stmtStatement = null;

	
		try
		{
			stmtStatement = (Db2eStatement) this.conexao.getConexao()
					.prepareStatement(strSQL);
			nrLinhasAlteradas = stmtStatement.executeUpdate();
		}
		catch (SQLException sqlEx)
		{
			new Mensagem("tcc.dbAcess.Dao."
								+ (EXCLUIR), "Erro: ".concat(sqlEx.getMessage()))
					.popupBlockingModal();
		}

		return nrLinhasAlteradas;
	}

	/**
	 * <b>Confirmar</b> - Confirmar altera��es, inclus�es ou exclus�es base de
	 * dados <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void Confirmar()
	{
		try
		{
			this.conexao.getConexao().commit();
		}
		catch (SQLException sqlEx)
		{
			new Mensagem("tcc.dbAcess.Dao.Confirmar", "Erro: ".concat(sqlEx
					.getMessage())).popupBlockingModal();
		}
	}

	/**
	 * <b>Desfazer</b> - Desfazer altera��es na base de dados <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void Desfazer()
	{
		try
		{
			this.conexao.getConexao().rollback();
		}
		catch (SQLException e)
		{
			new Mensagem("tcc.dbAcess.Dao.Desfazer", "Erro: ".concat(e
					.getMessage())).popupBlockingModal();
		}
	}

	/**
	 * <b>Integridade</b> - Construir a clausula where, que ir� garantir a
	 * integridade dos dados <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected abstract void Integridade();

	/**
	 * <b>Selecao</b> - gerar a clausula where, que ir� selecionar todos os
	 * dados da tabela <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected abstract void Selecao();

	/**
	 * <b>returnValores</b> - Gera Matriz com os Valores dos Campos a serem
	 * Atualizados <br>
	 * 
	 * @return Matriz com os valores <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected abstract String [] returnValores();

	/**
	 * <b>Inserir</b> - Insere registro no banco de dados <br>
	 * 
	 * @param produtor Objeto Produtor, com as Informa��es a Serem inseridas no
	 *           banco de dados
	 * @return Nr de Linhas Inseridas <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public int Inserir()
	{
		int nrLinhasInseridas = 0;

		try
		{
			this.Integridade();
			if (this.Consultar(false).next() == false)
			{
				nrLinhasInseridas = Inserir(ClausulaSQL.GerarInsert(getTabela(), getCampos(), returnValores()));
			}
		}
		catch (Exception e)
		{

		}

		return nrLinhasInseridas;
	}

	/**
	 * <b>Atualizar</b> - Atualizar informa��es no banco de dados <br>
	 * 
	 * @return nr de linhas atualizadas <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public int Atualizar()
	{
		int nrLinhasAtualizadas = 0;
		try
		{
			this.Integridade();
			
			if (this.Consultar(false).next() == true) // se possui o registro
																	// selecionado
			{
				nrLinhasAtualizadas = Atualizar(ClausulaSQL.GerarUpdate(getTabela(),
						getCampos(), returnValores(), getWhere()));
			}
		}
		catch (Exception e)
		{
			Vm.debug("erro em atualizar!");
		}

		return nrLinhasAtualizadas;
	}

	/**
	 * <b>Consultar</b> - Consulta de Registros no BD <br>
	 * 
	 * @param Produtor
	 * @param SelecionarTodos
	 * @return <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public ResultSet Consultar(boolean SelecionarTodos)
	{

		if (SelecionarTodos)
		{
			Selecao();
		}
		return Consultar(ClausulaSQL.GerarSelect(getTabela(), getCampos(), getWhere()));
	}

	/**
	 * <b>Excluir</b> - excluir informa��es do banco de dados
	 * 
	 * @return n�mero de linhas excluidas <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public int Excluir()
	{
		int nrLinhasExcluidas = 0;
		Integridade();
		try
		{
			this.Integridade();
			if (this.Consultar(false).next() == true) // se possui o registro
																	// selecionado
			{
				nrLinhasExcluidas = Excluir(ClausulaSQL.GerarDelete(getTabela(),
						getWhere()));
			}
		}
		catch (Exception e)
		{
		}
		return nrLinhasExcluidas;
	}
	
	public String nomeColuna(int Coluna)
	{
		String nomeColuna = "";
		try
		{
			nomeColuna = getCampos()[Coluna];
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		return nomeColuna;
	}

}

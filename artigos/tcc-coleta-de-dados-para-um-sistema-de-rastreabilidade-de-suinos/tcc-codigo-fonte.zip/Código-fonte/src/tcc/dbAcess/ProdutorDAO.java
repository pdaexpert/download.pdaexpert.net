/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 25/04/2006														<br>
  * TCC											<br>
  * ProdutorDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.Produtor;

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class ProdutorDAO
	extends DAO
{

	/*CREATE TABLE PRODUTOR (
	   CGCCPF 		VARCHAR(15) NOT NULL,
	   MATRICULA 	VARCHAR(20),
	   NOME 			VARCHAR(50),
	   ENDERECO 	VARCHAR(50),
	   TELEFONE 	VARCHAR(20)) */
	
	private static final String   TABELA = "PRODUTOR";
	private static final String[] CAMPOS = {"CGCCPF" , "MATRICULA", "NOME", "ENDERECO", "TELEFONE"};
	private Produtor produtor = null;
	
	public ProdutorDAO(Conexao conexao, Produtor produtor)
	{
		super(conexao,TABELA,CAMPOS);
	}

	/** setProdutor 													<br>
	 * Valorar o atributo produtor desta classe							<br>
	 * @param produtor 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setProdutor(Produtor produtor) 
	{
		this.produtor = produtor;
	}


	/** getProdutor 													<br>
	 * Retorna produtor												<br>
	 * @return produtor												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Produtor getProdutor()
	{
		return this.produtor;
	}

	public void Integridade()
	{
		// where produtor.cgccpf = Produtor.getCgcCpf()
		setWhere("where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]);
	}

	public void Selecao()
	{
		//Selecionar todos os registros
		setWhere(" ");
	}
	
	protected String [] returnValores()
	{
		return new String[] {"'"  + this.getProdutor().getCgcCpf()	 	+ "'",
			   					"'"  + this.getProdutor().getMatricula() 	+ "'",
			   					"'"  + this.getProdutor().getNome()		 	+ "'",
			   					"'"  + this.getProdutor().getEndereco()	+ "'",
			   					"'"  + this.getProdutor().getTelefone()	+ "'" };
	}
	
	
}

/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 09/05/2006 <br>
 * TCC <br>
 * Manutencao.java <br>
 */
package tcc.dbAcess;

/**
 * <br>
 * 
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class Manutencao
	extends DAO
{

	/**
	 * Construtor da Classe Manutencao.java <br>
	 * 
	 * @param conexao
	 * @param Tabela
	 * @param Campos <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Manutencao(Conexao conexao)
	{
		super(conexao, null, null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tcc.dbAcess.DAO#Integridade()
	 */
	protected void Integridade()
	{
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tcc.dbAcess.DAO#Selecao()
	 */
	protected void Selecao()
	{
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tcc.dbAcess.DAO#returnValores()
	 */
	protected String [] returnValores()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public void CriarTabelas()
	{

		Inserir("DROP TABLE PRODUTOR ");

		Inserir("DROP TABLE PROPRIEDADE");

		Inserir("DROP TABLE TIPOIDENTIFICACAO");

		Inserir("DROP TABLE FASE ");

		Inserir("DROP TABLE RACA ");

		Inserir("DROP TABLE SUINO ");

		Inserir("DROP TABLE LOTE ");

		Inserir("DROP TABLE POCILGA ");

		//Inserir("DROP TABLE AVALIACAOPARCERIA ");

		//Inserir("DROP TABLE APLICACAOMEDICAMENTO ");

		//Inserir("DROP TABLE CONSUMORACAO ");

		Inserir("DROP TABLE TXMORTEDESCARTE");

		//Inserir("DROP TABLE AVALIACAOITENS");

		//Inserir("DROP TABLE ITEMAVALIACAO ");

		Inserir("DROP TABLE MORTISDESCARTE ");

		//Inserir("DROP TABLE RACAO ");

		//Inserir("DROP TABLE VACINAMEDICAMENTO ");
		
		Inserir("CREATE TABLE PRODUTOR "
					+ "(CGCCPF CHAR(15) NOT NULL,"
					+ "MATRICULA VARCHAR(20),"
					+ "NOME VARCHAR(50),"
					+ "ENDERECO VARCHAR(50),"
					+ "TELEFONE VARCHAR(20))");

		Inserir("CREATE TABLE PROPRIEDADE "
					+ "(CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL)");

		Inserir("CREATE TABLE TIPOIDENTIFICACAO (TIPOIDENTIFICACAO INTEGER NOT NULL,DESCRICAO CHAR(30) NOT NULL)");

		Inserir("CREATE TABLE FASE (FASE INTEGER NOT NULL,DESCRICAO CHAR(30))");

		Inserir("CREATE TABLE RACA (RACA INTEGER NOT NULL,DESCRICAO CHAR(50))");

		Inserir("CREATE TABLE SUINO "
					+ "(CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL,"
					+ "LOTE INTEGER NOT NULL,"
					+ "SEQUENCIA INTEGER NOT NULL,"
					+ "TIPOIDENTIFICACAO INTEGER NOT NULL,"
					+ "FASE INTEGER NOT NULL,"
					+ "RACA INTEGER NOT NULL,"
					+ "SEXO CHAR(1) DEFAULT 'M')");

		Inserir("CREATE TABLE LOTE "
					+ "(CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL,"
					+ "LOTE INTEGER NOT NULL)");

		Inserir("CREATE TABLE POCILGA "
					+ "(CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL)");

		/*Inserir("CREATE TABLE AVALIACAOPARCERIA "
					+ "(CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL,"
					+ "NUMEROAVALIACAO INTEGER NOT NULL,"
					+ "DATAAVALIACAO DATE NOT NULL)");*/

		/*Inserir("CREATE TABLE APLICACAOMEDICAMENTO ("
					+ "CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL,"
					+ "LOTE INTEGER NOT NULL,"
					+ "SEQUENCIA INTEGER NOT NULL,"
					+ "CODIGOVACINAMEDICAMENTO INTEGER NOT NULL,"
					+ "DATAAPLICACAO DATE,"
					+ "DATALCTO DATE,"
					+ "QUANTIDADE DECIMAL(5,2) NOT NULL)");*/

		/*Inserir("CREATE TABLE CONSUMORACAO (	"
					+ "CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL,"
					+ "CODIGORACAO INTEGER NOT NULL,"
					+ "LOTE INTEGER NOT NULL,"
					+ "DATALCTO DATE NOT NULL,"
					+ "QUANTIDADE DECIMAL(5,2) NOT NULL) ");*/

		Inserir("CREATE TABLE TXMORTEDESCARTE ("
					+ "CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL,"
					+ "LOTE INTEGER NOT NULL,"
					+ "SEQUENCIA INTEGER NOT NULL,"
					+ "CODIGOCAUSA INTEGER NOT NULL,"
					+ "DATALCTO DATE NOT NULL,"
					+ "DTMORTEDESCARTE DATE NOT NULL,"
					+ "PESOESTIMADO DECIMAL(5,2)) ");

		/*Inserir("CREATE TABLE AVALIACAOITENS ("
					+ "CGCCPF CHAR(15) NOT NULL,"
					+ "PROPRIEDADE INTEGER NOT NULL,"
					+ "POCILGA INTEGER NOT NULL,"
					+ "NUMEROAVALIACAO INTEGER NOT NULL,"
					+ "CODIGOITEM INTEGER NOT NULL,"
					+ "VALORCARACTER CHAR(50),"
					+ "VALORDECIMAL DECIMAL(5,2),"
					+ "VALORBOOLEANO CHAR(1)) ");*/

		/*Inserir("CREATE TABLE ITEMAVALIACAO ("
					+ "CODIGOITEM INTEGER NOT NULL,"
					+ "DESCRICAO CHAR(30)) ");*/

		Inserir("CREATE TABLE MORTISDESCARTE ("
					+ "CODIGOCAUSA INTEGER NOT NULL,"
					+ "DESCRICAO CHAR(50),"
					+ "MORTEDESCARTE CHAR(1) DEFAULT 'M' NOT NULL) ");

		/*Inserir("CREATE TABLE RACAO ("
					+ "CODIGORACAO INTEGER NOT NULL,"
					+ "DESCRICAO CHAR(30) NOT NULL,"
					+ "LOTEFABRICACAO CHAR(10)) ");*/

		/*Inserir("CREATE TABLE VACINAMEDICAMENTO ("
					+ "CODIGOVACINAMEDICAMENTO INTEGER NOT NULL,"
					+ "DESCRICAO CHAR(30),"
					+ "VACINAMEDICAMENTO BOOLEAN,"
					+ "UNIDADEMEDIDA CHAR(3),"
					+ "LOTEFABRICACAO CHAR(30) NOT NULL)");*/
	}
	
	public void ImportarDados()
	{
		Inserir("insert into produtor values ('12345678912345','junior','0001','serv turquia','33246090')");
		Inserir("insert into produtor values ('9876543211234' ,'joao'  ,'0002','linha capiao','00000000')");

		Inserir("insert into propriedade values ('9876543211234' ,1)");
		Inserir("insert into propriedade values ('12345678912345',1)");
		Inserir("insert into propriedade values ('12345678912345',2)");

		Inserir("insert into pocilga values ('9876543211234' ,1,1)");
		Inserir("insert into pocilga values ('12345678912345',1,1)");
		

		Inserir("insert into lote values('9876543211234' ,1,1,1)");
		Inserir("insert into lote values('12345678912345',1,1,1)");
		Inserir("insert into lote values('12345678912345',1,2,1)");

		Inserir("insert into suino values('9876543211234' ,1,1,1,1,1,1,1,'m')");
		Inserir("insert into suino values('9876543211234' ,1,1,1,2,1,1,1,'m')");
		Inserir("insert into suino values('12345678912345',1,1,1,1,1,1,1,'f')");
		Inserir("insert into suino values('12345678912345',1,1,1,2,1,1,1,'f')");

		Inserir("insert into mortisdescarte values (1,'encefalite','m')");
		Inserir("insert into mortisdescarte values (2,'diarreia'  ,'m')");
	}
}
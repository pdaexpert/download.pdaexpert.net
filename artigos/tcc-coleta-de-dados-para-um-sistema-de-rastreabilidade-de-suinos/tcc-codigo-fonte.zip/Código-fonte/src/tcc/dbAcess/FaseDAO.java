/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * FaseDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.Fase;

/**
 * Extens�o DAO <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class FaseDAO
	extends DAO
{

	/**
	 * Objeto com as informa��es
	 */
	protected Fase fase = null;

	/**
	 * Tabela que ser� acessada pela classe
	 */
	protected static final String		TABELA		= "fase";
	
	/**
	 * Campos que ser�o acessados pela classe
	 */
	protected static final String []	CAMPOS		=
																{ "fase", "descricao" };

	public FaseDAO(Conexao conexao, Fase fase)
	{
		super(conexao,TABELA,CAMPOS);
		setFase(fase);
	}
	
	/** setFase 													<br>
	 * Valorar o atributo fase desta classe							<br>
	 * @param fase 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setFase(Fase fase)
	{
		this.fase = fase;
	}
	
	/** getFase 													<br>
	 * Retorna fase												<br>
	 * @return fase												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Fase getFase()
	{
		return this.fase;
	}
	
	protected void Integridade()
	{
		setWhere(" where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]);
	}

	protected void Selecao()
	{
		setWhere(" ");
	}

	protected String [] returnValores()
	{
		return new String[] { " " + getFase().getFase() 	  + " ",
				 				   " '" + getFase().getDescricao() + "' "};
	}

}

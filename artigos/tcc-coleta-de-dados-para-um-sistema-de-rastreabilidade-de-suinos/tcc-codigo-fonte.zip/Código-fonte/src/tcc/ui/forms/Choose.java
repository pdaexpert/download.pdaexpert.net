/**
 * Universidade Regional de Chapec� - Unochapec�
 * 20/04/2006
 * TCC
 * Choose.java
 **/
package tcc.ui.forms;

import superwaba.ext.xplat.sql.ResultSet;
import tcc.rastreabilidade.LogicalInterface;
import tcc.superwaba.custom.ui.DBGrid;
import waba.ui.Event;
import waba.ui.GridEvent;
import waba.ui.Window;

/**
 * Classe Respons�vel Pela exibi��o dos dados e tamb�m do retorno da linha
 * selecionada ao formul�rio que � instanciou <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class Choose
	extends Window
{
	protected DBGrid			dbGrid	= null;
	protected LogicalInterface objeto	= null;

	/**
	 * Construtor da Classe Choose.java 								 <br>
	 * @param resultSEt ResultSet com os Dados
	 * @param objeto    Objeto que receber� a linha selecionada  <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Choose(ResultSet resultSEt, LogicalInterface objeto)
	{
		this.setBorderStyle(RECT_BORDER);
		this.setTitle("SELE��O DE DADOS");
		
		this.setDbGrid(new DBGrid(resultSEt));
		this.setObjeto(objeto);
		
		this.add(this.dbGrid);
		this.dbGrid.setRect(CENTER, BOTTOM, this.getRect().width, (int) (this
				.getRect().height * 0.9));
	}

	/** getDbGrid 													<br>
	 * Retorna dbGrid												<br>
	 * @return dbGrid												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public DBGrid getDbGrid()
	{
		return this.dbGrid;
	}

	/** setDbGrid 													<br>
	  * Valorar o atributo dbGrid desta classe							<br>
	  * @param dbGrid 															<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  **/
	public void setDbGrid(DBGrid dbGrid) 
	{
		this.dbGrid = dbGrid;
	}

	/** getObjeto 													<br>
	 * Retorna objeto												<br>
	 * @return objeto												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public LogicalInterface getObjeto()
	{
		return this.objeto;
	}

	/** setObjeto 													<br>
	  * Valorar o atributo objeto desta classe							<br>
	  * @param objeto 															<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  **/
	public void setObjeto(LogicalInterface objeto) 
	{
		this.objeto = objeto;
	}
	
	/**
	 * Ao Executar um evento, ser� disparada uma a��o
	 */
	public void onEvent(Event event)
	{
		super.onEvent(event);
		switch (event.type)
		{
			case GridEvent.SELECTED_EVENT:
			{
				this.objeto.setAtributosObjeto(this.dbGrid.getSelectedItem());
				this.unpop();
				break;
			}
			default:
				break;
		}

	}

}

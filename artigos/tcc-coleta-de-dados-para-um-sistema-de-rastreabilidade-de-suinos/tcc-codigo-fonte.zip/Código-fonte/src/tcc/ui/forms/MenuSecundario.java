/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 04/05/2006														<br>
  * TCC											<br>
  * MenuControles.java												<br>
  **/
package tcc.ui.forms;

import tcc.superwaba.custom.ui.CustomMenuBar;
import waba.ui.Button;
import waba.ui.ControlEvent;
import waba.ui.Event;
import waba.ui.Label;

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class MenuSecundario
	extends Menu
{
	/**
	 * Itens da 1� Coluna
	 */
	private static String[] ITENS_MENU_01 = {"Arquivo","Sair"};
	
	/**
	 * Caption dos Bot�es
	 */
	private String[] CaptionBotoes = null; 
	private Button[] Botoes		    = null;
	
	public MenuSecundario(String Titulo, String[] CaptionsBotoes)
	{
		setWindowProperties(".::. " + Titulo + " .::.",new CustomMenuBar(new String[][] {ITENS_MENU_01}));
		setCaptionBotoes(CaptionsBotoes);
		setBotoes(new Button [getCaptionBotoes().length]);
		addButtons();
	}
	
	/** setCaptionBotoes 														<br>
	 * Valorar o atributo CaptionBotoes desta classe					<br>
	 * @param captionBotoes 													<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setCaptionBotoes(String [] captionBotoes)
	{
		this.CaptionBotoes = captionBotoes;
	}
	
	/** setBotoes 																	<br>
	 * Valorar o atributo Botoes desta classe								<br>
	 * @param botoes 																<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setBotoes(Button [] botoes)
	{
		this.Botoes = botoes;
	}
	
	/**
	 * <b>setButton</b> - Inserir um Button na Matriz de Buttons <br>
	 * @param nrBotao posi��o
	 * @param botao   objeto a inserir									 <br>				 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void setButton(int nrBotao, Button botao)
	{
		this.Botoes[nrBotao] = botao;
	}
	
	/** getCaptionBotoes 														<br>
	 * Retorna captionBotoes													<br>
	 * @return captionBotoes													<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String [] getCaptionBotoes()
	{
		return this.CaptionBotoes;
	}
	
	/** getBotoes 																	<br>
	 * Retorna botoes																<br>
	 * @return botoes																<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Button [] getBotoes()
	{
		return this.Botoes;
	}
	
	/**
	 * <b>addButtons</b> - adiciona bot�es na tela do formul�rio	<br>
	 * @param Captions	Matriz com as Captions dos Bot�es																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com 	<br>
	 */
	protected void addButtons()
	{
		Label lblAux = null;
		int nrBotao  = 0;
		try
		{ 
			for (nrBotao = 0; nrBotao < getCaptionBotoes().length; nrBotao++)
			{
				setButton(nrBotao,new Button(getCaptionBotoes()[nrBotao])); 
				addOnClb(Botoes[nrBotao]);
				Botoes[nrBotao].setRect(CENTER,AFTER,100,13);
			}
			clbFundo.add(lblAux = new Label(""));
			lblAux.setRect(SAME,AFTER,SAME,PREFERRED,Botoes[nrBotao - 1]);
		}
		catch (Exception e) 
		{
		}
	}
	
	/* (non-Javadoc)
	 * @see tcc.ui.forms.Menu#onEvent(waba.ui.Event)
	 */
	public void onEvent(Event evento)
	{
		// TODO Auto-generated method stub
		super.onEvent(evento);
		switch (evento.type)
		{
			case ControlEvent.PRESSED:
			{
				try
				{
					for (int botao = 0; botao < getBotoes().length; botao++)
					{
						if (evento.target == getBotoes()[botao])
						{
							onButtonPressed(botao);
							break;
						}
					}
					
				}
				catch (Exception e)
				{
					// TODO: handle exception
				}
				break;
			}
			default:
				break;
		}
	}
	
	/* (non-Javadoc)
	 * @see tcc.ui.forms.Menu#onMenuItemSelected()
	 */
	protected void onMenuItemSelected()
	{
		switch (getMenuBar().getSelectedMenuItem())
		{
			case 1:
			{
				unpop();
				break;
			}
			default:
				break;
		}
	}
	
	/**
	 * <b>onButtonPressed</b> - M�todo Executado ao Pressionar um dos bot�es da tela <br>
	 * @param buttonNumber n�mero do bot�o pressionado
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onButtonPressed(int buttonNumber)
	{
		
	}
}

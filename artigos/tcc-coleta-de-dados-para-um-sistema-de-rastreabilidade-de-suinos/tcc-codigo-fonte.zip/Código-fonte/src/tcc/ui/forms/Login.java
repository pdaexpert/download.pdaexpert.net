package tcc.ui.forms;

import waba.ui.Button;
import waba.ui.ControlEvent;
import waba.ui.Edit;
import waba.ui.Event;
import waba.ui.Label;
import waba.ui.MainWindow;
import waba.ui.Window;

/**
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public class Login
	extends Window
{
	protected MainWindow	mwPrincipal	= null;

	protected Edit			edtLogin		= null;

	protected Edit			edtSenha		= null;

	protected Label		lblLogin		= null;

	protected Label		lblSenha		= null;

	protected Button		btnEntrar	= null;

	protected Button		btnSair		= null;

	/**
	 * Contrutor da Classe Login
	 * 
	 * @param mwPrincipal MainWindow que Chamou o Objeto da Classe Login
	 */
	public Login(MainWindow mwPrincipal)
	{

		this.mwPrincipal = mwPrincipal;
		this.setWindowProperties();
		this.addItensOnWindow();
		this.edtLogin.requestFocus();

	}

	/**
	 * Executa Ao Iniciar a Aplicacao
	 */
	protected void onStart()
	{
		super.onStart();
	}

	/**
	 * Executa Apos a Ocorrencia de Algum Evento
	 * 
	 * @param evento Evento que sera testado
	 */
	public void onEvent(Event evento)
	{
		super.onEvent(evento);
		switch (evento.type)
		{
			case ControlEvent.PRESSED:
			{
				if (evento.target == this.btnEntrar)
				{
					this.onBtnEntrarPress();
				}
				if (evento.target == this.btnSair)
				{
					this.onBtnSairPress();
				}
				break;
			}
			default:
			{
				break;
			}
		}
	}

	/**
	 * Executa ao Clicar no Botao Sair
	 * 
	 */
	protected void onBtnSairPress()
	{
		this.unpop();
		this.mwPrincipal.exit(1);
	}

	/**
	 * Executa Ap�s Clicar no Bot�o
	 * 
	 */
	protected void onBtnEntrarPress()
	{
		// TODO: Incluir Verifica��o de Usu�rio e Senha
		new MenuPrincipal().popupModal();
	}

	/**
	 * Informa��es b�sicas � constru��o da Tela
	 */
	protected void setWindowProperties()
	{
		this.setTitle("Digite seu Login e Senha");
		this.setBorderStyle(RECT_BORDER);
		this.setRect(CENTER, CENTER, 150, 102);
		this.canDrag = false;
	}

	/**
	 * Adcionar os itens � tela
	 */
	protected void addItensOnWindow()
	{
		this.edtLogin = new Edit("");
		this.edtSenha = new Edit("");
		this.lblLogin = new Label("Login");
		this.lblSenha = new Label("Senha");
		this.btnEntrar = new Button("Entrar");
		this.btnSair = new Button("Sair");

		this.edtSenha.setMode(Edit.PASSWORD_ALL);

		this.edtSenha.setMaxLength(8);
		this.edtLogin.setMaxLength(8);

		this.add(lblLogin);
		this.add(edtLogin);
		this.add(lblSenha);
		this.add(edtSenha);
		this.add(btnEntrar);
		this.add(btnSair);

		this.lblLogin.setRect(05, 20, PREFERRED + 5, PREFERRED);
		this.edtLogin.setRect(AFTER + 5, SAME, PREFERRED - 10, PREFERRED);

		this.lblSenha.setRect(SAME, AFTER + 5, SAME, PREFERRED, lblLogin);
		this.edtSenha.setRect(AFTER + 5, SAME, PREFERRED - 10, PREFERRED);

		this.btnEntrar.setRect(LEFT + 20, AFTER + 10, PREFERRED + 10,
				PREFERRED + 3);
		this.btnSair.setRect(RIGHT - 20, SAME, SAME, SAME);
	}

}

package tcc.ui.forms;

import tcc.superwaba.custom.ui.CustomMenuBar;
import tcc.ui.forms.mortalidade.FrmMortalidade;

/**
 * MenuOperacoes
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 * <br>
 * Exten��o da Classe Menu. Ser� utilizada como base �s classes de interface
 * que ir�o abrigar os formul�rios de inclus�o de dados
 */
public class MenuOperacoes
	extends Menu
{
	/**
	 * Itens do Menu Bar
	 */
	protected static String []	strItensMenu_	=
															{ "Operacoes", "Incluir",
			"Alterar", "Consultar", "Excluir","Sair"	};
	
	/**
	 * Operacao (controle) a ser realidada (Mortalidade, Ra��o, etc)
	 */
	protected String Operacao = "";
	
	FrmMortalidade frame = null;
	
	/**
	 * Construtor da Classe MenuOperacoes
	 * @param strOperacao titulo que ser� apresentado na parte superior da tela
	 */
	public MenuOperacoes(String strOperacao)
	{
		setOperacao(strOperacao);
		setWindowProperties(getOperacao(),new CustomMenuBar(new String[][] {strItensMenu_}));
		addOnClb(frame = new FrmMortalidade());
		frame.setRect(clbFundo.getRect());
		
	}  
		
	/** setOperacao 													<br>
	 * Valorar o atributo Operacao desta classe							<br>
	 * @param operacao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setOperacao(String operacao)
	{
		this.Operacao = operacao;
	}
	
	/** getOperacao 													<br>
	 * Retorna operacao												<br>
	 * @return operacao												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getOperacao()
	{
		return this.Operacao;
	}
	
	protected void onStart()
	{
		//super.onStart();
	}
	/* (non-Javadoc)
	 * @see tcc.ui.forms.Menu#onMenuItemSelected()
	 */
	protected void onMenuItemSelected()
	{
		// TODO Auto-generated method stub
		
	}
}

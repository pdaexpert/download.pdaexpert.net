package tcc.ui;

import tcc.ui.forms.Login;
import waba.ui.MainWindow;

public class JanelaPrincipal
	extends MainWindow
{

	protected Login	lgLogin	= null;

	/**
	 * JanelaPrincipal() - Construtor Padr�o Desta Classe
	 **/
	public JanelaPrincipal()
	{
		this.setWindowProperties();
	}

	/**
	 * Execu��es Necess�rias quando Iniciar a Aplica��o
	 */
	public void onStart()
	{
		getLgLogin().popupModal();
	}

	/**
	 * Execu��es Necess�rias quando for Fechada a Aplica��o
	 */
	public void onExit()
	{

	}

	/** setLgLogin 													<br>
	 * Valorar o atributo lgLogin desta classe							<br>
	 * @param lgLogin 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setLgLogin(Login lgLogin)
	{
		this.lgLogin = lgLogin;
	}
	
	/** getLgLogin 													<br>
	 * Retorna lgLogin												<br>
	 * @return lgLogin												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Login getLgLogin()
	{
		return this.lgLogin;
	}
	
	/**
	 * Inserir as informa��es necess�rias � contru��o da Tela
	 */
	protected void setWindowProperties()
	{
		setBorderStyle(BORDER_SIMPLE);
		setTitle(".::. CooperAlfa .::.");
		setLgLogin(new Login(this));
	}

}

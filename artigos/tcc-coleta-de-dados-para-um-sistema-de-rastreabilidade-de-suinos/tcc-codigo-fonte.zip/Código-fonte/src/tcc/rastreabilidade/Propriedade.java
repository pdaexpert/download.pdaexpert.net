/**
  * Universidade Regional de Chapec� - Unochapec�
  * 20/04/2006
  * TCC
  * Propriedade.java
  **/
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Classe com a L�gida de neg�cio para controle da entidade Propriedade <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com				<br>
 */
public class Propriedade
	implements 	LogicalInterface
{

	/**
	 * Produtor (Propriet�rio)
	 */
	protected Produtor produtor 	 = null;
	
	/**
 	  * C�digo da Propriedade
	  */
	protected int		 propriedade = 0	 ;
		
	/**
	 * Construtor Padr�o da Classe Propriedade							<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 */
	public Propriedade()
	{
		this(new Produtor(),0);
	}
	
	/**
	 * Construtor da Classe Propriedade										<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @param produtor		Produtor (Propriet�rio)						
	 * @param propriedade	C�digo da Propriedade						<br>
	 */
	public Propriedade(Produtor produtor, int propriedade)
	{
		this.setProdutor(produtor);
		this.setPropriedade(propriedade);
	}
	
	/* METODOS SETS */
	/** setProdutor 
	 * <br>
	 * Valorar o atributo produtor desta classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @param produtor .
	 */
	public void setProdutor(Produtor produtor) 
	{
		this.produtor = produtor;
	}

	/** setPropriedade 
	  * <br>
	  * Valorar o atributo propriedade desta classe
	  * <br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	  * <br>
	  * @param propriedade .
	  */
	public void setPropriedade(int propriedade) 
	{
		this.propriedade = propriedade;
	}

	public void setAtributosObjeto(String [] linha)
	{
		try
		{
			for (int nrAtributos = 0; nrAtributos < linha.length; nrAtributos++)
			{
				switch (nrAtributos)
				{
					case 0:
					{
						setProdutor(new Produtor(linha[nrAtributos],"","","",""));
						break;
					}
					case 1:
					{
						setPropriedade(Convert.toInt(linha[nrAtributos]));
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e) 
		{
		}
	}

	/* METODOS GETS */
	/** getProdutor 
	 * <br>
	 * Retorna produtor
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @return produtor.
	 */
	public Produtor getProdutor()
	{
		return this.produtor;
	}
	
	/** getPropriedade 
	 * <br>
	 * Retorna propriedade
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @return propriedade.
	 */
	public int getPropriedade()
	{
		return this.propriedade;
	}
}

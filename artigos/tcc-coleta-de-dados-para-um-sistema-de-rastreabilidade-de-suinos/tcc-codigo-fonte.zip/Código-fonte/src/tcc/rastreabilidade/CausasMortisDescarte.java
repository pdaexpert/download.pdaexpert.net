/**
 * Universidade Regional de Chapec� - Unochapec� 	<br>
 * 23/04/2006													<br>
 * TCC															<br>
 * CausasMortisDescarte.java								<br>
 **/
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Gerenciamento dos Tipos de Causas Mortis / Descarte			<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class CausasMortisDescarte
	implements LogicalInterface
{
	/**
	 * C�digo da Causa
	 */
	protected int		CodigoCausa		= 0;
	
	/**
	 * Descri��o da Causa
	 */
	protected String	Descricao		= null;
	
	/**
	 * <b>M</b>orte ou <b>D</b>escarte
	 */
	protected char		MorteDescarte	= 'm';
	
	/**
	 *  Construtor da Classe CausasMortisDescarte.java <br>
	 * @param CodigoCausa
	 * @param Descricao
	 * @param MorteDescarte <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public CausasMortisDescarte(int CodigoCausa, String Descricao, char MorteDescarte)
	{
		setCodigoCausa(CodigoCausa);
		setDescricao(Descricao);
		setMorteDescarte(MorteDescarte);
	}
	
	/** Construtor da Classe CausasMortisDescarte.java <br>
	 *  <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 **/
	public CausasMortisDescarte()
	{
		this(0,"",'m');
	}
	
	
	/** setCodigoCausa 													<br>
	 * Valorar o atributo CodigoCausa desta classe							<br>
	 * @param codigoCausa 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setCodigoCausa(int codigoCausa)
	{
		CodigoCausa = codigoCausa;
	}
	
	/** setDescricao 													<br>
	 * Valorar o atributo Descricao desta classe							<br>
	 * @param descricao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setDescricao(String descricao)
	{
		Descricao = descricao;
	}
	
	/** setMorteDescarte 													<br>
	 * Valorar o atributo MorteDescarte desta classe							<br>
	 * @param morteDescarte 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setMorteDescarte(char morteDescarte)
	{
		MorteDescarte = morteDescarte;
	}
	
	public void setAtributosObjeto(String [] linha)
	{
		try
		{
			for (int nrAtributo = 0; nrAtributo < linha.length; nrAtributo++)
			{
				switch (nrAtributo)
				{
					case 0:
					{
						setCodigoCausa(Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 1:
					{
						setDescricao(linha[nrAtributo]);
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e)
		{
		}
	}

	/** getCodigoCausa 													<br>
	 * Retorna codigoCausa												<br>
	 * @return codigoCausa												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public int getCodigoCausa()
	{
		return this.CodigoCausa;
	}
	
	/** getDescricao 													<br>
	 * Retorna descricao												<br>
	 * @return descricao												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getDescricao()
	{
		return this.Descricao;
	}
	
	/** getMorteDescarte 													<br>
	 * Retorna morteDescarte												<br>
	 * @return morteDescarte												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public char getMorteDescarte()
	{
		return this.MorteDescarte;
	}
}

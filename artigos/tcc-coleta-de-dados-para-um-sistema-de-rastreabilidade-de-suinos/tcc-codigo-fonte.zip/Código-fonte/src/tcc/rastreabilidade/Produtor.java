/**
 * Universidade Regional de Chapec� - Unochapec�
 * 20/04/2006
 * TCC
 * Produtor.java
 **/
package tcc.rastreabilidade;

/**
 * Classe Produtor, com a l�gica necess�ria para o gerenciamento dos dados <br>
 * no Banco de Dados <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public class Produtor
	implements LogicalInterface
{
	
	/**
	 * CgcCpf do Produtor 
	 */
	protected String	CgcCpf		= null;
	
	/**
	 *	Matricula do Produtor 
	 */
	protected String	Matricula	= null;
	
	/**
	 * Nome do Produtor
	 */
	protected String	Nome			= null;
	
	/**
	 * Telefone do Produtor
	 */
	protected String	Telefone		= null;
	
	/**
	 * Endere�o do Produtor
	 */
	protected String	Endereco		= null;
	
	/**
	 * Cria um Objeto do tipo Produtor. 																<br>
	 * <table>
	 * @param CgcCpf		CgcCpf 	 do Produtor
	 * @param Matricula	Matricula do Produtor
	 * @param Nome			Nome 		 do Produtor
	 * @param Telefone	Telefone  do Produtor
	 * @param Endereco	Endere�o  do Produtor
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 */
	public Produtor(String CgcCpf, String Matricula, String Nome, String Telefone, String Endereco)
	{
		this.setCgcCpf(CgcCpf)      ; 
		this.setMatricula(Matricula);
		this.setNome(Nome)		    ;
		this.setTelefone(Telefone)  ;
		this.setEndereco(Endereco)  ;
	}
	
	/**
	 * Cria um Objeto Produtor com os Atributos Vazios												<br>
	 * - Utilizar m�todos gets e sets para atribuir e recuperar os valores					<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 */
	public Produtor()
	{
		this("","","","","");
	}
	
	/**
	 *  setCgcCpf																	<br>
	 *	Valor o Atributo CgcCpf desta Classe								<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @param CgcCpf	cgccpf do produtor
	 */
	public void setCgcCpf(String CgcCpf)
	{
		this.CgcCpf = CgcCpf;
	}
	
	/**
	 *  setMatricula 																<br>
	 * Valor o Atributo Matricula Cpf desta Classe						<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @param matricula matricula do produtor
	 */
	public void setMatricula(String Matricula)
	{
		this.Matricula = Matricula;
	}
	
	/** setNome 																	<br>
	 *	Valorar o atributo nome desta classe 								<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com 	<br>
	 * @param nome nome do produtor.
	 */
	public void setNome(String nome)
	{
		this.Nome = nome;
	}
	
	/** setTelefone 																<br>
	 *	Valorar o Atributo Telefone desta classe 							<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @param telefone telefone do produtor.
	 */
	public void setTelefone(String telefone)
	{
		this.Telefone = telefone;
	}
	
	/** setEndereco 																<br>
	 * Valorar o atributo endere�o desta classe							<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @param endereco endere�o do produtor.
	 */
	public void setEndereco(String endereco)
	{
		this.Endereco = endereco;
	}

	public void setAtributosObjeto(String [] linha)
	{
		try
		{
			for (int nrColunas = 0; nrColunas < linha.length; nrColunas++)
			{
				switch (nrColunas)
				{
					case 0:
					{
						this.setCgcCpf(linha[nrColunas]);
						break;
					}
					case 1:
					{
						this.setMatricula(linha[nrColunas]);
						break;
					}
					case 2:
					{
						this.setNome(linha[nrColunas]);
						break;
					}
					case 3:
					{
						this.setEndereco(linha[nrColunas]);
						break;
					}
					case 4:
					{
						this.setTelefone(linha[nrColunas]);
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e)
		{
		}	
	}
	
	/** getCgcCpf																	<br>
	 * Retorna cgcCpf																<br>	
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @return cgcCpf.
	 */
	public String getCgcCpf()
	{
		return this.CgcCpf;
	}
	
	/** getMatricula																<br>
	 * Retorna matricula															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @return matricula do produtor.
	 */
	public String getMatricula()
	{
		return this.Matricula;
	}
	
	/** getNome 																	<br>
	 * Retorna nome																<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @return nome do produtor.
	 */
	public String getNome()
	{
		return this.Nome;
	}
	
	
	/** getTelefone 																<br>
	 * Retorna telefone															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @return telefone do produtor.
	 */
	public String getTelefone()
	{
		return this.Telefone;
	}
	
	/** getEndereco 																<br>
	 * Retorna endereco															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 * @return endereco do produtor											<br>
	 */
	public String getEndereco()
	{
		return this.Endereco;
	}

}

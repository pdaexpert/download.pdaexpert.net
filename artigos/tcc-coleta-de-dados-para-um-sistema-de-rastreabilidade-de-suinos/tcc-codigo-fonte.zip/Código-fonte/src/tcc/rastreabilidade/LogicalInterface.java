/**
 * Universidade Regional de Chapec� - Unochapec�
 * 20/04/2006
 * TCC
 * LogicalObject.java
 **/
package tcc.rastreabilidade;

/**
 * Interface que padroniza os m�todos implementados nas classes de l�gica de neg�cio <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public interface LogicalInterface
{
	/**
	 * <b> setAtributosObjeto </b> -
	 *	Valorar os atributos da Classe com os valores da linha passada como parametro	<br>
	 * @param linha linha retornada pelo DBGrid ou Choose										<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com							<br>
	 */
	public void setAtributosObjeto(String [] linha);

}

/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 24/04/2006 <br>
 * TCC <br>
 * MortalidadeDescarte.java <br>
 */
package tcc.rastreabilidade;

import waba.sys.Convert;
import waba.util.Date;

/**
 * Classe de Gerenciamento das Mortes/ Descartes de Suinos <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class MortalidadeDescarte
	implements LogicalInterface
{

	/**
	 * Suino
	 */
	protected Suino						Suino					= null;
	
	/**
	 * Causa Mortis/ Descarte	 */
	protected CausasMortisDescarte	Causa					= null;
	
	/**
	 * Data Lan�amento
	 */
	protected Date							DataLcto				= null;
	
	/**
	 * Data da morte ou descarte
	 */
	protected Date							DataMorteDescarte	= null;
	
	/**
	 * Peso Estimado do Animal
	 */
	protected double						PesoEstimado		= 0.00;

	
	/**
	 *  Construtor da Classe MortalidadeDescarte.java <br>
	 * @param Suino
	 * @param Causa
	 * @param DataLcto
	 * @param DataMorteDescarte
	 * @param QtdCabecas
	 * @param PesoEstimado <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public MortalidadeDescarte(Suino Suino, 
	                           CausasMortisDescarte Causa,
	                           Date DataLcto, 
	                           Date DataMorteDescarte, 
	                           double PesoEstimado)
	{
		this.setSuino(Suino);
		this.setCausa(Causa);
		this.setDataLcto(DataLcto);
		this.setDataMorteDescarte(DataMorteDescarte);
		this.setPesoEstimado(PesoEstimado);
	}
	
	/**
	 *  Construtor Padr�o da Classe MortalidadeDescarte.java <br>
	 *  <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public MortalidadeDescarte()
	{
		this(new Suino(), new CausasMortisDescarte(), new Date(), new Date(), 0.0);
	}
	
	/** setSuino 																		<br>
	 * Valorar o atributo Suino desta classe									<br>
	 * @param suino 																	<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com		<br>
	 **/
	public void setSuino(Suino suino)
	{
		this.Suino = suino;
	}
	
	/** setCausa 																	<br>
	 * Valorar o atributo Causa desta classe								<br>
	 * @param causa 																<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setCausa(CausasMortisDescarte causa)
	{
		this.Causa = causa;
	}
	
	/** setDataLcto 																<br>
	 * Valorar o atributo DataLcto desta classe							<br>
	 * @param dataLcto 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setDataLcto(Date dataLcto)
	{
		this.DataLcto = dataLcto;
	}
	
	/** setDataMorteDescarte 													<br>
	 * Valorar o atributo DataMorteDescarte desta classe				<br>
	 * @param dataMorteDescarte 												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setDataMorteDescarte(Date dataMorteDescarte)
	{
		this.DataMorteDescarte = dataMorteDescarte;
	}
	
	/** setPesoEstimado 															<br>
	 * Valorar o atributo PesoEstimado desta classe						<br>
	 * @param pesoEstimado 														<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setPesoEstimado(double pesoEstimado)
	{
		this.PesoEstimado = pesoEstimado;
	}
	
	public void setAtributosObjeto(String [] linha)
	{
		Produtor 	produtor 	= new Produtor();
		Propriedade propriedade = new Propriedade();
		Pocilga 		pocilga 		= new Pocilga();
		Lote 			lote 			= new Lote();
		
		try
	 	{
			for (int nrColuna = 0; nrColuna < linha.length; nrColuna++)
			{
				switch (nrColuna)
				{
					case 0:
					{
						produtor.setCgcCpf(linha[nrColuna]);
						break;
					}
					case 1:
					{
						propriedade.setProdutor(produtor);
						propriedade.setPropriedade(Convert.toInt(linha[nrColuna]));
						break;
					}
					case 2:
					{
						pocilga.setPropriedade(propriedade);
						pocilga.setPocilga(Convert.toInt(linha[nrColuna]));
						break;
					}
					case 3:
					{
						lote.setPocilga(pocilga);
						lote.setLote(Convert.toInt(linha[nrColuna]));
						this.Suino.setLote(lote);
						break;
					}
					case 4:
					{
						this.Suino.setSequencia(Convert.toInt(linha[nrColuna]));
						break;
					}
					case 5:
					{
						this.Causa.setCodigoCausa(Convert.toInt(linha[nrColuna]));
					}
					case 6:
					{
						this.DataLcto = new Date(  linha[nrColuna].substring(6,7)
														 + "/"
														 + linha[nrColuna].substring(9,10)
														 + "/"
														 + linha[nrColuna].substring(0,4));
						break;
					}
					case 7:
					{
						this.DataMorteDescarte = new Date(  linha[nrColuna].substring(6,7)
								 									 + "/"
								 									 + linha[nrColuna].substring(9,10)
								 									 + "/"
								 									 + linha[nrColuna].substring(0,4));
						break;
					}
					case 8:
					{
						this.PesoEstimado = Convert.toDouble(linha[nrColuna]);
						break;
					}
					default:
						break;
				}
			}
	 	}
	 	catch (Exception e)
	 	{
	 	}
	}

	/** getSuino 													<br>
	 * Retorna suino												<br>
	 * @return suino												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Suino getSuino()
	{
		return this.Suino;
	}
	
	/** getCausa 													<br>
	 * Retorna causa												<br>
	 * @return causa												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public CausasMortisDescarte getCausa()
	{
		return this.Causa;
	}
	
	/** getDataLcto 													<br>
	 * Retorna dataLcto												<br>
	 * @return dataLcto												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Date getDataLcto()
	{
		return this.DataLcto;
	}
	
	/** getDataMorteDescarte 													<br>
	 * Retorna dataMorteDescarte												<br>
	 * @return dataMorteDescarte												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Date getDataMorteDescarte()
	{
		return this.DataMorteDescarte;
	}
	
	/** getPesoEstimado 													<br>
	 * Retorna pesoEstimado												<br>
	 * @return pesoEstimado												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public double getPesoEstimado()
	{
		return this.PesoEstimado;
	}
}

/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 01/05/2005														<br>
  * TCC											<br>
  * Linha.java												<br>
  **/
package tcc.rastreabilidade.xml.especificos;

import tcc.rastreabilidade.xml.Atributo;
import tcc.rastreabilidade.xml.Elemento;
import waba.util.Vector;

/**
 * Elemento XML "linha" <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Linha
	extends Elemento
{
	/**
	 * Nome do Elemento "linha"
	 */
	protected static final String NOME = "linha";
	
	/**
	 * Nome do Atributo Id "id"
	 */
	protected static final String ID = "id";
	
	/**
	 * Atributo Id
	 */
	protected Atributo Id = null;
	
	/**
	 * Colunas que constituem a linha
	 */
	protected Vector Colunas = new Vector();
		
	/**
	 *  Construtor da Classe Linha.java <br>
	 * @param Id <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	protected Linha(String NrLinha)
	{
		super(); // cria sem nome, conteudo ou atributos
		setNome(NOME); 
		setId(new Atributo(ID,NrLinha));
		addAtributo(getId());
	}
	
	/** setId 													<br>
	 * Valorar o atributo Id desta classe							<br>
	 * @param id 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setId(Atributo id)
	{
		this.Id = id;
	}
	
	/** setColunas 													<br>
	 * Valorar o atributo Colunas desta classe							<br>
	 * @param colunas 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setColunas(Vector colunas)
	{
		Colunas = colunas;
	}
		
	/** getId 													<br>
	 * Retorna id												<br>
	 * @return id												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Atributo getId()
	{
		return this.Id;
	}
	
	/** getColunas 													<br>
	 * Retorna colunas												<br>
	 * @return colunas												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Vector getColunas()
	{
		return this.Colunas;
	}
	
	/**
	 * <b>addColuna</b> - Adicionar uma coluna ao vetor de colunas, que constituem a linha <br>
	 * @param coluna	Coluna a ser adicionada																 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void addColuna(Coluna coluna)
	{
		this.Colunas.add(coluna);
	}
	
	/* desativado
	protected void criarColunas()
	{
		int    nrColunas  = 0;
		Vector ColunasAux = new Vector();
		
		try
		{				
			while (getResultado().next())
			{
				nrColunas = getResultado().getMetaData().getColumnCount();
							
				for (int colunas = 0; colunas < nrColunas; colunas++)
				{
					ColunasAux.add(new Coluna(getResultado().getMetaData().getColumnName(colunas + 1),
									 			     getResultado().getMetaData().getColumnTypeName(colunas + 1),
												     getResultado().getString(colunas + 1)));
				}
			}
			setColunas(ColunasAux);
		}
		catch (Exception e) 
		{
		}
	}
	 */
	
}

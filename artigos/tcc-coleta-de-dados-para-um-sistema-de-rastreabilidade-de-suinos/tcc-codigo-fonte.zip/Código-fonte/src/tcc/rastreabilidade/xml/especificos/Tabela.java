/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 01/05/2005														<br>
  * TCC											<br>
  * Tabela.java												<br>
  **/
package tcc.rastreabilidade.xml.especificos;

import superwaba.ext.xplat.sql.ResultSet;
import superwaba.ext.xplat.sql.ResultSetMetaData;
import tcc.dbAcess.DAO;
import tcc.rastreabilidade.xml.Atributo;
import tcc.rastreabilidade.xml.Elemento;
import tcc.superwaba.custom.sql.CustomSqlType;
import waba.sys.Convert;
import waba.sys.Vm;
import waba.util.Vector;

/**
 * Elemento XML "tabela" <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Tabela
	extends Elemento
{
	/**
	 * Linhas que constituem a tabela
	 */
	private Vector Linhas = new Vector();
	
	/**
	 * Atributo Id
	 */
	private Atributo Id = null;
	
	/**
	 * Objeto DAO
	 */
	private DAO ObjetoDados = null;
	
	/**
	 * Dados que foram obtidos do objeto DAO
	 */
	private ResultSet resultado = null;
	
	/**
	 * Nome do Atributo Id "id"
	 */
	private static final String ID = "id";
	
	/**
	 * Nome deste Elemento "tabela"
	 */
	private static final String NOME = "tabela";
	
	
	/**
	 *  Construtor da Classe Tabela.java <br>
	 * @param ObjetoDados <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Tabela(DAO ObjetoDados)
	{
		super();
		setNome(NOME); //nome do elemento
		setObjetoDados(ObjetoDados);
		setResultado(getObjetoDados().Consultar(false));
		
		setId(new Atributo(ID,getObjetoDados().getTabela()));
		addAtributo(getId());	
		
		criarLinhas();
	}
	
	/** setId 													<br>
	 * Valorar o atributo Id desta classe							<br>
	 * @param id 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setId(Atributo id)
	{
		Id = id;
	}
	
	/** setLinhas 													<br>
	 * Valorar o atributo Linhas desta classe							<br>
	 * @param linhas 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setLinhas(Vector linhas)
	{
		Linhas = linhas;
	}

	/** setObjetoDados 													<br>
	 * Valorar o atributo ObjetoDados desta classe							<br>
	 * @param objetoDados 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setObjetoDados(DAO objetoDados)
	{
		this.ObjetoDados = objetoDados;
	}
	
	/** setResultado 													<br>
	 * Valorar o atributo resultado desta classe							<br>
	 * @param resultado 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setResultado(ResultSet resultado)
	{
		this.resultado = resultado;
	}
	
	/** getId 													<br>
	 * Retorna id												<br>
	 * @return id												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Atributo getId()
	{
		return this.Id;
	}
	
	/** getLinhas 													<br>
	 * Retorna linhas												<br>
	 * @return linhas												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Vector getLinhas()
	{
		return this.Linhas;
	}
	
	/** getObjetoDados 													<br>
	 * Retorna objetoDados												<br>
	 * @return objetoDados												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public DAO getObjetoDados()
	{
		return this.ObjetoDados;
	}
	
	/** getResultado 													<br>
	 * Retorna resultado												<br>
	 * @return resultado												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public ResultSet getResultado()
	{
		return this.resultado;
	}
	
	public void criarLinhas()
	{
		int 					nrColunas 	= 0;
		ResultSetMetaData metaData 	= null;
		Linha 			   linhaAux 	= null;
		int				   nrLinha     = 0;
		
		try
		{
			
			metaData  = getResultado().getMetaData();
			nrColunas = metaData.getColumnCount();

			this.getResultado().beforeFirst();

			while (getResultado().next())
			{
				nrLinha ++;
				linhaAux = new Linha(Convert.toString(nrLinha));
				for (int coluna = 0; coluna < nrColunas; coluna++)
				{
					linhaAux.addColuna(new Coluna(getObjetoDados().nomeColuna(coluna),
										               CustomSqlType.getTypeName(metaData .getColumnType(coluna + 1)),
										               getResultado().getString        (coluna + 1)));
					
				}
				Linhas.add(linhaAux);
			}
		}
		catch (Exception e)
		{
			Vm.debug("Erro tcc.rastreabilidade.xml.especificos.Tabela: " + e.toString());
		}
	}
	
}

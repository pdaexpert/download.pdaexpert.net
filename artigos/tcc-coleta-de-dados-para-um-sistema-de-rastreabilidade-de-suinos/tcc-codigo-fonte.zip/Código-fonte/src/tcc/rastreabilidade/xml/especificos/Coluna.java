/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 01/05/2005														<br>
  * TCC											<br>
  * Coluna.java												<br>
  **/
package tcc.rastreabilidade.xml.especificos;

import tcc.rastreabilidade.xml.Atributo;
import tcc.rastreabilidade.xml.Elemento;
import waba.util.Vector;

/**
 * Elemento XML "coluna" <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Coluna
	extends Elemento
{
	/*
	 * <Coluna 
	 *    Tipo  = Atributo 
	 *    Nome  = Atributo>
	 *    Valor = Conteudo
	 */
	
	/**
	 * Tipo do Conte�do da Coluna (String, Int, Decimal, Boolean)
	 */
	protected Atributo Tipo = null;
	
	/**
	 * Nome da Coluna
	 */
	protected Atributo Nome = null;
	
	/**
	 * Utilizado para instanciar o atributo tipo
	 */
	protected static final String TIPO  = "tipo";
	
	/**
	 * Utilizado para instanciar o atributo nome
	 */
	protected static final String NOME = "nome";
	
	/**
	 * Nome deste elemento 
	 */
	protected static final String ELEMENTO = "coluna";
	
	/**
	 * Construtor da Classe Coluna.java <br>
	 * @param strNome		 Nome da Coluna
	 * @param strTipo		 Tipo do Conte�do da Coluna (String, Boolean, Int)
	 * @param strConteudo Conte�do da Coluna <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Coluna(String strNome, String strTipo, String strConteudo)
	{
		super(); // cria um elemento vazio
		
		/*
		 * Vetor com os atributos e seus valores 
		 */
		Nome = new Atributo(NOME,strNome);
		Tipo = new Atributo(TIPO,strTipo);
		Vector v = new Vector();
		v.add(Nome);
		v.add(Tipo);
		
		/*
		 * Adicionar informa��es ao objeto
		 */
		setNome(ELEMENTO);
		setConteudo(strConteudo);
		setAtributos(v);
		
	}
	
}

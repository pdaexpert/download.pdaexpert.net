/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 01/05/2005														<br>
  * TCC											<br>
  * Atributo.java												<br>
  **/
package tcc.rastreabilidade.xml;

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Atributo
{
	/**
	 * Nome do Atributo
	 */
	private String Nome  = "";
	
	/**
	 * Valor (conte�do do atributo)
	 */
	private String Valor = "";

	/**
	 * Construtor da Classe Atributo.java <br>
	 * @param Nome  Nome do Atributo
	 * @param Valor Valor do Atributo <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Atributo(String Nome, String Valor)
	{
		setNome(Nome);
		setValor(Valor);
	}
	
	/**
	 * Construtor Padr�o da Classe Atributo.java <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Atributo()
	{
		this("","");
	}
	
	
	/** setNome 													<br>
	 * Valorar o atributo Nome desta classe							<br>
	 * @param nome 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setNome(String nome)
	{
		this.Nome = nome;
	}
	
	/** setValor 													<br>
	 * Valorar o atributo Valor desta classe							<br>
	 * @param valor 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setValor(String valor)
	{
		this.Valor = valor;
	}
	
	/** getNome 													<br>
	 * Retorna nome												<br>
	 * @return nome												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getNome()
	{
		return this.Nome.toLowerCase();
	}
	
	/** getValor 													<br>
	 * Retorna valor												<br>
	 * @return valor												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getValor()
	{
		return this.Valor;
	}
	
	/**
	 * <b>retornaNomeValor</b> - <br>
	 * @return nome="valor"																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public String retornaNomeValor()
	{
		return   this.getNome() 
				 + "=" 
				 + "\"" 
				 + this.getValor()
				 + "\""
				 + " ";
	}
	
}

/**
 * Universidade Regional de Chapec� - Unochapec� 17/04/2006 TCC DBGrid.java
 */
package tcc.superwaba.custom.ui;

import superwaba.ext.xplat.sql.ResultSet;
import superwaba.ext.xplat.sql.SQLException;
import waba.sys.Vm;
import waba.ui.Grid;
import waba.ui.MessageBox;
import waba.util.Vector;

/**
 * Grid de Exibi��o de Dados de um ResultSet <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public class DBGrid
	extends Grid
{

	protected String [][]	dados			= null;
	protected Vector			linhas		= null;
	protected Vector			colunas		= null;
	protected ResultSet		resultSet	= null;
	protected int				numColunas	= 0	;
	
	/* =============== CONSTRUTORES ================ */
	/**
	 * DBGrid<br>
	 * Construtor padr�o da Classe DBGrid <br>
	 * @param resultSet	Dados que ser�o exibidos no DBGrid <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public DBGrid(ResultSet resultSet)
	{
		super(returnCaptions(resultSet), returnWidths(resultSet),returnAligns(resultSet), false);
		this.setResultSet(resultSet);
		this.organizarDados(this.getResultSet());
		this.setItems(this.getDados());
	}

	/**
	 * DBGrid<br>
	 * Construtor Extra para a Classe DBGrid<br>
	 * @param resultSet		Dados que ser�o exibidos no DBGrid 
	 * @param Captions		Matriz com os Labels a serem exibidos no DBGrid
	 * @param Widths			Largura das Colunas
	 * @param Aligns			Alinhamento das Colunas
	 * @param checkEnabled	Verdadeiro, quando deseja-se a multisele��o de linhas.
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 */
	public DBGrid(ResultSet resultSet, String[] Captions, int[] Widths, int[] Aligns, boolean checkEnabled)
	{
		super(Captions,Widths,Aligns,checkEnabled);
		this.setResultSet(resultSet);
		this.organizarDados(this.getResultSet());
		this.setItems(this.getDados());
	}
	
	/* ======================= METODOS SET ====================== */
	/**
	 * setDados <br>
	 * Instanciar um vetor de dados, que ser� utilizado no m�todo
	 * super.setItems()
	 * 
	 * @param linhas n�mero de linhas do vetor
	 * @param coluna n�mero de colunas do vetor
	 */
	protected void setDados(int linhas, int colunas)
	{
		this.dados = new String[linhas][colunas];
	}

	/**
	 * setLinhas <br>
	 * Instanciar um Vetor de Linhas <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void setLinhas()
	{
		this.linhas = new Vector();
	}

	/**
	 *  setColunas 
	 * <br>
	 *	Instanciar o vetor de colunas
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 */
	protected void setColunas()
	{
		this.colunas = new Vector();
	}
	
	/**
	 *  setNumColunas 
	 * <br>
	 *	Atribuir o n�mero de colunas do resultset ao atributo desta classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @param numColunas	n�mero de colunas
	 */
	protected void setNumColunas(int numColunas)
	{
		this.numColunas = numColunas;
	}
	
	/**
	 *  setResultSet 
	 * <br>
	 *	Atribuir o ResultSet passado como Parametro ao ResultSet desta Classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @param resultSet	ResultSet
	 */
	public void setResultSet(ResultSet resultSet)
	{
		try
		{
			this.resultSet = resultSet;
			this.setNumColunas(resultSet.getMetaData().getColumnCount());
		}
		catch(SQLException ex)
		{
			new MessageBox("Erro!","ui.DBGrid.setResultSet").popupBlockingModal();
			Vm.debug("Erro ui.DBGrid.setResultSet: ".concat(ex.getMessage()));
		}
	}

	/* (non-Javadoc)
	 * @see waba.ui.Grid#setItems(java.lang.String[][])
	 */
	public void setItems(String [][] items)
	{
		try
		{
			super.setItems(items);
		}
		catch (Exception e1)
		{
		}
	}
	
	/* ============== METODOS GET =============== */
	
	/**
	 * getDados
	 * <br>
	 * retorna o vetor Dados desta Classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 */
	public String[][] getDados()
	{
		return this.dados;
	}
	
	/**
	 * getNumColunas 
	 * <br>
	 *	Retornar o N�mero de Colunas do ResultSet
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @return n�mero de colunas
	 */
	public int getNumColunas()
	{
		return this.numColunas;
	}
	
	/**
	 * getResultSet 
	 * <br>
	 *	Retorna o ResultSet desta Classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @return	ResultSet
	 */
	public ResultSet getResultSet()
	{
		return this.resultSet;
	}
	
	/**
	 *  getLinhas 
	 * <br>
	 *	Retorna o Vetor de linhas desta classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @return	Vetor Linhas
	 */
	protected Vector getLinhas()
	{
		return this.linhas;
	}
	
	/**
	 *  getColunas 
	 * <br>
	 *	Retorna o Vetor de Colunas desta Classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @return	Vetor de Colunas
	 */
	protected Vector getColunas()
	{
		return this.colunas;
	}
	
	
	/* ============= DEMAIS METODOS ============== */
	
	/**
	 * returnCaptions <br>
	 * Constru��o da matriz de labels padr�o de cada coluna que sera mostrada no
	 * DBGrid <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 * @param resultSet ResultSet que ser� analisado e retornar� os labels
	 * @return Captions do DBGrid
	 */
	public static String [] returnCaptions(ResultSet resultSet)
	{
		String [] columnCaptions = null;
		try
		{
			columnCaptions = new String[resultSet.getMetaData().getColumnCount()];
			for (int column = 0; column < resultSet.getMetaData().getColumnCount(); column++)
			{
				columnCaptions[column] = resultSet.getMetaData().getColumnName(column + 1);
			}
		}
		catch (SQLException ex)
		{
			new MessageBox("Erro!", "ui.DBGrid.returnCaptions").popupBlockingModal();
			Vm.debug("Erro ui.DBGrid.returnCaptions: ".concat(ex.getMessage()));
		}
		return columnCaptions;
	}

	/**
	 * returnWidths <br>
	 * Contru��o da Matriz com o Tamanho Padr�o de cada coluna que ser� mostrada
	 * no DBGrid <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 * @param resultSet ResultSet que ser� analisado e retornar� os labels
	 * @return Largura das Colunas do DBGrid
	 */
	public static int [] returnWidths(ResultSet resultSet)
	{
		int [] columnWidths = null;
		try
		{
			columnWidths = new int[resultSet.getMetaData().getColumnCount()];
			for (int column = 0; column < resultSet.getMetaData().getColumnCount(); column++)
			{
				columnWidths[column] = resultSet.getMetaData().getColumnDisplaySize(column + 1);
			}
		}
		catch (SQLException ex)
		{
			new MessageBox("Erro!", "ui.DBGrid.returnWidths").popupBlockingModal();
			Vm.debug("Erro ui.DBGrid.returnWidths: ".concat(ex.getMessage()));
		}
		return columnWidths;
	}

	/**
	 * returnAligns <br>
	 * Matriz com o alinhamento padr�o de cada coluna (ESQUERDA) <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 * @param resultSet ResultSet que ser� analisado e retornar� os labels
	 * @return Alinhamentos das Colunas
	 */
	public static int [] returnAligns(ResultSet resultSet)
	{
		int [] columnAligns = null;
		try
		{
			columnAligns = new int[resultSet.getMetaData().getColumnCount()];
			for (int column = 0; column < resultSet.getMetaData().getColumnCount(); column++)
			{
				columnAligns[column] = LEFT;
			}
		}
		catch (SQLException ex)
		{
			new MessageBox("Erro!", "ui.DBGrid.returnAligns").popupBlockingModal();
			Vm.debug("Erro returnAligns: ".concat(ex.getMessage()));
		}
		return columnAligns;
	}

	/**
	 * organizarDados <br>
	 * Organizar os Dados do ResultSet passado como parametro <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 * @param resultSet ResultSet a Ser organizado
	 */
	public void organizarDados(ResultSet resultSet)
	{

		try
		{
			//resultSet.beforeFirst();

			this.setLinhas();
			
			/* Enquanto tiver linhas */
			while (resultSet.next())
			{
				this.setColunas();
				
				/* Para cada coluna desta linha */
				for (int column = 0; column < this.getNumColunas(); column++)
				{
					this.getColunas().add(resultSet.getString(column + 1));
				}
				this.getLinhas().add(this.getColunas());
			}
			
			this.setDados(this.getLinhas().getCount(),this.getNumColunas());
			this.dados = this.buildDados(this.getDados());
		}
		catch (SQLException ex)
		{
			new MessageBox("Erro!", "ui.DBGrid.organizarDados").popupBlockingModal();
			Vm.debug("Erro addData: ".concat(ex.getMessage()));
		}
	}

	/**
	 * buildDados 
	 * <br>
	 *	Adicionar os dados dos vetors linhas e colunas na matriz dados[][] desta classe
	 * <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
	 * <br>
	 * @param dados	vetor de dados vazio
	 * @return	vetor de dados com informa��es
	 */
	protected String[][] buildDados(String dados[][])
	{
		for (int l = 0; l < dados.length; l++)
		{
			Vector VecAux = (Vector) this.getLinhas().items[l];
			for (int c = 0; c < dados[l].length; c++)
			{
				try
				{
					dados[l][c] = (String) VecAux.items[c];
				}
				catch (ClassCastException e)
				{
					Vm.debug(e.getMessage());
				}
			}
		}
		return dados;
	}
}

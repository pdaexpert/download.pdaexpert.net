/**
 * Universidade Regional de Chapec� - Unochapec� 10/04/2006 TCC Mensagem.java
 */
package tcc.superwaba.custom.ui;

import superwaba.ext.xplat.ui.MultiEdit;
import waba.fx.Color;
import waba.fx.Font;
import waba.ui.Button;
import waba.ui.ControlEvent;
import waba.ui.Event;
import waba.ui.Window;

/**
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 *         Trata Strings passadas como parametro, fazendo com que as mensagens
 *         apare�am de forma organizada na tela do Usu�rio
 */
public class Mensagem
	extends Window
{

	protected String		strTitulo	= null;
	protected String		strTexto		= null;
	protected MultiEdit	edtTexto		= null;
	protected Button		btnSair		= null;
	/**
	 * Mensagem - Construtor Padr�o. Divide o texto passado como parametro em
	 * linhas de at� 30 caracteres.
	 * 
	 * @param strTitulo titulo da mensagem
	 * @param strTexto texto da mensagem
	 */
	public Mensagem(String strTitulo, String strTexto)
	{
		super();
		
		this.setRect(CENTER,CENTER,150,165);
		this.setBorderStyle(RECT_BORDER);
		this.setTitle(strTitulo);
		this.setTitleFont(new Font(this.getFont().name,this.getFont().style,10));
		this.setBackColor(new Color(200,10,10));
		
		this.edtTexto = new MultiEdit("",0,0);
		this.btnSair  = new Button("Ok");
		
		this.add(edtTexto);
		this.add(btnSair);
		
		this.edtTexto.setRect(CENTER,CENTER - 2,this.getRect().width - 20,this.getRect().height - 60);
		this.btnSair.setRect(CENTER,AFTER + 3,PREFERRED + 5,PREFERRED + 3);
	   
		this.edtTexto.setText(strTexto);
		this.edtTexto.setEditable(false);
		this.btnSair.setBackColor(Color.WHITE);
		
		
	}

	/**
	 * dividirMensagem Dividir o Texto em Linhas com o tamanho igual ao n�mero
	 * passado como parametro <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 * @param strTexto texto que ser� dividido
	 * @param intTamanhoLinha tamanho da linha
	 * @return String Texto Dividido
	 */
	/*
	protected static String dividirMensagem(String strTexto, int intTamanhoLinha)
	{
		String strMensagem = null;
		int intNrLinhas = 0;
		int intUltimaPosicao = 0;

		try
		{
			Vm.debug(Convert.toString(intNrLinhas));
			Vm.debug(Convert.toString(strTexto.length()));
			Vm.debug(Convert.toString(intTamanhoLinha));
			intNrLinhas = (strTexto.length() / intTamanhoLinha);
		}
		catch (ArithmeticException e)
		{
			new MessageBox("Erro no Calculo!", e.getMessage());
		}

		for (int i = 0; i < intNrLinhas; i++)
		{
			try
			{
				strMensagem.concat(strTexto.substring(intUltimaPosicao,
						intTamanhoLinha
								* intNrLinhas));
			}
			catch (NullPointerException e)
			{
				new MessageBox("Erro! ", e.getMessage());
			}
			intUltimaPosicao = intTamanhoLinha
										* intNrLinhas
										+ 1;
		}

		return strMensagem;
	}*/
	/* (non-Javadoc)
	 * @see waba.ui.Control#onEvent(waba.ui.Event)
	 */
	public void onEvent(Event event)
	{
		// TODO Auto-generated method stub
		super.onEvent(event);
		switch (event.type)
		{
			case ControlEvent.PRESSED:
			{
				if (event.target == btnSair)
				{
					this.unpop();
				}
				break;
			}

			default:
				break;
		}
	}
}

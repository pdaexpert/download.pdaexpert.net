import tcc.rastreabilidade.Suino;

/**
 * Universidade Regional de Chapec� - Unochapec� 	<br>
 * 01/01/2000														<br>
 * TCC											<br>
 * Teste.java												<br>
 **/

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Rastreabilidade
{
	Suino obj_suino = new Suino();
}

/**
 * Universidade Regional de Chapec� - Unochapec� 01/04/2006 TCC
 */
package tcc.ui.forms;

import tcc.superwaba.custom.ui.CustomMenuBar;
import tcc.superwaba.custom.ui.externos.ControlListBox;
import waba.fx.Font;
import waba.ui.Control;
import waba.ui.ControlEvent;
import waba.ui.Event;
import waba.ui.Window;

/**
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public abstract class Menu
	extends Window
{
	/**
	 * Tamanho Padr�o da Fonte
	 */
	protected static int			TAMANHO_FONTE			= 10;
	
	/**
	 * Custom Menu Bar
	 */
	private CustomMenuBar  MenuBar = null;

	protected ControlListBox clbFundo = new ControlListBox();
	
	/* (non-Javadoc)
	 * @see waba.ui.Window#setMenuBar(waba.ui.Control)
	 */
	public void setMenuBar(CustomMenuBar menubar)
	{
		super.setMenuBar(menubar);
		this.MenuBar = menubar;
	}
	
	/** getMenuBar 													<br>
	 * Retorna menuBar												<br>
	 * @return menuBar												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public CustomMenuBar getMenuBar()
	{
		return this.MenuBar;
	}
	
	/**
	 * <b>setWindowProperties</b> - Configurar a tela com as op��es padr�es necess�rias<br>
	 * @param titulo	titulo da tela
	 * @param menuBar menuBar que ser� inserido na tela											 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void setWindowProperties(String titulo, CustomMenuBar menuBar)
	{
		CustomMenuBar mnbAux = menuBar;
		mnbAux.setFont(new Font(getFont().name,getFont().style,TAMANHO_FONTE));
		setBorderStyle(TAB_ONLY_BORDER);
		setTitle(titulo);
		setMenuBar(mnbAux);
		canDrag = false;
		add(clbFundo);
		clbFundo.setRect(getRect().x,BOTTOM,getRect().width,getRect().height - 12);
		
	}

	public void onEvent(Event evento)
	{
		// TODO Auto-generated method stub
		super.onEvent(evento);
		switch (evento.type)
		{
			case ControlEvent.WINDOW_CLOSED:
			{
				if (evento.target == getMenuBar())
				{
					this.onMenuItemSelected();
				}
				break;
			}

			default:
				break;
		}
	}

	/**
	 *  <b>addOnClb</b> - adicionar controle no ControlListBox <br>
	 * @param control controle a ser adicionado																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void addOnClb(Control control)
	{
		clbFundo.add(control);
	}
	
	/**
	 * <b>onMenuItemSelected</b> - Ser� Chamado ao Selecionar um Item do 
	 * MenuBar (Implementar nas Classes Especializadas)<br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected abstract void onMenuItemSelected();

}

/**
 * Universidade Regional de Chapec� - Unochapec� 01/04/2006 TCC
 * MenuPrincipal.java
 */
package tcc.ui.forms;

import tcc.dbAcess.Conexao;
import tcc.dbAcess.Manutencao;
import tcc.rastreabilidade.export.Exportacao;
import tcc.superwaba.custom.ui.CustomMenuBar;
import tcc.superwaba.custom.ui.Mensagem;

/**
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 * <br>
 * Esta Classe Ser� Utilizada como "Portal" que ir� direcionar �s novas telas,
 * dependento do MenuItem Acionado
 */
public class MenuPrincipal
	extends Menu
{
	/**
	 * Titulo da Window 
	 */
	private static String		TITULO			= ".::. Menu Principal .::.";

	/**
	 * Itens que ser�o exibidos na 1� Coluna
	 */
	private static String []	ITENS_MENU_01	=
															{ "Arquivo", "Exportar", "Manutencao","Sair" };
	
	/**
	 * Itens Que ser�o Exibidos na 2� Coluna
	 */
	private static String []	ITENS_MENU_02	=
															{ "Op��es", "Cadastros -->",
			"Controles -->"							};
	
	/**
	 * Itens Que ser�o Exibidos na 3� Coluna
	 */
	private static String []	ITENS_MENU_03	=
															{ "?", "Ajuda", "Sobre" };
	
	public MenuPrincipal()
	{
		setWindowProperties(TITULO,new CustomMenuBar(new String [][] {ITENS_MENU_01,ITENS_MENU_02,ITENS_MENU_03}));
	}
	
	/**
	 * <b>onMenuItemSelected</b> - Ao Selecionar um Item do MenuBar<br>										 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onMenuItemSelected()
	{
		// TODO Auto-generated method stub
		switch (getMenuBar().getSelectedMenuItem())
		{
			case 1:
			{
				new Exportacao().ExportarXML();
				break;
			}
			case 2:
			{
				Conexao cnx = new Conexao();
				cnx.ConexaoDb2e();
				new Manutencao(cnx).CriarTabelas();
				cnx.FecharConexao();
				
				cnx.ConexaoDb2e();
				new Manutencao(cnx).ImportarDados();
				cnx.FecharConexao();
			}
			case 3:
			{
				this.unpop();
				break;
			}
			case 101:
			{
				new MenuControles().popupModal();
				break;
			}
			case 102:
			{
				new MenuControles().popupModal();
				break;
			}
			case 201:
			{
				new Mensagem(".::. Ajuda .::.",  "Exportar  = Gerar Arquivo com Dados Existentes no Banco de Dados do Palm\n\n" 
					    								 + "Cadastros = Cadastrar informa��es sobre Associados, Propriedades, etc.\n\n"
					    								 + "Controles = Controles de Mortalidade de Suinos, Consumo de Ra��o, etc.\n\n").popupModal();
				break;
			}
			case 202:
			{
				new Mensagem(".::. Sobre .::.",  "Prot�tipo de Coleta de Dados para " 
													    + "Um sistema de Rastreabiliade de Suinos\n\n"
													    + "Desenvolvido Por Jose Volnei Dal Pra Junior " 
													    + "no ano de 2006 como Trabalho de Conclus�o" 
													    + "de Curso Utilizando a Empresa CooperAlfa como "
													    + "Objeto de Estudo.\n\n"
													    + "jrdalpra@gmail.com \n(49) 9112-9359").popupModal();
				break;
			}
			default:
			{
				if (getMenuBar().getMenuItemCaption(getMenuBar().getSelectedMenuItem()) != null)
				{
					new MenuOperacoes(getMenuBar().getMenuItemCaption(getMenuBar().getSelectedMenuItem())).popupModal();
				}
				break;
			}
		}

	}

}

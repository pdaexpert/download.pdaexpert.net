/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 06/05/2006														<br>
  * TCC											<br>
  * MenuControles.java												<br>
  **/
package tcc.ui.forms;

import tcc.ui.forms.mortalidade.FrmMortalidade;

/**
 * Formul�rio para os controles do sistema 							<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class MenuControles
	extends MenuSecundario
{
	/**
	 *  Construtor da Classe MenuControles.java <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public MenuControles()
	{
		super("Controles",new String[] {"Mortalidade","Consumo Ra��o","Avalia��o Pocilga"});
	}
	
	/* (non-Javadoc)
	 * @see tcc.ui.forms.MenuSecundario#onButtonPressed(int)
	 */
	protected void onButtonPressed(int buttonNumber)
	{
		// TODO Auto-generated method stub
		super.onButtonPressed(buttonNumber);
		switch (buttonNumber)
		{
			case 0: //mortalidade
			{
				onBtnMortalidadePressed();
				break;
			}
			case 1: //controle ra��o
			{
				onBtnControleRacaoPressed();
				break;
			}
			case 2: // avalia��o pocilga
			{
				onBtnAvalicaoPocilgaPressed();
				break;
			}
			default:
				break;
		}
	}
	
	/**
	 *  <b>onBtnMortalidadePressed</b> - Executa quando precionado o bot�o Mortalidade <br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void onBtnMortalidadePressed()
	{
		new FrmMortalidade().popupBlockingModal();
	}
	
	/**
	 *  <b>onBtnControleRacaoPressed</b> - Executa Quando Pressionado o Bot�o Controle Ra��o <br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void onBtnControleRacaoPressed()
	{
		
	}
	/**
	 *  <b>onBtnAvalicaoPocilgaPressed</b> - Executado quando precionado o bot�o Avalia��o Pocilga <br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void onBtnAvalicaoPocilgaPressed()
	{
		
	}
}

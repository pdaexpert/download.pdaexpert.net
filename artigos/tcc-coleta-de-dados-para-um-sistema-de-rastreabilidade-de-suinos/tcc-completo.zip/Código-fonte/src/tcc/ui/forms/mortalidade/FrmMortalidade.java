/**
 * Universidade Regional de Chapec� - Unochapec� 06/04/2006 TCC Formulario.java
 */
package tcc.ui.forms.mortalidade;

import tcc.dbAcess.CausasMortisDescarteDAO;
import tcc.dbAcess.Conexao;
import tcc.dbAcess.LoteDAO;
import tcc.dbAcess.MortalidadeDescarteDAO;
import tcc.dbAcess.PocilgaDAO;
import tcc.dbAcess.ProdutorDAO;
import tcc.dbAcess.PropriedadeDAO;
import tcc.dbAcess.SuinoDAO;
import tcc.rastreabilidade.CausasMortisDescarte;
import tcc.rastreabilidade.Lote;
import tcc.rastreabilidade.MortalidadeDescarte;
import tcc.rastreabilidade.Pocilga;
import tcc.rastreabilidade.Produtor;
import tcc.rastreabilidade.Propriedade;
import tcc.rastreabilidade.Suino;
import tcc.superwaba.custom.ui.CustomMenuBar;
import tcc.ui.forms.Choose;
import waba.sys.Convert;
import waba.sys.Vm;
import waba.ui.Button;
import waba.ui.ControlEvent;
import waba.ui.Edit;
import waba.ui.Event;
import waba.ui.Label;
import waba.ui.Window;
import waba.util.Date;

/**
 * Formul�rio de Inser��o de Dados sobre a Mortalidade/Descarte de Animais
 * 
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public class FrmMortalidade
	extends Window
{
	protected Conexao						cnxConexao				= null;

	/* Objetos L�gicos */
	/**
	 * @see Produtor
	 */
	protected Produtor					produtor					= null;

	/**
	 * @see Propriedade
	 */
	protected Propriedade				propriedade				= null;

	/**
	 * @see Pocilga
	 */
	protected Pocilga						pocilga					= null;

	/**
	 * @see Lote
	 */
	protected Lote							lote						= null;

	/**
	 * @see Suino
	 */
	protected Suino						suino						= null;

	/**
	 * @see CausasMortisDescarte
	 */
	protected CausasMortisDescarte	causa						= null;

	/**
	 * @see MortalidadeDescarte
	 */
	protected MortalidadeDescarte		mortalidadedescarte	= null;

	/* Objetos de Interface */
	protected Label						lblProdutor				= null;
	protected Edit							edtProdutor				= null;
	protected Button						btnProdutor				= null;

	protected Label						lblPropriedade			= null;
	protected Edit							edtPropriedade			= null;
	protected Button						btnPropriedade			= null;

	protected Label						lblPocilga				= null;
	protected Edit							edtPocilga				= null;
	protected Button						btnPocilga				= null;

	protected Label						lblLote					= null;
	protected Edit							edtLote					= null;
	protected Button						btnLote					= null;

	protected Label						lblCausa					= null;
	protected Edit							edtCausa					= null;
	protected Button						btnCausa					= null;

	protected Label						lblSuino					= null;
	protected Edit							edtSuino					= null;
	protected Button						btnSuino					= null;

	protected Label						lblPeso					= null;
	protected Edit							edtPeso					= null;

	protected Label						lblDataMorte			= null;
	protected Edit							edtDataMorte			= null;

	protected Button						btnOk						= null;
	protected Button						btnCancelar				= null;

	protected CustomMenuBar				menu						= new CustomMenuBar(new String[][]
																			{
																			{ "Operacoes",
			"Incluir", "Alterar", "Consultar", "Excluir", "Sair" } });

	protected String						Operacao					= "";

	/**
	 * Construtor da Classe FrmMortalidade.java <br>
	 * Controi uma Interface para inclusao de dados sobre a Mortalidade de Suinos <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public FrmMortalidade()
	{
		setBorderStyle(TAB_ONLY_BORDER);
		setTitle(".::. Mortalidade .::. ");
		setOperacao(Operacao);
		canDrag = false;
		setMenuBar(menu);
		addItens();
		addObjetos();
		LimparEdits();
		DesabilitarTodos();
	}

	/**
	 * setOperacao <br>
	 * Valorar o atributo Operacao desta classe <br>
	 * 
	 * @param operacao <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void setOperacao(String operacao)
	{
		this.Operacao = operacao;
	}

	/**
	 * getOperacao <br>
	 * Retorna operacao <br>
	 * 
	 * @return operacao <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public String getOperacao()
	{
		return this.Operacao;
	}

	public void onEvent(Event event)
	{
		// TODO Auto-generated method stub
		super.onEvent(event);

		switch (event.type)
		{
			case ControlEvent.PRESSED:
			{
				if (event.target == btnProdutor)
				{
					onPressBtnProdutor();
				}
				if (event.target == btnPropriedade)
				{
					onPressBtnPropriedade();
				}
				if (event.target == btnPocilga)
				{
					onPressBtnPocilga();
				}
				if (event.target == btnLote)
				{
					onPressBtnLote();
				}
				if (event.target == btnSuino)
				{
					onPressBtnSuino();
				}
				if (event.target == btnCausa)
				{
					onPressBtnCausa();
				}
				if (event.target == btnOk)
				{
					onPressBtnOk();
				}
				if (event.target == btnCancelar)
				{
					onPressBtnCancelar();
				}
				break;
			}
			case ControlEvent.WINDOW_CLOSED:
			{
				if (event.target == menu)
				{
					onMenuItemSelected();
					break;
				}
			}
			default:
			{
				break;
			}

		}

	}

	/**
	 * <b>addItens</b> - Inserir os objetos de interface <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void addItens()
	{
		lblProdutor = new Label("Produtor");
		edtProdutor = new Edit("99999999999999");
		btnProdutor = new Button(" ... ");

		lblPropriedade = new Label("Propriedade");
		edtPropriedade = new Edit("999");
		btnPropriedade = new Button(" ... ");

		lblPocilga = new Label("Pocilga");
		edtPocilga = new Edit("999");
		btnPocilga = new Button(" ... ");

		lblLote = new Label("Lote");
		edtLote = new Edit("999");
		btnLote = new Button(" ... ");

		lblSuino = new Label("Suino");
		edtSuino = new Edit("9999");
		btnSuino = new Button(" ... ");

		lblCausa = new Label("Causa");
		edtCausa = new Edit("999");
		btnCausa = new Button(" ... ");

		lblPeso = new Label("Peso");
		edtPeso = new Edit("9.999,00");

		lblDataMorte = new Label("Data Morte");
		edtDataMorte = new Edit("99/99/9999");

		btnOk = new Button("Ok");
		btnCancelar = new Button("Cancelar");

		edtProdutor.setMaxLength(14);
		edtPropriedade.setMaxLength(3);
		edtPocilga.setMaxLength(3);
		edtLote.setMaxLength(3);
		edtCausa.setMaxLength(3);
		edtPeso.setMaxLength(8);
		edtDataMorte.setMaxLength(10);

		edtPeso.setMode(Edit.CURRENCY);
		edtDataMorte.setMode(Edit.DATE);

		edtPeso.alignment = RIGHT;

		add(lblProdutor);
		add(edtProdutor);
		add(btnProdutor);

		add(lblPropriedade);
		add(edtPropriedade);
		add(btnPropriedade);

		add(lblPocilga);
		add(edtPocilga);
		add(btnPocilga);

		add(lblLote);
		add(edtLote);
		add(btnLote);

		add(lblSuino);
		add(edtSuino);
		add(btnSuino);

		add(lblCausa);
		add(edtCausa);
		add(btnCausa);

		add(lblPeso);
		add(edtPeso);

		add(lblDataMorte);
		add(edtDataMorte);

		add(lblDataMorte);
		add(edtDataMorte);

		add(btnOk);
		add(btnCancelar);

		lblProdutor.setRect(LEFT + 5, TOP + 5, PREFERRED, PREFERRED);
		edtProdutor.setRect(SAME, AFTER, PREFERRED, PREFERRED, lblProdutor);
		btnProdutor.setRect(AFTER,
				SAME,
				PREFERRED,
				this.edtProdutor.getRect().height,
				this.edtProdutor);

		lblPropriedade.setRect(lblProdutor.getRect().x,
				btnProdutor.getRect().y + 18,
				PREFERRED,
				PREFERRED);
		edtPropriedade.setRect(SAME, AFTER, PREFERRED, PREFERRED, lblPropriedade);
		btnPropriedade.setRect(AFTER,
				SAME,
				PREFERRED,
				this.edtProdutor.getRect().height,
				this.edtPropriedade);

		lblPocilga.setRect(lblProdutor.getRect().x + 58,
				lblPropriedade.getRect().y,
				PREFERRED,
				PREFERRED);
		edtPocilga.setRect(edtPropriedade.getRect().x + 58,
				edtPropriedade.getRect().y,
				PREFERRED,
				PREFERRED,
				lblPropriedade);
		btnPocilga.setRect(btnPropriedade.getRect().x + 58,
				btnPropriedade.getRect().y,
				PREFERRED,
				this.edtProdutor.getRect().height,
				this.edtPropriedade);

		lblLote.setRect(lblProdutor.getRect().x + 110,
				lblPropriedade.getRect().y,
				PREFERRED,
				PREFERRED);
		edtLote.setRect(edtPropriedade.getRect().x + 110,
				edtPropriedade.getRect().y,
				PREFERRED,
				PREFERRED,
				lblPropriedade);
		btnLote.setRect(btnPropriedade.getRect().x + 110,
				btnPropriedade.getRect().y,
				PREFERRED,
				this.edtProdutor.getRect().height,
				this.edtPropriedade);

		lblSuino.setRect(lblProdutor.getRect().x,
				lblPropriedade.getRect().y + 30,
				PREFERRED,
				PREFERRED);
		edtSuino.setRect(SAME, AFTER, PREFERRED, PREFERRED, lblSuino);
		btnSuino.setRect(AFTER,
				SAME,
				PREFERRED,
				this.edtProdutor.getRect().height,
				edtSuino);

		lblCausa.setRect(lblSuino.getRect().x + 58,
				lblSuino.getRect().y,
				PREFERRED,
				PREFERRED);
		edtCausa.setRect(SAME, AFTER, PREFERRED, PREFERRED, lblCausa);
		btnCausa.setRect(AFTER,
				SAME,
				PREFERRED,
				this.edtProdutor.getRect().height,
				edtCausa);

		lblPeso.setRect(lblSuino.getRect().x,
				lblSuino.getRect().y + 30,
				PREFERRED,
				PREFERRED);
		edtPeso.setRect(SAME, AFTER, PREFERRED, PREFERRED, lblPeso);
		lblDataMorte.setRect(lblPeso.getRect().x + 58,
				lblPeso.getRect().y,
				PREFERRED,
				PREFERRED);
		edtDataMorte.setRect(SAME, AFTER, PREFERRED, PREFERRED, lblDataMorte);

		btnOk.setRect(LEFT + 15, BOTTOM - 8, PREFERRED + 5, PREFERRED + 3);
		btnCancelar.setRect(RIGHT - 15, BOTTOM - 8, PREFERRED + 5, PREFERRED + 3);
	}

	/**
	 * <b>addObjetos</b> - Instanciar os objetos l�gicos <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void addObjetos()
	{
		cnxConexao = new Conexao();
		produtor = new Produtor();
		propriedade = new Propriedade();
		pocilga = new Pocilga();
		lote = new Lote();
		suino = new Suino();
		causa = new CausasMortisDescarte();
		mortalidadedescarte = new MortalidadeDescarte();
	}

	/**
	 *  <b>HabilitarTodos</b> - habilitar todos os objetos da window <br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void HabilitarTodos()
	{
		for (int nrControles = 0; nrControles < getChildren().length; nrControles++)
		{
			getChildren()[nrControles].setEnabled(true);
		}
	}

	/**
	 * <b>DesabilitarTodos</b> - Desabilitar todos os Objetos da Window <br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void DesabilitarTodos()
	{
		for (int nrControles = 0; nrControles < getChildren().length; nrControles++)
		{
			getChildren()[nrControles].setEnabled(false);
		}
	}


	/**
	 * <b>LimparEdits</b> - Limpar todos os edits <br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void LimparEdits()
	{
		edtProdutor		.setText("");
		edtPropriedade	.setText("");
		edtPocilga		.setText("");
		edtLote			.setText("");
		edtCausa			.setText("");
		edtSuino			.setText("");
		edtPeso			.setText("");
		edtDataMorte	.setText("");
	}

	/*
	 * Eventos
	 */

	/**
	 * <b>onPressBtnProdutor</b> - Executa ao pressionar o bot�o Produtor <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnProdutor()
	{
		LimparEdits();
		addObjetos();
		
		cnxConexao.ConexaoDb2e();
		Choose choose = new Choose(new ProdutorDAO(cnxConexao, produtor).Consultar(true),produtor);
		choose.popupBlockingModal();
		cnxConexao.FecharConexao();
		
		edtProdutor.setText(this.produtor.getCgcCpf());

		if ((getOperacao().toLowerCase().compareTo("consultar") == 0)
				|| (getOperacao().toLowerCase().compareTo("alterar") == 0)
				|| (getOperacao().toLowerCase().compareTo("excluir") == 0))
		{
			if (edtProdutor.getText().length() > 0)
			{
				MortalidadeDescarteDAO morteDAO = null;
				cnxConexao.ConexaoDb2e();
				morteDAO = new MortalidadeDescarteDAO(cnxConexao,mortalidadedescarte);			
				morteDAO.setWhere("where "
						            + morteDAO.getTabela()
										+ "."
										+ morteDAO.getCampos()[0]
										+ " = '"
										+ produtor.getCgcCpf()
										+ "'");
				Choose choose2 = new Choose(morteDAO.Consultar(false),mortalidadedescarte);
				choose2.popupBlockingModal();
				cnxConexao.FecharConexao();
				
				edtPropriedade.setText(mortalidadedescarte.getSuino()
						.getLote()
						.getPocilga()
						.getPropriedade()
						.getPropriedade()
												+ "");
				edtPocilga.setText(mortalidadedescarte.getSuino()
						.getLote()
						.getPocilga()
						.getPocilga()
											+ "");
				edtLote.setText(mortalidadedescarte.getSuino().getLote().getLote()
										+ "");
				edtSuino.setText(mortalidadedescarte.getSuino().getSequencia()
										+ "");
				edtCausa.setText(mortalidadedescarte.getCausa().getCodigoCausa()
										+ "");
				edtPeso.setText(mortalidadedescarte.getPesoEstimado()
										+ "");
				edtDataMorte.setText(mortalidadedescarte.getDataMorteDescarte()
											+ "");
			}
		}
	}

	/**
	 * <b>onPressBtnPropriedade</b> - Executa ao pressionar o botao Propriedade<br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnPropriedade()
	{
		if (getOperacao().toLowerCase().compareTo("incluir") == 0)
		{
			
			propriedade.setProdutor(produtor);
			
			cnxConexao.ConexaoDb2e();
			Choose choose = new Choose(new PropriedadeDAO(cnxConexao, propriedade).Consultar(true),propriedade);
			choose.popupBlockingModal();
			cnxConexao.FecharConexao();
			
			edtPropriedade.setText(Convert.toString(propriedade.getPropriedade()));
		}

	}

	/**
	 * <b>onPressBtnPocilga</b> - Executa ap�s pressionar o bot�o Pocilga <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnPocilga()
	{
		
		if (getOperacao().toLowerCase().compareTo("incluir") == 0)
		{
			pocilga.setPropriedade(propriedade);

			cnxConexao.ConexaoDb2e();
			Choose choose = new Choose(new PocilgaDAO(cnxConexao, pocilga).Consultar(true),pocilga);
			choose.popupBlockingModal();
			cnxConexao.FecharConexao();
			
			edtPocilga.setText(Convert.toString(pocilga.getPocilga()));
			
		}
		
	}

	/**
	 * <b>onPressBtnLote</b> - Executa ap�s pressionar o bot�o lote <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnLote()
	{

		if (getOperacao().toLowerCase().compareTo("incluir") == 0)
		{
			lote.setPocilga(pocilga);
			
			cnxConexao.ConexaoDb2e();
			Choose choose = new Choose(new LoteDAO(cnxConexao, lote).Consultar(true),lote);
			choose.popupBlockingModal();
			cnxConexao.FecharConexao();
			
			edtLote.setText(Convert.toString(lote.getLote()));
		}
		
	}

	/**
	 * <b>onPressBtnCausa</b> - Executa ap�s pressionar o bot�o Causa <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnCausa()
	{
		if ((getOperacao().toLowerCase().compareTo("incluir") == 0)
				|| (getOperacao().toLowerCase().compareTo("alterar") == 0))
		{
			cnxConexao.ConexaoDb2e();
			Choose choose = new Choose(new CausasMortisDescarteDAO(cnxConexao,
					causa).Consultar(true), causa);
			choose.popupBlockingModal();
			cnxConexao.FecharConexao();
			edtCausa.setText(Convert.toString(causa.getCodigoCausa()));
		}
	}

	/**
	 * <b>onPressBtnSuino</b> - Executa ap�s pressionar o bot�o Suino <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnSuino()
	{
		
		if (getOperacao().toLowerCase().compareTo("incluir") == 0)
		{
			suino.setLote(lote);
			
			cnxConexao.ConexaoDb2e();
			Choose choose = new Choose(new SuinoDAO(cnxConexao, suino).Consultar(true),suino);
			choose.popupBlockingModal();
			cnxConexao.FecharConexao();
			
			edtSuino.setText(Convert.toString(suino.getSequencia()));
		}
		
	}

	/**
	 * <b>onPressBtnOk</b> - Executa ap�s pressionar o bot�o OK <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnOk()
	{
		boolean ok = false;

		

		if (edtCausa.getText().compareTo("0") != 0)
		{
			mortalidadedescarte.setCausa(causa);
			mortalidadedescarte.setDataLcto(new Date());
			mortalidadedescarte.setDataMorteDescarte(new Date(edtDataMorte.getText()));
			mortalidadedescarte.setPesoEstimado(Convert.toDouble(edtPeso.getText()));
		}

		if (getOperacao().toLowerCase().compareTo("incluir") == 0)
		{
			if ((edtProdutor.getText().length() > 0)
					&& (edtPropriedade.getText().length() > 0)
					&& (edtPocilga.getText().length() > 0)
					&& (edtLote.getText().length() > 0)
					&& (edtSuino.getText().length() > 0)
					&& (edtCausa.getText().length() > 0)
					&& (edtPeso.getText().length() > 0))
			{
				mortalidadedescarte.setSuino(suino);
				
				cnxConexao.ConexaoDb2e();
				new MortalidadeDescarteDAO(cnxConexao, mortalidadedescarte).Inserir();
				cnxConexao.FecharConexao();
				
				ok = true;
			}
		}
		if (getOperacao().toLowerCase().compareTo("alterar") == 0)
		{
			cnxConexao.ConexaoDb2e();
			new MortalidadeDescarteDAO(cnxConexao, mortalidadedescarte).Atualizar();
			cnxConexao.FecharConexao();
			
			ok = true;
		}
		
		if (getOperacao().toLowerCase().compareTo("consultar") == 0)
		{
			ok = true;
		}
		
		if (getOperacao().toLowerCase().compareTo("excluir") == 0)
		{
			cnxConexao.ConexaoDb2e();
			new MortalidadeDescarteDAO(cnxConexao, mortalidadedescarte).Excluir();
			cnxConexao.FecharConexao();
			
			ok = true;
		}

		if (ok)
		{
			LimparEdits();
			DesabilitarTodos();
		}
		
		//cnxConexao.FecharConexao();
		Vm.debug("desconectou");
	}

	/**
	 * <b>onPressBtnCancelar</b> - Executa ap�s pressionar o bot�o Cancelar <br>
	 * 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	protected void onPressBtnCancelar()
	{
		LimparEdits();
		DesabilitarTodos();
	}

	protected void onMenuItemSelected()
	{
		switch (menu.getSelectedMenuItem())
		{
			case 1:
			case 2:
			case 3:
			case 4:
			{
				HabilitarTodos();
				setOperacao(menu.getMenuItemCaption(menu.getSelectedMenuItem()));
				break;
			}
			case 5:
			{
				unpop();
				break;
			}
			default:
				break;
		}

	}

}

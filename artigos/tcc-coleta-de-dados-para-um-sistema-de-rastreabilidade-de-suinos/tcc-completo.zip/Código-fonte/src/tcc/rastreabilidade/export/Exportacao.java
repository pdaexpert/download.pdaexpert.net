/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 29/04/2005														<br>
  * TCC											<br>
  * Exportacao.java												<br>
  **/
package tcc.rastreabilidade.export;

import tcc.rastreabilidade.xml.especificos.Transferencia;
import waba.io.File;
import waba.sys.Settings;
import waba.sys.Vm;
import waba.ui.MessageBox;
import waba.util.Date;

/**
 * Exporta��o de Dados do BD												<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Exportacao
{

	/**
	 * Arquivo que ter� o seu conte�do gravado no Palm
	 */
	protected File arquivo = null;
	
	/**
	 *  Construtor da Classe Exportacao.java <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Exportacao()
	{
		setArquivo(criaArquivo());
	}
	
	/** setArquivo 													<br>
	 * Valorar o atributo arquivo desta classe							<br>
	 * @param arquivo 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setArquivo(File arquivo)
	{
		this.arquivo = arquivo;
	}
	
	/** getArquivo 													<br>
	 * Retorna arquivo												<br>
	 * @return arquivo												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public File getArquivo()
	{
		return this.arquivo;
	}
	
	protected File criaArquivo()
	{
		String path = "";
		if (Settings.platform.toLowerCase().equals("WindowsCE".toLowerCase()))
		{
			path = "/";
		}
		else
		{
			if (Settings.platform.toLowerCase().equals("PocketPC".toLowerCase()))
			{
				path = "/";
			}
			else
			{
				if (Settings.platform.toLowerCase().equals("Linux".toLowerCase()))
				{
					
				}
				else
				{
					if (Settings.platform.toLowerCase().equals("PalmOS".toLowerCase()))
					{
						path = "/";
					}
					else
					{
						Vm.debug("Sistema Desconhecido");
					}
				}
				
			}
		}
		
		File arquivoAux = null;
		if (File.isAvailable() == false)
		{
         Vm.debug("Arquivo nao disponivel!");
		}
      else
      { 
      	if (File.isCardInserted(-1) == false)
      	{
      		Vm.debug("Nenhum Cart�o Inserido!");
      	}
         else
         {
         	arquivoAux = new File(path + "rastreabilidade.xml",File.CREATE,-1);
         }		
      }
		return arquivoAux;
	}
	
	/**
	 * <b>Exportar</b> - Exportar o conte�do do Banco de Dados em Formato XML <br>
	 * 																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void ExportarXML()
	{
		Transferencia transf = null;
		String 		  tag 	= "";
		MessageBox	  msb		= null;
		try
		{
			transf = new Transferencia(new Date());
			msb	 = new MessageBox("Aten��o!","Exportando Dados ... ",null);
			msb.setUnpopDelay(1000);
		
			msb.popupModal();
			for (int i = 0; i < transf.getBuffer().getCount(); i++)
			{
				tag = (String) transf.getBuffer().items[i];
				getArquivo().writeBytes(tag.getBytes(),0,tag.length());
				
				
			}
			getArquivo().close();
		}
		catch (Exception e)
		{
			Vm.debug("Erro tcc.rastreabilidade.export.Exportacao: " + e.toString());
		}
	}
	
}

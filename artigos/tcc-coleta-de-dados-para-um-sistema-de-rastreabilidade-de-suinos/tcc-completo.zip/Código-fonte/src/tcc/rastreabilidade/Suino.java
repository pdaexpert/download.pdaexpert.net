/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 23/04/2006 <br>
 * TCC <br>
 * Suino.java <br>
 */
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Suino - L�gica <br>
 * 
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class Suino
	implements LogicalInterface
{

	/**
	 * Lote em que o suino esta alocado
	 */
	protected Lote						lote					= null;
	
	/**
	 * Numero sequencial de identifica��o do suino
	 */
	protected int						sequencia			= 0;
	
	/**
	 * Tipo de identificaca��o do suino
	 */
	protected TipoIdentificacao	tipoidentificacao	= null;
	
	/**
	 * Fase do su�no
	 */
	protected Fase						fase					= null;
	
	/**
	 * Ra�a
	 */
	protected Raca						raca					= null;
	
	/**
	 *<b>M</b>acho ou <b>F</b>emea
	 */
	protected char					sexo						= 'm';
	
	/**
	 *  Construtor da Classe Suino.java <br>
	 * @param lote						lote no qual o suino esta alocado
	 * @param sequencia				codigo do suino (identificacao)
	 * @param tipoidentificacao	tipo de identificacao utilizada
	 * @param fase						fase em que se encontra o suino
	 * @param raca						raca do suino
	 * @param sexo 					macho ou femea						 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Suino(Lote lote, 
	             int sequencia, 
	             TipoIdentificacao tipoidentificacao, 
	             Fase fase, 
	             Raca raca, 
	             char sexo)
	{
		this.setLote(lote);
		this.setSequencia(sequencia);
		this.setTipoidentificacao(tipoidentificacao);
		this.setFase(fase);
		this.setRaca(raca);
	}
	
	/** Construtor da Classe Suino.java <br>
	 *  <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 **/
	public Suino()
	{
		this(new Lote(), 0,new TipoIdentificacao(),new Fase(), new Raca(), 'm');
	}
	
	
	/** setLote 													          <br>
	 * Valorar o atributo lote desta classe							 <br>
	 * @param lote 															 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 **/
	public void setLote(Lote lote) 
	{
		this.lote = lote;
	}

	/** setSequencia 													<br>
	 * Valorar o atributo sequencia desta classe							<br>
	 * @param sequencia 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setSequencia(int sequencia) 
	{
		this.sequencia = sequencia;
	}
	
	/** setTipoidentificacao 													<br>
	 * Valorar o atributo tipoidentificacao desta classe							<br>
	 * @param tipoidentificacao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setTipoidentificacao(TipoIdentificacao tipoidentificacao)
	{
		this.tipoidentificacao = tipoidentificacao;
	}
	
	/** setFase 													<br>
	 * Valorar o atributo fase desta classe							<br>
	 * @param fase 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setFase(Fase fase)
	{
		this.fase = fase;
	}
	
	/** setRaca 													<br>
	 * Valorar o atributo raca desta classe							<br>
	 * @param raca 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setRaca(Raca raca)
	{
		this.raca = raca;
	}
	
	/** setSexo 													<br>
	 * Valorar o atributo sexo desta classe							<br>
	 * @param sexo 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setSexo(char sexo)
	{
		this.sexo = sexo;
	}
	
	public void setAtributosObjeto(String [] linha)
	{
		Produtor 			produtor 	= null;
		Propriedade 		propriedade = null;
		Pocilga 				pocilga 		= null;
		
		try
		{
			for (int nrAtributo = 0; nrAtributo < linha.length; nrAtributo++)
			{
				switch (nrAtributo)
				{
					case 0:
					{
						produtor = new Produtor(linha[nrAtributo],"","","","");
						break;
					}
					case 1:
					{
						propriedade = new Propriedade(produtor,Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 2:
					{
						pocilga = new Pocilga(propriedade,Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 3:
					{
						setLote(new Lote(pocilga,Convert.toInt(linha[nrAtributo])));
						break;
					}
					case 4:
					{
						setSequencia(Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 5:
					{
						setTipoidentificacao(new TipoIdentificacao(Convert.toInt(linha[nrAtributo]),""));
						break;
					}
					case 6:
					{
						setFase(new Fase(Convert.toInt(linha[nrAtributo]),""));
						break;
					}
					case 7:
					{
						setRaca(new Raca(Convert.toInt(linha[nrAtributo]),""));
						break;
					}
					case 8:
					{
						setSexo(linha[nrAtributo].charAt(0));
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e)
		{
		}
	}

	/** getLote 													<br>
	 * Retorna lote												<br>
	 * @return lote												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Lote getLote()
	{
		return this.lote;
	}
	
	
	/** getSequencia 													<br>
	 * Retorna sequencia												<br>
	 * @return sequencia												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public int getSequencia()
	{
		return this.sequencia;
	}
	
	/** getTipoidentificacao 													<br>
	 * Retorna tipoidentificacao												<br>
	 * @return tipoidentificacao												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public TipoIdentificacao getTipoidentificacao()
	{
		return this.tipoidentificacao;
	}
	
	/** getFase 													<br>
	 * Retorna fase												<br>
	 * @return fase												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Fase getFase()
	{
		return this.fase;
	}
	
	/** getRaca 													<br>
	 * Retorna raca												<br>
	 * @return raca												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Raca getRaca()
	{
		return this.raca;
	}
	
	/** getSexo 													<br>
	 * Retorna Sexo												<br>
	 * @return Sexo												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public char getSexo()
	{
		return this.sexo;
	}
}

/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 22/04/2006 <br>
 * TCC <br>
 * Fase.java <br>
 */
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Fase do Animal (leit�o, suino, etc)								 <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class Fase
	implements LogicalInterface
{

	/**
	 * C�digo da Fase
	 */
	protected int							Fase			= 0;
	
	/**
	 * Descrica��o da Fase
	 */
	protected String						Descricao	= null;
	
	/**
	 * Construtor da Classe Fase <br>
	 * @param Fase		  C�digo da Fase
	 * @param Descricao Descri��o da Fase <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Fase(int Fase, String Descricao)
	{
		this.setFase(Fase);
		this.setDescricao(Descricao);
	}
	
	/**
	 *  Construtor Padr�o da Classe Fase <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Fase()
	{
		this(0,"");
	}
	
	/** setFase 																	<br>
	 * Valorar o atributo Fase desta classe								<br>
	 * @param fase 																<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setFase(int fase)
	{
		this.Fase = fase;
	}
	
	/** setDescricao 																<br>
	 * Valorar o atributo Descricao desta classe							<br>
	 * @param descricao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setDescricao(String descricao)
	{
		this.Descricao = descricao;
	}
	
	public void setAtributosObjeto(String [] linha)
	{
		try
		{
			for (int nrAtributo = 0; nrAtributo < linha.length; nrAtributo++)
			{
				switch (nrAtributo)
				{
					case 0:
					{
						setFase(Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 1:
					{
						setDescricao(linha[nrAtributo]);
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e)
		{
		}

	}

	/** getFase 													<br>
	 * Retorna fase												<br>
	 * @return fase												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public int getFase()
	{
		return this.Fase;
	}
	
	/** getDescricao 													<br>
	 * Retorna descricao												<br>
	 * @return descricao												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getDescricao()
	{
		return this.Descricao;
	}
}

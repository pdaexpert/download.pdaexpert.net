/**
 * Universidade Regional de Chapec� - Unochapec� 	<br>
 * 22/04/2006													<br>
 * TCC															<br>
 * TipoIdentificacao.java									<br>
 **/
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Classe TipoIdentificacao (Brinco, Mossa, etc )					<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class TipoIdentificacao
	implements LogicalInterface
{

	/**
	 * C�digo do Tipo de Identifica��o 
	 */
	protected int							TipoIdentificacao	= 0;
	
	/**
	 * Descrica��o da Identifica��o (Mossa, Brinco, etc)
	 */
	protected String						Descricao			= null;
	
	/**
	 * Construtor Padr�o da Classe 										 <br>
    * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public TipoIdentificacao()
	{
		this(0,"");
	}
	
	/**
	 * Construtor da Classe 														<br>
	 * @param TipoIdentificacao	Codigo do Tipo de Identificacao
	 * @param Descricao				Descricao do Tipo de Identificacao 	<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com 		<br>
	 */
	public TipoIdentificacao(int TipoIdentificacao, String Descricao)
	{
		this.setTipoIdentificacao(TipoIdentificacao);
		this.setDescricao(Descricao);
	}
	
	/** setTipoIdentificacao 													<br>
	 * Valorar o atributo TipoIdentificacao desta classe				<br>
	 * @param tipoIdentificacao 												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setTipoIdentificacao(int tipoIdentificacao)
	{
		this.TipoIdentificacao = tipoIdentificacao;
	}

	/** setDescricao 																<br>
	 * Valorar o atributo Descricao desta classe							<br>
	 * @param descricao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setDescricao(String descricao)
	{
		this.Descricao = descricao;
	}

	public void setAtributosObjeto(String [] linha)
	{
		try
		{
			for (int nrAtributo = 0; nrAtributo < linha.length; nrAtributo++)
			{
				switch (nrAtributo)
				{
					case 0:
					{
						setTipoIdentificacao(Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 1:
					{
						setDescricao(linha[nrAtributo]);
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e)
		{
		}
	}
	
	/** getTipoIdentificacao 													<br>
	 * Retorna tipoIdentificacao												<br>
	 * @return tipoIdentificacao												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public int getTipoIdentificacao()
	{
		return this.TipoIdentificacao;
	}

	/** getDescricao 																<br>
	 * Retorna descricao															<br>
	 * @return descricao															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getDescricao()
	{
		return this.Descricao;
	}

}

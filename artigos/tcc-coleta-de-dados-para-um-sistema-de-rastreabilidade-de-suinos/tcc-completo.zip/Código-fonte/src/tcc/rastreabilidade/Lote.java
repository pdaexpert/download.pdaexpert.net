/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 22/04/2006													<br>
  * TCC															<br>
  * Lote.java													<br>
  **/
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Classe que cont�m a l�gica de gerenciamento da entidade Lote	<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com		<br>
 **/
public class Lote
	implements LogicalInterface
{

	/**
	 * Pocilga � qual o lote pertence
	 */
	protected Pocilga pocilga 	= null;
	
	/**
	 * C�digo do Lote
	 */
	protected int		lote	 	= 0	;
	
	/**
	 *  Construtor Padr�o da Classe 										 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Lote()
	{
		this(new Pocilga(),0);
	}
	
	/**
	 * Construtor da Classe Lote 											 <br>
	 * @param pocilga	Pocilga � qual o Lote Pertence
	 * @param lote 	C�digo do Lote										 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Lote(Pocilga pocilga, int lote)
	{
		this.setPocilga(pocilga);
		this.setLote(lote);
	}
	
	/** setPocilga 																<br>
	 * Valorar o atributo pocilga desta classe							<br>
	 * @param pocilga 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setPocilga(Pocilga pocilga) 
	{
		this.pocilga = pocilga;
	}

	/** setLote 																	<br>
	 * Valorar o atributo lote desta classe								<br>
	 * @param lote 																<br>
	 *	@author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setLote(int lote) 
	{
		this.lote = lote;
	}

	public void setAtributosObjeto(String [] linha)
	{
		try
		{
			Produtor 	produtor 	= null;
			Propriedade propriedade = null;
			for (int nrAtributo = 0; nrAtributo < linha.length; nrAtributo++)
			{
				switch (nrAtributo)
				{
					case 0:
					{
						produtor = new Produtor(linha[nrAtributo],"","","","");
						break;
					}
					case 1:
					{
						propriedade = new Propriedade(produtor,Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 2:
					{
						this.setPocilga(new Pocilga(propriedade,Convert.toInt(linha[nrAtributo])));
						break;
					}
					case 3:
					{
						this.setLote(Convert.toInt(linha[nrAtributo]));
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e)
		{
		}
		
	}
	
	/** getPocilga 																<br>
	 * Retorna pocilga															<br>
	 * @return pocilga															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Pocilga getPocilga()
	{
		return this.pocilga;
	}
	
	/** getLote 													<br>
	 * Retorna lote												<br>
	 * @return lote												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public int getLote()
	{
		return this.lote;
	}
}

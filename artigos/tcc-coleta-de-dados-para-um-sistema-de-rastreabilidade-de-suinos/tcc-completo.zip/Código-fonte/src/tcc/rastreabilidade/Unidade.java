/**
 * Universidade Regional de Chapec� - Unochapec�
 * 19/04/2006
 * TCC
 * Unidade.java
 **/
package tcc.rastreabilidade;

/**
 * Unidade <br>
 * Respons�vel pelo gerenciamento das unidades (Filiais)
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 */
public class Unidade
{

	/**
	 * N�mero da Unidade
	 */
	protected int		Unidade		= 0;

	/**
	 * Nome (Descricao) da Unidade
	 */
	protected String	Descricao	= "";

	/* ========== CONSTRUTORES ============= */
	/**
	 * Construtor da Classe Unidade 
	 * @param Unidade			N�mero da Unidade
	 * @param Descricao		Nome (Descri��o)
	 */
	public Unidade(int Unidade, String Descricao)
	{
		this.setUnidade(Unidade);
		this.setDescricao(Descricao);
	}
	
	/**
	 * Construtor Padr�o da Classe Unidade								 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Unidade()
	{
		this(0,"");
	}
	
	/* ========== METODOS SETS ============= */
	public void setUnidade(int Unidade)
	{
		this.Unidade = Unidade;
	}
	
	/** setDescricao 													<br>
	 * Valorar o atributo Descricao desta classe							<br>
	 * @param descricao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setDescricao(String descricao)
	{
		this.Descricao = descricao;
	}
	
	/* ========== METODOS GETS ============= */
	public int getUnidade()
	{
		return this.Unidade;
	}
	
	public String getDescricao()
	{
		return this.Descricao;
	}
	
}

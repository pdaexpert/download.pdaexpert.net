/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 01/05/2005														<br>
  * TCC											<br>
  * Elemento.java												<br>
  **/
package tcc.rastreabilidade.xml;

import waba.util.Vector;

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Elemento
{
	/**
	 * Atributos do Elemento (Classe Atributo)
	 */
	private Vector Atributos = new Vector();
	
	/**
	 * Conte�do do Elemento (N� de Texto)
	 */
	private String Conteudo     = ""  ;
	
	/**
	 * Nome do Elemento
	 */
	private String Nome         = ""	;
	
	/**
	 * Vers�o do Xml (1.0)
	 */
	private final String Versao = "<?xml version=\"1.0\"?>";
	
	/**
	 * Construtor da Classe Elemento.java <br>
	 * @param Nome			Nome do Elemento
	 * @param Conteudo	Conte�do do Elemento
	 * @param Atributos  Vetor de Atributos do elemento <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Elemento(String Nome, String Conteudo, Vector Atributos)
	{
		setNome(Nome);
		setConteudo(Conteudo);
		setAtributos(Atributos);
	}
	
	/**
	 * Construtor Padr�o da Classe Elemento.java <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public Elemento()
	{
		this("","",new Vector());
	}
	
	
	/** setVecAtributos 													<br>
	 * Valorar o atributo vecAtributos desta classe							<br>
	 * @param vecAtributos 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setAtributos(Vector Atributos)
	{
		this.Atributos = Atributos;
	}
	
	/** setConteudo 													<br>
	 * Valorar o atributo Conteudo desta classe							<br>
	 * @param conteudo 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setConteudo(String conteudo)
	{
		this.Conteudo = conteudo;
	}
	
	/** setNome 													<br>
	 * Valorar o atributo Nome desta classe							<br>
	 * @param nome 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setNome(String nome)
	{
		this.Nome = nome;
	}
	
	/** getVecAtributos 													<br>
	 * Retorna vecAtributos												<br>
	 * @return vecAtributos												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Vector getAtributos()
	{
		return this.Atributos;
	}
	
	/** getConteudo 													<br>
	 * Retorna conteudo												<br>
	 * @return conteudo												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getConteudo()
	{
		return this.Conteudo;
	}
	
	/** getNome 													<br>
	 * Retorna nome												<br>
	 * @return nome												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getNome()
	{
		return this.Nome.toLowerCase();
	}
	
	/** getVersao 													<br>
	 * Retorna versao												<br>
	 * @return versao												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getVersao()
	{
		return this.Versao;
	}
	
	/**
	 *  <b>addAtributo</b> - Adicionar atributo ao vetor de atributos da classe <br>
	 * @param atributo atributo do elemento																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public void addAtributo(Atributo atributo)
	{
		this.Atributos.add(atributo);
	}
	
	/**
	 *  <b>retornaAtributos</b> - Atributos alinhados <br>
	 * @return atributo1="valor1" atributo2="valor2" atributon="valorn"																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public String retornaAtributos()
	{
		String AtributosFormatados = "";
		Atributo atributo = new Atributo();
		
		try
		{
			for (int nrAtributo = 0; nrAtributo < this.getAtributos().getCount(); nrAtributo++)
			{
				atributo = (Atributo)this.getAtributos().items[nrAtributo];
				AtributosFormatados = AtributosFormatados + atributo.retornaNomeValor();
			}
		}
		catch (Exception e) 
		{
		}
		
		return AtributosFormatados;
	}
	
	/**
	 * <b>startElement</b> - Tag de inicializacao do elemento <br>
	 * @return &lt; elemento atributo1=valor1 atributon=valorn &gt;																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public String startElement()
	{
		return   "<"
				 + this.getNome()
				 + " "
				 + this.retornaAtributos()
				 + " "
				 + ">";
	}
	
	/**
	 * <b>endElement</b> - Tag de fechamento do elemento <br>
	 * @return &lt;/elemento&gt;																	 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public String endElement()
	{
		return   "</"
				 + this.getNome()
				 + ">";
				
	}
	
	/**
	 * <b>EmptyElement</b> - Retorna a Tag de um Elemento sem Conte�do <br>
	 *@return &lt;/ elemento atributo1=valor1 atributon=valorn &gt;																 
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public String EmptyElement()
	{
		return   "</"
		 		 + this.getNome()
		 		 + " "
		 		 + this.retornaAtributos()
		 		 + " "
		 		 + ">";	
	}
	
	
	
}

/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 01/05/2005														<br>
  * TCC											<br>
  * Transferencia.java												<br>
  **/
package tcc.rastreabilidade.xml.especificos;

import tcc.dbAcess.Conexao;
import tcc.dbAcess.MortalidadeDescarteDAO;
import tcc.rastreabilidade.MortalidadeDescarte;
import tcc.rastreabilidade.xml.Atributo;
import tcc.rastreabilidade.xml.Elemento;
import waba.sys.Convert;
import waba.util.Date;
import waba.util.Vector;


/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class Transferencia
	extends Elemento
{
	/**
	 * Tabelas que ser�o exportadas
	 */
	private Vector Tabelas = null;
	
	/**
	 * Nome do Elemento "transferencia"
	 */
	private static final String NOME = "transferencia";
	
	/**
	 * Nome do Atributo Id  = "id"
	 */
	private static final String ID = "id";
	
	/**
	 * Atributo ID (Data da Transferencia)
	 */
	private Atributo Id = null;
	
	/**
	 * Buffer que ir� guardar as tags XML
	 */
	private Vector buffer = null;
	
	public Transferencia(Date data)
	{
		super();
		setNome(NOME); //nome
		setId(new Atributo(ID,Convert.toString(data.getDateInt())));
		addAtributo(getId());
		construirTags();
	}
	
	/** setId 													<br>
	 * Valorar o atributo Id desta classe							<br>
	 * @param id 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setId(Atributo id)
	{
		this.Id = id;
	}
	
	/** getId 													<br>
	 * Retorna id												<br>
	 * @return id												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Atributo getId()
	{
		return this.Id;
	}
	
	/** getBuffer 													<br>
	 * Retorna buffer												<br>
	 * @return buffer												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Vector getBuffer()
	{
		return this.buffer;
	}
	
	public void construirTags()
	{
		buffer					= new Vector();
		Tabelas 			 		= new Vector();
		Conexao 	conexao 		= new Conexao();
		Tabela  	tabelaAux 	= null;
		Linha 	linhaAux 	= null;
		Coluna 	colunaAux 	= null;
		
		/*
		 * Exportar a Tabela TxMorteDescarte
		 */

		conexao.ConexaoDb2e();
		MortalidadeDescarteDAO m = new MortalidadeDescarteDAO(conexao,new MortalidadeDescarte());
		m.setWhere("");
		tabelaAux = new Tabela(m);
		conexao.FecharConexao();
		Tabelas.add(tabelaAux);
		
		buffer.add(  getVersao()  		
					  + novaLinha());
		buffer.add(startElement());
		buffer.add(   getConteudo() 
						+ novaLinha());
		
		for (int nrTabelas = 0; nrTabelas < Tabelas.getCount(); nrTabelas++)
		{
			tabelaAux = (Tabela)Tabelas.items[nrTabelas];
			buffer.add(  tabulacao() 
						  + tabelaAux.startElement());
			buffer.add(  tabelaAux.getConteudo() 
						  + novaLinha());
						
			for (int nrLinhas = 0; nrLinhas < tabelaAux.getLinhas().getCount(); nrLinhas++)
			{
				linhaAux = (Linha) tabelaAux.getLinhas().items[nrLinhas];
				buffer.add(  tabulacao() 
						     + tabulacao() 	
						     + linhaAux.startElement());
				buffer.add(  linhaAux.getConteudo()		
							  + novaLinha());
				for (int nrColunas = 0; nrColunas < linhaAux.getColunas().getCount(); nrColunas++)
				{
					colunaAux = (Coluna) linhaAux.getColunas().items[nrColunas];
					buffer.add(  tabulacao() 
								  + tabulacao() 	
								  + tabulacao() 
								  + colunaAux.startElement());
					buffer.add(colunaAux.getConteudo());
					buffer.add(  colunaAux.endElement() 		
								  + novaLinha());
				}
				buffer.add(  tabulacao() 
						     + tabulacao() 
						     + linhaAux.endElement() 
						     + novaLinha());
			}		
			buffer.add(  tabulacao() 
					     + tabelaAux.endElement()	
					     + novaLinha());
		}
		
		buffer.add(  endElement()	
					  + novaLinha());
		
	}

	protected String novaLinha()
	{
		return "\n";
	}
	
	protected String tabulacao()
	{
		return "\t";
	}
	
}

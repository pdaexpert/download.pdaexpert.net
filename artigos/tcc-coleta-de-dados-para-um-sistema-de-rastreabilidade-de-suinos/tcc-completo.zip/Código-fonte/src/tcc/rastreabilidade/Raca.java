/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 22/04/2006 <br>
 * TCC <br>
 * Raca.java <br>
 */
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Raca do Animal <br>
 * 
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class Raca
	implements LogicalInterface
{

	/**
	 * Codigo da Ra�a
	 */
	protected int							Raca			= 0;
	
	/**
	 * Descri��o da Ra�a
	 */
	protected String						Descricao	= null;
	

	/**
 	*  Construtor Padr�o da Classe Raca <br>
 	* @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 	*/
	public Raca()
	{
		this(0,"");
	}
	
	/**
	 * Construtor da Classe Ra�a											 <br>
	 * @param Raca			C�digo da Ra�a
	 * @param Descricao 	Descri��o da Ra�a 							 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Raca(int Raca, String Descricao)
	{
		this.setRaca(Raca);
		this.setDescricao(Descricao);
	}
	
	/** setRaca 																	<br>
	 * Valorar o atributo Raca desta classe								<br>
	 * @param raca 																<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setRaca(int raca)
	{
		this.Raca = raca;
	}
	
	/** setDescricao 																<br>
	 * Valorar o atributo Descricao desta classe							<br>
	 * @param descricao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setDescricao(String descricao)
	{
		this.Descricao = descricao;
	}
	
	public void setAtributosObjeto(String [] linha)
	{
		try
		{
			for (int nrAtributo = 0; nrAtributo < linha.length; nrAtributo++)
			{
				switch (nrAtributo)
				{
					case 0:
					{
						setRaca(Convert.toInt(linha[nrAtributo]));
						break;
					}
					case 1:
					{
						setDescricao(linha[nrAtributo]);
						break;
					}
					default:
						break;
				}
			}
		}
		catch (Exception e)
		{
		}
	}

	/** getRaca 																	<br>
	 * Retorna raca																<br>
	 * @return raca																<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public int getRaca()
	{
		return this.Raca;
	}
	
	/** getDescricao 																<br>
	 * Retorna descricao															<br>
	 * @return descricao															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String getDescricao()
	{
		return this.Descricao;
	}
}

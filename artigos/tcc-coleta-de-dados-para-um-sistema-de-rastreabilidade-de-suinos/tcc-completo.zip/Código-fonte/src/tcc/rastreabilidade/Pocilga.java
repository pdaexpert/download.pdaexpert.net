/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 21/04/2006														<br>
  * TCC											<br>
  * Pocilga.java												<br>
  **/
package tcc.rastreabilidade;

import waba.sys.Convert;

/**
 * Classe com a L�gica de Neg�cio para Controle da Entidade Pocilga	<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com			<br>
 **/
public class Pocilga
	implements LogicalInterface
{
	/**
	 * Propriedade a qual a Pocilga Pertente
	 */
	protected Propriedade propriedade = null;
	
	/**
	 * C�digo da Pocilga
	 */
	protected int			 pocilga		 = 0 	 ;
	
	
	/**
	 *	Construtor da classe Pocilga 
	 * @param propriedade Propriedade a qual a Pocilga pertente
	 * @param pocilga		 Codigo da Pocilga							 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Pocilga(Propriedade propriedade, int pocilga)
	{
		this.setPropriedade(propriedade);
		this.setPocilga(pocilga);
	}
	
	/**
	 * Construtor Padr�o da Classe Pocilga (Valores Nulos)		 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public Pocilga()
	{
		this(new Propriedade(),0);
	}
	
	/** setPropriedade 															<br>
	  * Valorar o atributo propriedade desta classe						<br>
	  * @param propriedade 	Propriedade a qual a Pocilga Pertence	<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  **/
	public void setPropriedade(Propriedade propriedade)
	{
		this.propriedade = propriedade;
	}

	/** setPocilga 																<br>
	  * Valorar o atributo pocilga desta classe							<br>
	  * @param pocilga 	codigo da pocilga									<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  **/
	public void setPocilga(int pocilga) 
	{
		this.pocilga = pocilga;
	}

	public void setAtributosObjeto(String [] linha)
	{
		Produtor 	prod 	= new Produtor();
		Propriedade prop 	= new Propriedade();
		try
		{
		for (int nrColuna = 0; nrColuna < linha.length; nrColuna++)
		{
			switch (nrColuna)
			{
				case 0:
				{
					prod.setCgcCpf(linha[nrColuna]);
					break;
				}
				case 1:
				{
					prop.setProdutor(prod);
					prop.setPropriedade(Convert.toInt(linha[nrColuna]));
					break;
				}
				case 2:
				{
					this.setPropriedade(prop);
					this.setPocilga(Convert.toInt(linha[nrColuna]));
					break;
				}
				default:
					break;
			}
		}
		}
		catch (Exception e) 
		{
		}

	}
	
	/** getPropriedade 															<br>
	 * Retorna propriedade														<br>
	 * @return propriedade	Propriedade a qual a pocilga pertence	<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Propriedade getPropriedade()
	{
		return propriedade;
	}

	/** getPocilga 													<br>
	  * Retorna pocilga												<br>
	  * @return pocilga	codigo da pocilga						<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  */
	public int getPocilga()
	{
		return this.pocilga;
	}
}

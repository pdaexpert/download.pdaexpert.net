/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 02/05/2006 <br>
 * TCC <br>
 * CustomType.java <br>
 */
package tcc.superwaba.custom.sql;

/**
 * Extende Fun��es da Classe superwaba.ext.xplat.sql.Types <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 */
public class CustomSqlType
{
	public static final int	BIT				= -7;
	public static final int	TINYINT			= -6;
	public static final int	SMALLINT			= 5;
	public static final int	INTEGER			= 4;
	public static final int	BIGINT			= -5;
	public static final int	FLOAT				= 6;
	public static final int	REAL				= 7;
	public static final int	DOUBLE			= 8;
	public static final int	NUMERIC			= 2;
	public static final int	DECIMAL			= 3;
	public static final int	CHAR				= 1;
	public static final int	VARCHAR			= 12;
	public static final int	LONGVARCHAR		= -1;
	public static final int	DATE				= 91;
	public static final int	TIME				= 92;
	public static final int	TIMESTAMP		= 93;
	public static final int	BINARY			= -2;
	public static final int	VARBINARY		= -3;
	public static final int	LONGVARBINARY	= -4;
	public static final int	NULL				= 0;
	public static final int	OTHER				= 1111;
	public static final int	JAVA_OBJECT		= 2000;
	public static final int	DISTINCT			= 2001;
	public static final int	STRUCT			= 2002;
	public static final int	ARRAY				= 2003;
	public static final int	BLOB				= 2004;
	public static final int	CLOB				= 2005;
	public static final int	REF				= 2006;
	public static final int	DATALINK			= 70;
	public static final int	BOOLEAN			= 16;

	public static String getTypeName(int Type)
	{
		String TypeName = "";

		switch (Type)
		{
			case -7:
				TypeName = "BIT";
				break;
			case -6:
				TypeName = "TINYINT";
				break;
			case 5:
				TypeName = "SMALLINT";
				break;
			case 4:
				TypeName = "INTEGER";
				break;
			case -5:
				TypeName = "BIGINT";
				break;
			case 6:
				TypeName = "FLOAT";
				break;
			case 7:
				TypeName = "REAL";
				break;
			case 8:
				TypeName = "DOUBLE";
				break;
			case 2:
				TypeName = "NUMERIC";
				break;
			case 3:
				TypeName = "DECIMAL";
				break;
			case 1:
				TypeName = "CHAR";
				break;
			case 12:
				TypeName = "VARCHAR";
				break;
			case -1:
				TypeName = "LONGVARCHAR";
				break;
			case 91:
				TypeName = "DATE";
				break;
			case 92:
				TypeName = "TIME";
				break;
			case 93:
				TypeName = "TIMESTAMP";
				break;
			case -2:
				TypeName = "BINARY";
				break;
			case -3:
				TypeName = "VARBINARY";
				break;
			case -4:
				TypeName = "LONGVARBINARY";
				break;
			case 0:
				TypeName = "NULL";
				break;
			case 1111:
				TypeName = "OTHER";
				break;
			case 2000:
				TypeName = "JAVA_OBJECT";
				break;
			case 2001:
				TypeName = "DISTINCT";
				break;
			case 2002:
				TypeName = "STRUCT";
				break;
			case 2003:
				TypeName = "ARRAY";
				break;
			case 2004:
				TypeName = "BLOB";
				break;
			case 2005:
				TypeName = "CLOB";
				break;
			case 2006:
				TypeName = "REF";
				break;
			case 70:
				TypeName = "DATALINK";
				break;
			case 16:
				TypeName = "BOOLEAN";
				break;
			default:
				break;
		}

		return TypeName.toLowerCase();
	}

}

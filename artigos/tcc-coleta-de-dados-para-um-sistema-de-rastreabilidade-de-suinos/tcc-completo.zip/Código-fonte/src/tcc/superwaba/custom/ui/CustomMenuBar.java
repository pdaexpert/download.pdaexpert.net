/**
 * Universidade Regional de Chapec� - Unochapec�
 * 03/04/2006
 * TCC
 * CustomMenuBar.java
 **/
package tcc.superwaba.custom.ui;

/**
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com
 * <br>
 * Especializa��o da Classe waba.ui.MenuBar, com alguns m�todos adicionais.
 * <br>
 * @version 1.0
 */
public class CustomMenuBar
	extends waba.ui.MenuBar
{
	/**
	 * Array de Strings, que ir�o compor o menuBar
	 */
	protected String[][] ItensMenu;

	/**
	 * CustomMenuBar - Construtor Sem Modifica��es
	 * @param items itens que ir�o compor o MenuBar
	 * @see waba.ui.MenuBar
	 */
	public CustomMenuBar(String [][] items)
	{
		super(items);
		setItensMenu(items);		
	}
	
	/** setItensMenu 													<br>
	 * Valorar o atributo ItensMenu desta classe							<br>
	 * @param itensMenu 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setItensMenu(String [][] itensMenu)
	{
		ItensMenu = itensMenu;
	}
	
	/** getItensMenu 													<br>
	 * Retorna itensMenu												<br>
	 * @return itensMenu												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public String [][] getItensMenu()
	{
		return this.ItensMenu;
	}
	
	/**
	 * Retorna a Coluna do Menu Item Selecionado
	 * @param menuItemSelected
	 * @return int
	 */
	public int getColSelected(int menuItemSelected)
	{
		int iColSelected = menuItemSelected / 100;
		return iColSelected;
	}
  
	/**
	 * Retorna a Linha do Menu Item Selecionado
	 * @param menuItemSelected
	 * @return
	 */
	public int getRowSelected(int menuItemSelected)
	{
		int iRowSelected = menuItemSelected % 100;
		return iRowSelected;
	}

	/**
	 * Return the menuItemSelected Caption
	 * @param menuItemSelected
	 * @return
	 */
	public String getMenuItemCaption(int menuItemSelected)
	{
		String strRetorno = null;
		try
		{
			if (   (this.getColSelected(menuItemSelected) >= 0)
				 && (this.getRowSelected(menuItemSelected) >= 0))
			{
				strRetorno = getItensMenu()[this.getColSelected(menuItemSelected)]
				                           [this.getRowSelected(menuItemSelected)];
			}
		}
		catch (Exception e) 
		{
		}
		return strRetorno;
	}

	/**
	 * Return the menuBarCaption of menuItemSelected Col
	 * @param menuItemSelected
	 * @return
	 */
	public String getMenuBarCaption(int menuItemSelected)
	{
		String strRetorno = null;

		try
		{
			strRetorno = getItensMenu()[this.getColSelected(menuItemSelected)][0];
		}
		catch (Exception e)
		{
			// TODO: handle exception
		}

		return strRetorno;
	}

}

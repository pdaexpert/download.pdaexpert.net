/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * PocilgaDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.Pocilga;

/**
 * Classe de acesso � dados de um Banco de Dados <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class PocilgaDAO
	extends DAO
{

	/**
	 * Objeto que cont�m as informa��es que ser�o inseridas ou consultadas
	 * no banco de dados
	 */
	private Pocilga pocilga = null;
	
	/**
	 * Tabela que ser� acessada pela classe
	 */
	private static final String 	TABELA = "pocilga";
	
	/**
	 * Campos que ser�o acessados pela classe
	 */
	private static final String[]	CAMPOS = {"cgccpf"	, 
														 "propriedade", 
														 "pocilga" };
	
	
	/** Construtor da Classe PocilgaDAO.java <br>
	 *  <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 **/
	public PocilgaDAO(Conexao conexao, Pocilga pocilga)
	{
		super(conexao,TABELA,CAMPOS);
		setPocilga(pocilga);
	}
	
	
	/** getPocilga 													<br>
	 * Retorna pocilga												<br>
	 * @return pocilga												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Pocilga getPocilga()
	{
		return this.pocilga;
	}

	/** setPocilga 													<br>
	  * Valorar o atributo pocilga desta classe							<br>
	  * @param pocilga 															<br>
	  * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	  **/
	public void setPocilga(Pocilga pocilga) 
	{
		this.pocilga = pocilga;
	}
	

	protected void Integridade()
	{
		setWhere(    " where " + TABELA + "." + CAMPOS[0] + " = '" + getPocilga().getPropriedade().getProdutor().getCgcCpf() + "'"
				     + "   and " + TABELA + "." + CAMPOS[1] + " =  " + getPocilga().getPropriedade().getPropriedade()         
				     + "   and " + TABELA + "." + CAMPOS[2] + " =  " + getPocilga().getPocilga()           							);
		

	}

	protected void Selecao()
	{
		setWhere(    " where " + TABELA + "." + CAMPOS[0] + " = '" + getPocilga().getPropriedade().getProdutor().getCgcCpf() + "'"
			        + "   and " + TABELA + "." + CAMPOS[1] + " =  " + getPocilga().getPropriedade().getPropriedade()        );
	}

	protected String [] returnValores()
	{
		return new String[] {"'" + this.getPocilga().getPropriedade().getProdutor().getCgcCpf() + "'" ,
				               ""  + this.getPocilga().getPropriedade().getPropriedade()          + ""  ,
				               ""  + this.getPocilga().getPocilga()										 + ""  };
	}

}

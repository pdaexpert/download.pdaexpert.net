/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * MortalidadeDescarteDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.MortalidadeDescarte;
import waba.sys.Convert;
import waba.sys.Vm;

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class MortalidadeDescarteDAO
	extends DAO
{

	/**
	 * Objeto com as informa��es
	 */
	MortalidadeDescarte mortalidadeDescarte = null;
	
	/**
	 * Tabela que ser� acessada
	 */
	public static final String 	TABELA = "txmortedescarte";
	
	/**
	 * Campos que ser�o acessados
	 */
	public static final String[] 	CAMPOS = {"CgcCpf"			  , 
 														 "Propriedade"		  ,
	                                        "Pocilga"			  ,
	                                        "Lote"				  ,
	                                        "Sequencia"		  ,
	                                        "CodigoCausa"		  ,
	                                        "DataLcto"			  ,
	                                        "DtMorteDescarte"  ,
	                                        "PesoEstimado" 	  };
	
	/**
	 *  Construtor da Classe MortalidadeDescarteDAO.java <br>
	 * @param conexao							Conex�o com o banco de dados
	 * @param mortalidadeDescarteNovo	Objeto com as novas informa��es 
	 * @param mortalidadeDescarteAntigo Objeto com as informa��es antigas (integridade)	<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public MortalidadeDescarteDAO(Conexao conexao, 
	                              MortalidadeDescarte mortalidadeDescarte)
	{
		super(conexao,TABELA,CAMPOS);
		setMortalidadeDescarte(mortalidadeDescarte);
	}
	
	/** setMortalidadeDescarte 													<br>
	 * Valorar o atributo mortalidadeDescarte desta classe							<br>
	 * @param mortalidadeDescarte 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setMortalidadeDescarte(MortalidadeDescarte mortalidadeDescarte)
	{
		this.mortalidadeDescarte = mortalidadeDescarte;
	}
	
	/** getMortalidadeDescarte 													<br>
	 * Retorna mortalidadeDescarte												<br>
	 * @return mortalidadeDescarte												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public MortalidadeDescarte getMortalidadeDescarte()
	{
		return this.mortalidadeDescarte;
	}
	
	protected void Integridade()
	{
		setWhere(  " where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]
               + "   and " + TABELA + "." + CAMPOS[1] + " = " + returnValores()[1]
               + "   and " + TABELA + "." + CAMPOS[2] + " = " + returnValores()[2] 
               + "   and " + TABELA + "." + CAMPOS[3] + " = " + returnValores()[3]
               + "   and " + TABELA + "." + CAMPOS[4] + " = " + returnValores()[4]);
		Vm.debug(getWhere());
	}

	protected void Selecao()
	{
		setWhere(  " where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]
               + "   and " + TABELA + "." + CAMPOS[1] + " = " + returnValores()[1]
	            + "   and " + TABELA + "." + CAMPOS[2] + " = " + returnValores()[2] 
	            + "   and " + TABELA + "." + CAMPOS[3] + " = " + returnValores()[3]
	            + "   and " + TABELA + "." + CAMPOS[4] + " = " + returnValores()[4]);
	}

	protected String [] returnValores()
	{
		return new String[]
             {
				  "'" + getMortalidadeDescarte().getSuino().getLote().getPocilga().getPropriedade().getProdutor().getCgcCpf().trim() + "'",
				  " " + getMortalidadeDescarte().getSuino().getLote().getPocilga().getPropriedade().getPropriedade() 						+ " ",
				  " " + getMortalidadeDescarte().getSuino().getLote().getPocilga().getPocilga() 													+ " ",
				  " " + getMortalidadeDescarte().getSuino().getLote().getLote() 																		+ " ",
				  " " + getMortalidadeDescarte().getSuino().getSequencia() 																				+ " ",
				  " " + getMortalidadeDescarte().getCausa().getCodigoCausa() 																			+ " ",
				  "'" + getMortalidadeDescarte().getDataLcto().getDate()  																				+ "'",
				  "'" + getMortalidadeDescarte().getDataMorteDescarte().getDate()     																+ "'",
				  " " + Convert.toString(getMortalidadeDescarte().getPesoEstimado(),2)																+ " "
             };
	}

}

/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * SuinoDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.Suino;

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class SuinoDAO
	extends DAO
{

	Suino suino = null;
	
	/**
	 * Tabela que ser� acessada pela classe
	 */
	protected static final String		TABELA		= "suino";
	
	/**
	 * Campos que ser�o acessados pela classe
	 */
	protected static final String []	CAMPOS		=
																{  "cgccpf", 
																	"propriedade",
																	"pocilga", 
																	"lote",
																	"sequencia", 
																	"tipoidentificacao",
																	"fase", 
																	"raca", 
																	"sexo"};
	
	/**
	 *  Construtor da Classe SuinoDAO.java <br>
	 * @param conexao
	 * @param suino <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public SuinoDAO(Conexao conexao, Suino suino)
	{
		super(conexao, TABELA, CAMPOS);
		setSuino(suino);
	}
	
	/** setSuino 													<br>
	 * Valorar o atributo suino desta classe							<br>
	 * @param suino 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setSuino(Suino suino)
	{
		this.suino = suino;
	}
	
	/** getSuino 													<br>
	 * Retorna suino												<br>
	 * @return suino												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public Suino getSuino()
	{
		return this.suino;
	}
	
	protected void Integridade()
	{
		setWhere(  " where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]
					+ "   and " + TABELA + "." + CAMPOS[1] + " = " + returnValores()[1]
               + "   and " + TABELA + "." + CAMPOS[2] + " = " + returnValores()[2]
               + "   and " + TABELA + "." + CAMPOS[3] + " = " + returnValores()[3]
               + "   and " + TABELA + "." + CAMPOS[4] + " = " + returnValores()[4]);
	}

	protected void Selecao()
	{
		setWhere(  " where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]
               + "   and " + TABELA + "." + CAMPOS[1] + " = " + returnValores()[1]
		         + "   and " + TABELA + "." + CAMPOS[2] + " = " + returnValores()[2]
		         + "   and " + TABELA + "." + CAMPOS[3] + " = " + returnValores()[3]);
	}

	protected String [] returnValores()
	{
		return new String[] 
             {"'" + getSuino().getLote().getPocilga().getPropriedade().getProdutor().getCgcCpf() 	+ "'",
				  " " + getSuino().getLote().getPocilga().getPropriedade().getPropriedade() 				+ "" ,
				  " " + getSuino().getLote().getPocilga().getPocilga()											+ "" ,
				  " " + getSuino().getLote().getLote()																	+ "" ,
				  " " + getSuino().getSequencia() 																		+ "" ,
				  " " + getSuino().getTipoidentificacao().getTipoIdentificacao()								+ "" ,
				  " " + getSuino().getFase().getFase()																	+ "" ,
				  " " + getSuino().getRaca().getRaca()																	+ "" ,
				  "'" + getSuino().getSequencia()																		+ "'",};
	}

}

/**
  * Universidade Regional de Chapec� - Unochapec� 	<br>
  * 26/04/2006														<br>
  * TCC											<br>
  * TipoIdentificacaoDAO.java												<br>
  **/
package tcc.dbAcess;

import tcc.rastreabilidade.TipoIdentificacao;

/**
 * 																		<br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
 **/
public class TipoIdentificacaoDAO
	extends DAO
{

	/**
	 * Objeto que cont�m as informa��es
	 */
	
	TipoIdentificacao tipoidentificacao = null;
	
	/**
	 * Tabela que ser� acessada pela classe
	 */
	protected static final String		TABELA				= "tipoidentificacao";
	
	/**
	 *  Campos que ser�o acessados pela classe 
	 */
	protected static final String []	CAMPOS				=
																		{ "tipoidentificacao",
																		  "descricao"			};

	/**
	 *  Construtor da Classe TipoIdentificacaoDAO.java <br>
	 * @param conexao
	 * @param tipoidentificacao <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 *
	 */
	public TipoIdentificacaoDAO(Conexao conexao, TipoIdentificacao tipoidentificacao)
	{
		super(conexao,TABELA,CAMPOS);
		setTipoidentificacao(tipoidentificacao);
	}
	
	/** setTipoidentificacao 													<br>
	 * Valorar o atributo tipoidentificacao desta classe							<br>
	 * @param tipoidentificacao 															<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 **/
	public void setTipoidentificacao(TipoIdentificacao tipoidentificacao)
	{
		this.tipoidentificacao = tipoidentificacao;
	}
	
	/** getTipoidentificacao 													<br>
	 * Retorna tipoidentificacao												<br>
	 * @return tipoidentificacao												<br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com	<br>
	 */
	public TipoIdentificacao getTipoidentificacao()
	{
		return this.tipoidentificacao;
	}
	
	protected void Integridade()
	{
		setWhere(" where " + TABELA + "." + CAMPOS[0] + " = " + returnValores()[0]);
	}
	
	protected void Selecao()
	{
		setWhere(" ");
	}

	/* (non-Javadoc)
	 * @see tcc.dbAcess.DAO#returnValores()
	 */
	protected String [] returnValores()
	{
		return new String[] {"  " + getTipoidentificacao().getTipoIdentificacao() + " ",
									" '" + getTipoidentificacao().getDescricao() 		  + "'"};
	}

}

/**
 * Universidade Regional de Chapec� - Unochapec� <br>
 * 26/04/2006 <br>
 * TCC <br>
 * ClausulaSQL.java <br>
 */
package tcc.dbAcess;

/**
 * Gera Clausulas SQLs <br>
 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
 *         <br>
 *         Adapta��o da classe clausulas_sql.class.php <br>
 *         Alfred Reinold Baudisch <br>
 *         alfred_baudisch@hotmail.com
 */
public final class ClausulaSQL
{

	/**
	 * <b>GerarInsert</b> - Gera Clausula de Inser��o de Dados <br>
	 * 
	 * @param tabela tabela que ser� utilizada na inser��o
	 * @param campos matriz com os campos da tabela
	 * @param valores matriz com os valores que ser�o inseridos na tabela
	 * @return Clausula SQL formatada <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public static String GerarInsert(String tabela, String [] campos, String [] valores)
	{
		String clausulaSQL = "";
		
		try
		{
			int qtdCampos 	= campos.length;
			clausulaSQL 	= "INSERT INTO " + tabela + " (";

			for (int nrCampos = 0; nrCampos < qtdCampos; nrCampos++)
			{
				clausulaSQL = clausulaSQL + campos[nrCampos];
				if (nrCampos < (qtdCampos - 1))
				{
					clausulaSQL = clausulaSQL + ", ";
				}
			}

			clausulaSQL = clausulaSQL + ") VALUES (";
			
			for (int nrValores = 0; nrValores < qtdCampos; nrValores++)
			{
				clausulaSQL = clausulaSQL
						+ valores[nrValores];
				if (nrValores < (qtdCampos - 1))
				{
					clausulaSQL = clausulaSQL + ", ";
				}
			}
			
			clausulaSQL = clausulaSQL + ")";
			
		}
		catch (NullPointerException ex)
		{
			clausulaSQL = " ";
		}

		return clausulaSQL;
		
	}

	/**
	 * <b>GerarUpdate</b> - Gerar clausula SQL para atualiza��o <br>
	 * 
	 * @param tabela tabela que ser� atualizada
	 * @param campos matriz com os campos a serem atualizados
	 * @param valores matriz com os valores a serem inseridos no campo
	 * @param where condi��o de localiza��o de registros (integridade)
	 * @return Clausula de atualiza��o organizada <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public static String GerarUpdate(String tabela, String [] campos,
										String [] valores, String where)
	{

		String clausulaSQL = "";
		try
		{
			int qtdCampos = campos.length;

			clausulaSQL = "UPDATE "
					+ tabela
					+ " SET ";

			for (int nrCampos = 0; nrCampos < qtdCampos; nrCampos++)
			{
				clausulaSQL = clausulaSQL
						+ campos[nrCampos]
						+ " = "
						+ valores[nrCampos]
						+ " ";
				if (nrCampos < (qtdCampos - 1))
				{
					clausulaSQL = clausulaSQL + ", ";
				}
			}
			clausulaSQL = clausulaSQL
					+ where;
		}
		catch (NullPointerException ex)
		{
			clausulaSQL = " ";
		}

		return clausulaSQL.toUpperCase();

	}

	public static String GerarDelete(String Tabela, String Where)
	{
		String SQL = "";
		try
		{
			SQL = "DELETE FROM "
					+ Tabela
					+ " "
					+ Where;
		}
		catch (NullPointerException e)
		{
			SQL = " ";
		}
		return SQL.toUpperCase();
	}

	/**
	 *  <b>GerarSelect</b> - Gerar clausula SQL para sele��o de dados <br>
	 * @param Tabela	tabela que ter� os dados selecionados
	 * @param Campos	campos que ser�o selecionados
	 * @param Where	clausula where de sele��o
	 * @return	Clausula de Sele��o Organizada						 <br>
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com <br>
	 */
	public static String GerarSelect(String Tabela, String [] Campos, String Where)
	{
		String clausulaSQL = "";
		try
		{
			int qtdCampos = Campos.length;

			for (int nrCampos = 0; nrCampos < qtdCampos; nrCampos++)
				{
					clausulaSQL = clausulaSQL + Campos[nrCampos];
				
					if ((nrCampos             < (qtdCampos - 1)) && 
						 (clausulaSQL.length() > 0              )    )
					{
						clausulaSQL = clausulaSQL + ", ";
					}
				}
						
			if (clausulaSQL.length() == 0 )
			{
				clausulaSQL = " * ";
			}
			
			clausulaSQL  =   "SELECT "
				            + clausulaSQL
				            + " FROM "
								+ Tabela 
								+ " " 
								+ Where;
		}
		catch (NullPointerException e)
		{
			clausulaSQL = " ";
		}
		return clausulaSQL.toUpperCase();

	}
}
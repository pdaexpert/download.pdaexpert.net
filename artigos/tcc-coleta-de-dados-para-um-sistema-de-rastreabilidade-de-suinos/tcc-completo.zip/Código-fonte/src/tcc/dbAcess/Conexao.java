package tcc.dbAcess;

import superwaba.ext.xplat.sql.Connection;
import superwaba.ext.xplat.sql.DriverManager;
import superwaba.ext.xplat.sql.SQLException;
import tcc.superwaba.custom.ui.Mensagem;

/**
 * Classe que faz a conex�o com bancos de dados.
 * 
 * @author Artur de Paula Ribeiro
 * 
 */
public class Conexao
{

	/**
	 * Driver de Conex�o com o Db2E (superwaba.ext.xplat.sql.db2e.Driver)
	 */
	protected static String			DRIVER	= "superwaba.ext.xplat.sql.db2e.Driver";

	/**
	 * Endereco do Servidor (wdbc:db2e:server)
	 */
	protected static String			URL		= "wdbc:db2e:server";

	protected Connection	CONEXAO;

	
	public Conexao()
	{
		//this.ConexaoDb2e();
	}
	
	
	/**
	 * M�todo que cria conexao com o banco de dados Db2Everyplace
	 * 
	 * @author Rafael Rodrigo de Oliveira Alves - Squadra Tecnologia
	 * 
	 */
	public void ConexaoDb2e()
	{

		try
		{
			Class.forName(DRIVER);
		}
		catch (ClassNotFoundException e)
		{
			new Mensagem("Erro - dbAcess.Conexao 1", 
							 "Erro: ".concat(e.getMessage())).popupBlockingModal();
		}

		try
		{
			this.CONEXAO = DriverManager.getConnection(URL);
		}
		catch (SQLException e)
		{
			new Mensagem("Erro - dbAcess.Conexao 2", 
					       "Erro: ".concat(e.getMessage())).popupBlockingModal();
		}
	}

	/**
	 * getConexao Retorna o Objeto Conex�o desta Classe
	 * @author Junior Dal Pr� - [HuRrIcAnE] - jrdalpra@gmail.com 
	 * @return Db2eConnection
	 */
	public Connection getConexao()
	{
		return this.CONEXAO;
	}
	
	public void FecharConexao()
	{
		try
		{
			this.CONEXAO.close();
		}
		catch(SQLException e)
		{
			new Mensagem("Erro dbAcess.Conexao 3",
							 "Erro: ".concat(e.getMessage())).popupBlockingModal();
		}
		
	}
}

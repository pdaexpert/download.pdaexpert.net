Niko
============

  Version 1.1 - May 2004

  NekoCat is a GPL game developed by Dex
       Web Site = http://www.geocities.com/dexhm/
       e-Mail   = dexhm2@hotmail.com

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Overview
--------

Niko begs with you he knows words you cannot find before he'll escape from the garden maze.

The game is very similar to the "hunchback" logic, but you've to be a little lucky too.

At the moment it is available only in Italian, more languages can be supported.
If you want, you can take the sources and modify it at your own pleasure.

In the "Opzioni" form you can control the way words are choosen.


How to install Niko?
-----------------------

Minimum Palm OS requirement is version 3.5.
However only the first release is compatible with < 5.0 device.
All following versions need a coloured PalmOS 5 device.
No test has been integrated so take care of it.

Niko is a composed by a PRC file (the application) and a PDB file (the Dictionary).
Both of them can be installed as a common Palm files:
- Extract from the ZIP
- Double click to transfer on your PDA with HotSync Manager
- Press the hotSync button on your cradle (with PDA inserted ;-))
- Play

IMPORTANT NOTICE:
  Uninstall any previous version of Niko before installing this one on your device.


Handheld Basic ++
----
Niko has been written and compiled with Handheld Basic (HB++) that you can download form http://www.handheld-basic.com

Source code of Niko is available for download on my Web Site.

Donate...
---------

Niko is free to use. However, if you like it, please consider making a donation to show your support. See my web site on how to send donation with Paypal.

History
-------

  1.1 (21/05/04)
    - added sound feature to Niko (thanks to Eric Quagliozzi)
    - source completely reorganized in different classes
  1.0 (01/05/04)
    - initial release
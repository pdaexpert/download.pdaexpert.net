YARP
============

  Version 1.0 - September 2004

  YARP is a GPL game developed by Dex
       Web Site = http://www.geocities.com/dexhm/
       e-Mail   = dexhm2@hotmail.com

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

Overview
--------

YARP stand for Yet Another Rpg for Palm and it is a complete environment for creating a RPG game on your Palm.

Create the location with Scenario Editor, then place the heroes of the 2 teams with the Event Editor, than make your world living using the Engine.
In any case you can read the User guide with the description of the basic functions.

At the moment it is available only in Italian, more languages will be supported.
If you want, you can take the sources and modify it at your own pleasure.



How to install YARP?
-----------------------

Minimum Palm OS requirement is version 5.0
No test has been integrated so take care of it.

YARP is a composed by 3 PRC file (2 editors and the Engine).
All of them can be installed as a common Palm files:
- Extract from the ZIP
- Double click to transfer on your PDA with HotSync Manager
- Press the hotSync button on your cradle (with PDA inserted ;-))
- Play

IMPORTANT NOTICE:
  Uninstall any previous version of the application before installing this one on your device.


Handheld Basic ++
----
YARP has been written and compiled with Handheld Basic (HB++) that you can download form http://www.handheld-basic.com

Source code of YARP is available for download on my Web Site.

Donate...
---------

YARP is free to use. However, if you like it, please consider making a donation to show your support. Send me an email to have instruction to make a donation with Paypal.

History
-------

  1.0 (10/09/04)
    - initial release
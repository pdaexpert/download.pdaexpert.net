import waba.ui.Button;
import waba.ui.ControlEvent;
import waba.ui.Event;
import waba.ui.Label;
import waba.ui.MainWindow;
	
public class OlaMundoSW extends MainWindow {

	private Label  lblOla   = null;
	private Button btnClose = null;
	
	
	public OlaMundoSW()
	{
		// Executa o construtor da classe MainWindow (super classe)
		super();
	}
	
	public void onStart() 
	{
		// Executa o m�todo onStart da classe base (super classe)
		super.onStart();
		
		// Cria um objeto do tipo "Label" para exibir um texto na tela
		lblOla   = new Label ("Ol� Mundo, sou um novo aplicativo SW!");
		
		// Cria um objeto do tipo "Button", para exibir o bot�o "Fechar"
		btnClose = new Button("Fechar");

		// Posiciona o Label com a mensagem no centro da tela,
		// tanto na horizontal quanto na vertical
		add(lblOla, CENTER, CENTER);

		// Posiciona o Label com a mensagem no centro da tela,
		// tanto na horizontal, e no final da tela na vertical
		add(btnClose, CENTER, BOTTOM);	
	}
	
	public void onEvent(Event event) 
	{
		// Executa o m�todo onEvent da classe base (super classe)
		super.onEvent(event);
				
		// Um bot�o foi clicado?
		if (event.type == ControlEvent.PRESSED)
		{
			// � o bot�o btnClose?
			if (event.target == btnClose)
			{
				// Finaliza a aplica��o
				exit(0);
			}
		}
	}
}
